# Deprecated keywords

Checkbox: No
Tags: deprecated, keywords
Text: avoid the use of deprecated keywords

Use of deprecated functions/operators such as *block.blockhash()* for *blockhash()* , *msg.gas* for *gasleft(), throw* for *revert()*, *sha3()* for *keccak256()*, *callcode()* for *delegatecall(),* *suicide()* for *selfdestruct(), constant* for *view* or *var* for *actual type name* should be avoided to prevent unintended errors with newer compiler versions

[SWC-111 · Overview](https://swcregistry.io/docs/SWC-111)
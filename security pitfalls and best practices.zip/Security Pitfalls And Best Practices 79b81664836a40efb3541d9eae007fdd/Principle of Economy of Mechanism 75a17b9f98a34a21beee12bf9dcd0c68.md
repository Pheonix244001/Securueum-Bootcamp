# Principle of Economy of Mechanism

Checkbox: No
Text: keep design as simple as possible

“Keep the design as simple and small as possible” — Ensure that 
contracts and functions are not overly complex or large so as to reduce 
readability or maintainability. Complexity typically leads to 
insecurity. (See [Saltzer and Schroeder's Secure Design Principles](https://en.wikipedia.org/wiki/Saltzer_and_Schroeder's_design_principles))
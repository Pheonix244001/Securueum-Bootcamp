# Incorrectly used modifiers

Checkbox: No
Tags: modifier
Text: Ensure correct usage

Access control is typically enforced on functions using modifiers that check if specific addresses/roles are calling these functions. A system can have multiple roles with different privileges. Ensure that correct modifiers are used on functions requiring specific access control enforced by that modifier.
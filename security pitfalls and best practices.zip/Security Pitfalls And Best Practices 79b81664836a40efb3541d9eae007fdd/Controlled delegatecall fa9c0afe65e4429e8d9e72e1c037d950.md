# Controlled delegatecall

Checkbox: Yes
Tags: delegatecall
Text: Use delegatecall  with caution and make sure to never call into untrusted contracts.

d*elegatecall()* or *callcode()* to an address controlled by the user allows execution of malicious contracts in the context of the caller’s state.

Ensure trusted destination addresses for such calls.

[SWC-112 · Overview](https://swcregistry.io/docs/SWC-112)

The Parity hack involved a combination of both insecure visibility modifiers and misuse of `delegate`
 call with abritrary data. The vulnerable contract’s function implemented `delegatecall`
 and a function from another contract that could modify ownership was left public. That allowed an attacker to craft the `msg.data`
 field to call the vulnerable function.

## delegatecall combined with selfdectruct and reentrancy vulenrabilites is the most common threat that is being observed . Usually with the help of this either funds are being lost or selfdestruct is being executed
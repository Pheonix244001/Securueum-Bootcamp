# Account existence check for low-level calls

Checkbox: No
Text: Low level calls to check account existence will return true even if there is no account

: Low-level calls *call*/*delegatecall*/*staticcall* return true even if the account called is non-existent (per EVM design)

Account existence must be checked prior to calling if needed.

[Detector Documentation · crytic/slither Wiki](https://github.com/crytic/slither/wiki/Detector-Documentation#low-level-calls)
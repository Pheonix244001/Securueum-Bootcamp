# Token owner has limited minting capabilities

Checkbox: No
Tags: erc20, mint
Text: be aware of any such capabilities in miniting functionality

Malicious or compromised owners can abuse minting capabilities. (See [here](https://github.com/crytic/building-secure-contracts/blob/master/development-guidelines/token_integration.md#owner-privileges))

contracts minting refers to the act of incrementing the account balances of addresses to which those new tokens are credited 

and in this context of token minting one should be aware of the contract owner having any extra capabilities over this functionality and

 if this is the case then a malicious owner could effectively admit an arbitrary number of tokens to any address of their choice which as you can imagine is very detrimental to the security of the token contract because all the other users using this contract and maintaining balances of these tokens in that contract will be affected because their relative share of tokens will be much smaller because of this malicious minting by the contractor
# Void constructor

Checkbox: No
Tags: constructor, inheritance

Calls to base contract constructors that are unimplemented leads to misplaced assumptions.

Check if the constructor is implemented or remove call if not.

[Detector Documentation · crytic/slither Wiki](https://github.com/crytic/slither/wiki/Detector-Documentation#void-constructor)

base construtor caliing unimplemented constructors due to misplaced assumption causing security implications
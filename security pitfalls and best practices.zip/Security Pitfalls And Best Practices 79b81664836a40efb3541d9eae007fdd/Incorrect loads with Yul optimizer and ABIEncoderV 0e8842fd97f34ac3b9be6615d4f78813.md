# Incorrect loads with Yul optimizer and ABIEncoderV2

Checkbox: No
Tags: abi, assembly
Text: fixed

The Yul optimizer incorrectly replaces *MLOAD*
 and *SLOAD*
 calls with values that have been previously written to the load location.

This can only happen if ABIEncoderV2 is activated and the experimental Yul optimizer has been activated manually in addition to the regular optimizer in the compiler settings.

This is due to a compiler bug introduced in *v0.5.14*
 and fixed in *v0.5.15*

[https://docs.soliditylang.org/en/v0.8.9/bugs.html](https://docs.soliditylang.org/en/v0.8.9/bugs.html)
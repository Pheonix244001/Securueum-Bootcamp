# Reentrancy vulnerabilities

Checkbox: Yes
Tags: reentrancy
Text: • Make sure all internal state changes are performed before the call is executed. This is known as the https://solidity.readthedocs.io/en/latest/security-considerations.html#use-the-checks-effects-interactions-pattern
• Use a reentrancy lock (ie.  https://github.com/OpenZeppelin/openzeppelin-contracts/blob/master/contracts/utils/ReentrancyGuard.sol.

Untrusted external contract calls could callback leading to unexpected results such as multiple withdrawals or out-of-order events.

Use check-effects-interactions pattern or reentrancy guards

[SWC-107 · Overview](https://swcregistry.io/docs/SWC-107)
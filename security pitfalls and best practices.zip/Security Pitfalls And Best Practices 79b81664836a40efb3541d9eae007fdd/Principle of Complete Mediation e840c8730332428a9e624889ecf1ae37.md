# Principle of Complete Mediation

Checkbox: No

“Every access to every object must be checked for authority.” — 
Ensure that any required access control is enforced along all access 
paths to the object or function being protected. (See [Saltzer and Schroeder's Secure Design Principles](https://en.wikipedia.org/wiki/Saltzer_and_Schroeder's_design_principles))
# Timing issues

Checkbox: No

Incorrect assumptions on timing of user actions, system state transitions or blockchain state/blocks/transactions may lead to security issues.
# Signature malleability

Checkbox: No
Tags: ecrecover, signature malleability
Text: A signature should never be included into a signed message hash to check if previously messages have been processed by the contract.

The *ecrecover*
 function is susceptible to signature malleability which could lead to replay attacks

Consider using OpenZeppelin’s [ECDSA library](https://github.com/OpenZeppelin/openzeppelin-contracts/blob/master/contracts/utils/cryptography/ECDSA.sol)
.

[SWC-117 · Overview](https://swcregistry.io/docs/SWC-117)

[SWC-121 · Overview](https://swcregistry.io/docs/SWC-121)

[Signature Replay Vulnerabilities in Smart Contracts](https://medium.com/cryptronics/signature-replay-vulnerabilities-in-smart-contracts-3b6f7596df57)

[Verify Signature | Solidity 0.8](https://www.youtube.com/watch?v=vYwYe-Gv_XI&t=624s)

[Replay Attack Vulnerability in Ethereum Smart Contracts Introduced by transferProxy()](https://medium.com/cypher-core/replay-attack-vulnerability-in-ethereum-smart-contracts-introduced-by-transferproxy-124bf3694e25)

In order to protect against signature replay attacks consider the following recommendations:

- Store every message hash that has been processed by the smart
contract. When new messages are received check against the already
existing ones and only proceed with the business logic if it's a new
message hash.
- Include the address of the contract that processes the message. This ensures that the message can only be used in a single contract.
- Under no circumstances generate the message hash including the signature. The `ecrecover` function is susceptible to signature malleability (see also SWC-117).
# Token balance and Flash loans

Checkbox: No
Tags: arbitrage, balance, erc20, flash loans
Text: Manipulation Risk

Users understand the associated risks of large funds or flash 
loans. Contracts relying on the token balance must carefully take in 
consideration attackers with large funds or attacks through flash loans.
 (See [here](https://github.com/crytic/building-secure-contracts/blob/master/development-guidelines/token_integration.md#token-scarcity))

token balances pose a security risk smart contract applications where the logic assumes that the balance of tokens that it is working with is always below a certain threshold stand the risk of those assumptions breaking if the balance exceeds those thresholds

Can be triggered by flash loans or whales 

can be used to arbitrage amplification
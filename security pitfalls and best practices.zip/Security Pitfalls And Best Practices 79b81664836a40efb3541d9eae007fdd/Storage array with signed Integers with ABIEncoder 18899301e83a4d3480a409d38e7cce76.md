# Storage array with signed Integers with ABIEncoderV2

Checkbox: No
Tags: abi
Text: fixed

Assigning an array of signed integers to a storage array of different type can lead to data corruption in that array.

This is due to a compiler bug introduced in *v0.4.7*
 and fixed in *v0.5.10*
.

[https://docs.soliditylang.org/en/v0.8.9/bugs.html](https://docs.soliditylang.org/en/v0.8.9/bugs.html)
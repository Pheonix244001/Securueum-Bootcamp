# Dangerous unary expressions

Checkbox: No

: Unary expressions such as *x =+ 1*
 are likely errors where the programmer really meant to use *x += 1*
. Unary *+*
 operator was deprecated in *solc v0.5.0*
.

[SWC-129 · Overview](https://swcregistry.io/docs/SWC-129)
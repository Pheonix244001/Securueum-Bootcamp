# Missing zero address validation

Checkbox: No
Tags: zero address
Text: perfom input validation on all address param that are of address type to check that they are not zero addresses .

Setters of address type parameters should include a zero-address check otherwise contract functionality may become inaccessible or tokens burnt forever.

[Detector Documentation · crytic/slither Wiki](https://github.com/crytic/slither/wiki/Detector-Documentation#missing-zero-address-validation)

zero addresses means 0000…  upto 20 bytes as ethereum address

these are used as burn addresses . any ether send to this address get burnt and  

zero address in ethereum and solidity has a special consideration
recall that ethereum addresses are 20 bytes in length and if all these bytes are zeros then it's referred to as a
zero address these zero addresses become significant because
state variables or local variables of address types have a default value of
zero in solidity and these zero addresses are also used as burn
addresses because the private key corresponding to this zero address is not known so any ether or tokens that
are sent to the zero address gets burnt or inaccessible forever
and if addresses used for access control within the smart contracts end up being zero
addresses such functions cannot be invoked again because of the lack of knowledge of the
private key so such functions cannot be called which might
in the worst case end up in such contract getting locked
so the best practice is to perform input validation on all
address parameters that are of address type to check that they are not zero
addressess
# Initializing state-variables in proxy-based upgradeable contracts

Checkbox: No
Tags: proxy, state variables
Text: dont initialize during declaration

This should be done in initializer functions and not as part of the state variable declarations in which case they won’t be set.

[https://docs.openzeppelin.com/upgrades-plugins/1.x/writing-upgradeable#avoid-initial-values-in-field-declarations](https://docs.openzeppelin.com/upgrades-plugins/1.x/writing-upgradeable#avoid-initial-values-in-field-declarations)

State var in implementation contract should not be initizlized in theri declartion themselves 

they will not will refelcted when the proxy contract makes a delegate call 

```solidity
contract MyContract {
    uint256 public hasInitialValue = 42; // equivalent to setting in the constructor
}
```

This is equivalent to setting these values in the constructor, and as
 such, will not work for upgradeable contracts. Make sure that all 
initial values are set in an initializer function as shown below; 
otherwise, any upgradeable instances will not have these fields set.

```solidity
contract MyContract is Initializable {
    uint256 public hasInitialValue;

    function initialize() public initializer {
        hasInitialValue = 42; // set initial value in initializer
    }
}
```
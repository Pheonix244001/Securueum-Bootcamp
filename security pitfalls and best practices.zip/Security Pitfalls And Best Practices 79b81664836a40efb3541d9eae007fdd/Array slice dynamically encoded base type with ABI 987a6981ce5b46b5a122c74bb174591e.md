# Array slice dynamically encoded base type with ABIEncoderV2

Checkbox: No
Tags: abi, array
Text: fixed

Accessing array slices of arrays with dynamically encoded base types (e.g. multi-dimensional arrays) can result in invalid data being read

This is due to a compiler bug introduced in *v0.6.0*
 and fixed in *v0.6.8*
. (

[https://docs.soliditylang.org/en/v0.8.9/bugs.html](https://docs.soliditylang.org/en/v0.8.9/bugs.html)
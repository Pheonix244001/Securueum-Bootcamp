# Tuple assignment multi stack slot components

Checkbox: No
Tags: tuple
Text: fixed

Tuple assignments with components that occupy several stack 
slots, i.e. nested tuples, pointers to external functions or references 
to dynamically sized calldata arrays, can result in invalid values. This
 is due to a compiler bug introduced in *v0.1.6*
 and fixed in *v0.6.6*
.

[https://docs.soliditylang.org/en/v0.8.9/bugs.html](https://docs.soliditylang.org/en/v0.8.9/bugs.html)
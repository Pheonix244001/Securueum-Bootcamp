# Token only has one address

Checkbox: No
Tags: address, erc20
Text: make sure erc20 contract works with a single address

Tokens with multiple entry points for balance updates can break internal bookkeeping based on the address (e.g. *balances[token_address][msg.sender]*
 might not reflect the actual balance). (See [here](https://github.com/crytic/building-secure-contracts/blob/master/development-guidelines/token_integration.md#contract-composition))

there should be a single address that maintains the balances of different users interacting with that contract and this effectively means that there is a single entry point for checking the balances of users and this is because multiple addresses
within a contract can result in multiple entry points for the different balances that are held or maintained by those addresses and not being aware of these multiple addresses and their balances can result in accounting bugs
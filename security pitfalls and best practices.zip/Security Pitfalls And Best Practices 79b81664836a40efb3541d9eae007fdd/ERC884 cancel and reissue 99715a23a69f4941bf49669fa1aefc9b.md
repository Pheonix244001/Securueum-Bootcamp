# ERC884 cancel and reissue

Checkbox: No
Tags: erc884
Text: Token Holding risk

Token implementers have the ability to cancel an address and move its tokens to a new address (See [here](https://gist.github.com/shayanb/cd495e23c7cf1a8b269f8ce7fd198538#file-token_checklist-md))
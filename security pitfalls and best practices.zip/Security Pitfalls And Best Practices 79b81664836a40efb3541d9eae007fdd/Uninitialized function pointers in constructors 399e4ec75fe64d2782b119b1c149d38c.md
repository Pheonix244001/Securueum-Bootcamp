# Uninitialized function pointers in constructors

Checkbox: No
Tags: constructor, pointers

****
Calling uninitialized function pointers in constructors of contracts compiled with *solc*
 versions *0.4.5-0.4.25*
 and *0.5.0-0.5.7*
 lead to unexpected behavior because of a compiler bug.

[https://github.com/crytic/slither/wiki/Detector-Documentation#uninitialized-function-pointers-in-constructors](https://github.com/crytic/slither/wiki/Detector-Documentation#uninitialized-function-pointers-in-constructors)
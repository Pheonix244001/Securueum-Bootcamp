# Dangerous state variable shadowing

Checkbox: No

Shadowing state variables in derived contracts may be dangerous for critical variables such as contract owner **
(for
 e.g. where modifiers in base contracts check on base variables but 
shadowed variables are set mistakenly) and contracts incorrectly use 
base/shadowed variables

Do not shadow state variables

[SWC-119 · Overview](https://swcregistry.io/docs/SWC-119)
# Transaction order dependence

Checkbox: No
Tags: erc20, frontrunning

Race conditions can be forced on specific Ethereum transactions by monitoring the mempool. 

For example, the classic ERC20 *approve()*
 change can be front-run using this method.

Do not make assumptions about transaction order dependence

[SWC-114 · Overview](https://swcregistry.io/docs/SWC-114)
# Long number literals

Checkbox: No
Tags: number
Text: long number literals are prone to errors . use scientific notation

Number literals with many digits should be carefully checked as they are prone to error.

[https://github.com/crytic/slither/wiki/Detector-Documentation#too-many-digits](https://github.com/crytic/slither/wiki/Detector-Documentation#too-many-digits)
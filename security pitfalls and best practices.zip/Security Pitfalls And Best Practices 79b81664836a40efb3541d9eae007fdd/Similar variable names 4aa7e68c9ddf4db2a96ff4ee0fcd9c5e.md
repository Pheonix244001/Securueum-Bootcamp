# Similar variable names

Checkbox: No
Tags: variable
Text: names of variables should be as distinct as possible

Variables with similar names could be confused for each other and therefore should be avoided

[https://github.com/crytic/slither/wiki/Detector-Documentation#variable-names-too-similar](https://github.com/crytic/slither/wiki/Detector-Documentation#variable-names-too-similar)
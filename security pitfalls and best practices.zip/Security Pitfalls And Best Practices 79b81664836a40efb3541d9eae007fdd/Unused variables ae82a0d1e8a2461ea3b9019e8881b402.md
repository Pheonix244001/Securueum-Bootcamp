# Unused variables

Checkbox: No
Tags: variable
Text: gas optimization

Unused state/local variables may be indicative of programmer error, missing logic or potential optimization opportunity, which needs to be flagged for removal or addressed appropriately

[https://swcregistry.io/docs/SWC-131](https://swcregistry.io/docs/SWC-131)
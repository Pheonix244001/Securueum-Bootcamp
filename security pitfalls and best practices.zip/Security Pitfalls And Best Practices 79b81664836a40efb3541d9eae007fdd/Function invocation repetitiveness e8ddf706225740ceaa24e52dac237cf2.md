# Function invocation repetitiveness

Checkbox: No
Tags: function
Text: Do not assume that function will only be called once

Externally accessible functions (*external*/*public* visibility) may be called any number of times. It is not safe to assume
 they will only be called only once or a specific number of times that 
is meaningful to the system design. Function implementation should be 
robust enough to track, prevent, ignore or account for arbitrarily 
repetitive invocations. For e.g., initialization functions (used with 
upgradeable contracts that cannot use constructors) are meant to be 
called only once.

taking the example of proxy based
upgradable contracts initialization
functions
are meant to be called only once
and which is why one of the security
best practices is to use the initializer lib from openzeppelin
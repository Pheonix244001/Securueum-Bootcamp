# Hash collisions with multiple variable length arguments

Checkbox: Yes
Tags: abi, hash
Text: avoid the use of packed primitive but if not then only use one variable length argument

Using *abi.encodePacked()* with multiple variable length arguments can, in certain situations, lead to a hash collision.

Do not allow users access to parameters used in *abi.encodePacked()* , use fixed length arrays or use *abi.encode()*.

[https://swcregistry.io/docs/SWC-133](https://swcregistry.io/docs/SWC-133)

[https://docs.soliditylang.org/en/v0.5.3/abi-spec.html#non-standard-packed-mode](https://docs.soliditylang.org/en/v0.5.3/abi-spec.html#non-standard-packed-mode)

[https://docs.soliditylang.org/en/v0.8.17/abi-spec.html](https://docs.soliditylang.org/en/v0.8.17/abi-spec.html)

Since `abi.encodePacked()`
 packs all elements in order
 regardless of whether they're part of an array, you can move elements 
between arrays and, so long as all elements are in the same order, it 
will return the same encoding. In a signature verification situation, an
 attacker could exploit this by modifying the position of elements in a 
previous function call to effectively bypass authorization.
# Constant issues

Checkbox: No

Incorrect assumptions about system actors, entities or parameters being constant may lead to security issues if/when such factors change unexpectedly.
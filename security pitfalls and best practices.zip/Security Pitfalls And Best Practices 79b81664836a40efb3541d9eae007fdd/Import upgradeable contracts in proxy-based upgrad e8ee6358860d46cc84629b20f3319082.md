# Import upgradeable contracts in proxy-based upgradeable contracts

Checkbox: No
Tags: proxy
Text: check the same rules for derived contracts also

Contracts imported from proxy-based upgradeable contracts should also be upgradeable where such contracts have been modified to use initializers instead of constructors

[https://docs.openzeppelin.com/upgrades-plugins/1.x/writing-upgradeable#use-upgradeable-libraries](https://docs.openzeppelin.com/upgrades-plugins/1.x/writing-upgradeable#use-upgradeable-libraries)

the contracts used in a proxy setup may also derive from other libraries or othercontracts within the project itself which could be defined in other files in which case they are imported to be used in the proxy contract these imported contracts that the proxy contracts derive from should also adhere to the same rules that we just discussed in other words the base contracts should also not use a constructor they should be using an initialized function and such contacts should also not initialize state variables during declaration and the best practice is to make sure that the imported contracts also follow those rules because if not the state would be uninitialized and using that state could result in undefined behavior or potentially even serious vulnerabilities
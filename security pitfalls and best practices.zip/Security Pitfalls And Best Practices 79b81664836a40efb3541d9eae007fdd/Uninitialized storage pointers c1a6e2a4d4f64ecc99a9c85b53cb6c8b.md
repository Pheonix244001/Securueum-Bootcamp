# Uninitialized storage pointers

Checkbox: No
Tags: pointers, storage
Text: Uninitialized local storage variable can poin to unexpected location

****
Uninitialized local storage variables can point 
to unexpected storage locations in the contract, which can lead to 
vulnerabilities

*Solc 0.5.0*
 and above disallow such pointers

[https://swcregistry.io/docs/SWC-109](https://swcregistry.io/docs/SWC-109)
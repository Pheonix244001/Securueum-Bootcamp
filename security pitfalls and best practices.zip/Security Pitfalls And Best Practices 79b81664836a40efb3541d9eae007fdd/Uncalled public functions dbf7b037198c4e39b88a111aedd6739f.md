# Uncalled public functions

Checkbox: No
Tags: function
Text: functions that are never called from within the contracts should be declared external to save gas.

*Public*
 functions that are never called from within the contracts should be declared *external*
 to save gas.

[https://github.com/crytic/slither/wiki/Detector-Documentation#public-function-that-could-be-declared-external](https://github.com/crytic/slither/wiki/Detector-Documentation#public-function-that-could-be-declared-external)

arg. of public function need to copied from the calldata component of the evm to the mem componet and this copying produce more bytecode that use more gas . 

in case of external functions their arguments can be left behind in the calldata component of the evm
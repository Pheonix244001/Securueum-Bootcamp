# Incorrect inheritance order

Checkbox: Yes
Tags: inheritance
Text: The rule of thumb is to inherit contracts from more /general/ to more /specific/.

Contracts inheriting from multiple contracts with identical functions should specify the correct inheritance order i.e. more general to more specific to avoid inheriting the incorrect function implementation.

[https://swcregistry.io/docs/SWC-125](https://swcregistry.io/docs/SWC-125)

[Solidity anti-patterns: Fun with inheritance DAG abuse](https://pdaian.com/blog/solidity-anti-patterns-fun-with-inheritance-dag-abuse/)

[Contracts - Solidity 0.4.25 documentation](https://docs.soliditylang.org/en/v0.4.25/contracts.html#multiple-inheritance-and-linearization)
# Essential assignments removed with Yul Optimizer

Checkbox: No
Tags: assembly
Text: fixed

The Yul optimizer can remove essential assignments to variables declared inside *for*
 loops when Yul's *continue*
 or *break*
 statement is used mostly while using inline assembly with *for*
 loops and *continue*
 and *break*
 statements. This is due to a compiler bug introduced in *v0.5.8*
/*v0.6.0*
 and fixed in *v0.5.16*
/*v0.6.1*
.

[https://docs.soliditylang.org/en/v0.8.9/bugs.html](https://docs.soliditylang.org/en/v0.8.9/bugs.html)
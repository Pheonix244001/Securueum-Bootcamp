# Function visibility

Checkbox: No
Tags: function
Text: Strictest Visibility should be implemented

Ensure that the strictest visibility is used for the required functionality. An accidental external/public visibility will allow (untrusted) users to invoke functionality that is supposed to be restricted internally.

Public external internal private  decreasing visibility
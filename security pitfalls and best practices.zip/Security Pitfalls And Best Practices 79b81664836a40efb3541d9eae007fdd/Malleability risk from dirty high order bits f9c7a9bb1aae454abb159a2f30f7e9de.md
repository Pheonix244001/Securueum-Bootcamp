# Malleability risk from dirty high order bits

Checkbox: No
Tags: signature malleability
Text: dirty higher order bits in msg.data is not good

: Types that do not occupy the full 32 bytes 
might contain “dirty higher order bits” which does not affect operation 
on types but gives different results with *msg.data*
.

[https://docs.soliditylang.org/en/v0.8.1/security-considerations.html#minor-details](https://docs.soliditylang.org/en/v0.8.1/security-considerations.html#minor-details)

there is a security risk from dirty high order bits in solidity

 recall that the evm word size is 256 bits or 32 points and there are multiple types in solidity whose size is less than 32 bytes using variables of such types may result in their higher order bits containing dirty values and what this means is that they may contain values from previous rights to those bits that have not been cleared or zeroed out such dirty order bits are not a concernfor variable operations because the compiler is aware of these dirty bits and takes care to make sure that they do not affect the values of variables
but if those variables end up getting used or passed around as message data then that may result in them having the different values and causing malleability or non-uniqueness this is a risk that needs to be kept in mind when looking at contracts that have variables of such types

Types that do not occupy the full 32 bytes might contain “dirty higher order bits”.
This is especially important if you access `msg.data`
 - it poses a malleability risk:
You can craft transactions that call a function `f(uint8 x)`
 with a raw byte argument
of `0xff000001`
 and with `0x00000001`
. Both are fed to the contract and both will
look like the number `1`
 as far as `x`
 is concerned, but `msg.data`
 will
be different, so if you use `keccak256(msg.data)`
 for anything, you will get different results.
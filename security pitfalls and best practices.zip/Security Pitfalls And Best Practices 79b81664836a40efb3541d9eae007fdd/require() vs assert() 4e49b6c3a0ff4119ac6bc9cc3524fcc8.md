# require() vs assert()

Checkbox: No
Tags: assert, require
Text: use assert to create panic if error and use require if expected an error

*require()* should be used for checking error conditions on inputs and return values while *assert()* should be used for invariant checking. Between *solc 0.4.10* and *0.8.0*, *require()* used *REVERT*
 (*0xfd*) opcode which refunded remaining gas on failure while *assert()*
 used INVALID (*0xfe*) opcode which consumed all the supplied gas

[Expressions and Control Structures - Solidity 0.8.1 documentation](https://docs.soliditylang.org/en/v0.8.1/control-structures.html#error-handling-assert-require-revert-and-exceptions)
# Token does not allow flash minting

Checkbox: No
Tags: erc20, flash loans, mint
Text: Overflow or Balance/Supply assumption → manipulation risk

Flash minting can lead to substantial swings in the balance and 
the total supply, which necessitate strict and comprehensive overflow 
checks in the operation of the token. (See [here](https://github.com/crytic/building-secure-contracts/blob/master/development-guidelines/token_integration.md#token-scarcity))

flash minting simply mends the new
tokens that are handed to the user
and these again are
only available within the context of a
transaction
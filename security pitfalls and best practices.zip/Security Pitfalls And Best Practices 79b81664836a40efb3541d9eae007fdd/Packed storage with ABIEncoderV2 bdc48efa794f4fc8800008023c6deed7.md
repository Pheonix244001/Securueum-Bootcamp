# Packed storage with ABIEncoderV2

Checkbox: No
Tags: abi
Text: fixed

Storage structs and arrays with types shorter than 32 bytes can cause data corruption if encoded directly from storage using ABIEncoderV2.

This is due to a compiler bug introduced in *v0.5.0*
 and fixed in *v0.5.7*

[https://docs.soliditylang.org/en/v0.8.9/bugs.html](https://docs.soliditylang.org/en/v0.8.9/bugs.html)
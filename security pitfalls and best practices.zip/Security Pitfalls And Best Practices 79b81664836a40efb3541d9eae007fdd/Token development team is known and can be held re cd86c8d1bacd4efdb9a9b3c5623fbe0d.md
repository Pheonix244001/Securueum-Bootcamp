# Token development team is known and can be held responsible for abuse

Checkbox: No
Tags: erc20, team
Text: Team risk can translate into a legal risk

Contracts with anonymous development teams, or that reside in legal shelters should require a higher standard of review. (See [here](https://github.com/crytic/building-secure-contracts/blob/master/development-guidelines/token_integration.md#owner-privileges))

Team behind the project may be public or anonymous 

anon teams are riskier and there is a greater security risk to the project 

they should meet a higher bar when it comes to security 

other school of thought is that it should not matter
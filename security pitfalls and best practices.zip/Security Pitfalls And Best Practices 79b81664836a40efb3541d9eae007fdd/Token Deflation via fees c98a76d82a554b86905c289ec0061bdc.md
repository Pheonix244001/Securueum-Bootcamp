# Token Deflation via fees

Checkbox: No
Tags: erc20, token deflation
Text: Check Deflation Unexpected Behaviour

Transfer and transferFrom should not take a fee. Deflationary tokens can lead to unexpected behavior. (See [here](https://github.com/crytic/building-secure-contracts/blob/master/development-guidelines/token_integration.md#erc-conformity))

Some of the contracts may take a fee when tokens are being transferred from one address to another and because of that the no of tokens will reduce over time when they transferred b/w those addresses .

And this is more of a concern in smart contact applications that allow their users to interact with it using arbitrary erc20 token contracts and in such cases consider a guarded launch approach where the initial set of erc20 tokens that can be used with this contract do not have this notion of deflation.
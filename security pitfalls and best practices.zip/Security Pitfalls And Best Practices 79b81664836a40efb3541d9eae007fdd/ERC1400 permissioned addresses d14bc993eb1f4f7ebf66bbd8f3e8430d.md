# ERC1400 permissioned addresses

Checkbox: No
Tags: erc1400, security tokens
Text: DOS risk

Can block transfers from/to specific addresses. (See [here](https://gist.github.com/shayanb/cd495e23c7cf1a8b269f8ce7fd198538#file-token_checklist-md))

Ploymath Security Tokens 

can block transfer to certain addresses
# Redundant statements

Checkbox: No
Tags: statements
Text: missing logic or optimzation

Statements with no effects that do not produce code may be indicative of programmer error or missing logic, which needs to be flagged for removal or addressed appropriately.

[https://swcregistry.io/docs/SWC-135](https://swcregistry.io/docs/SWC-135)
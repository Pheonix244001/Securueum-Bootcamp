# Calls inside a loop

Checkbox: No
Tags: dos, loop
Text: Avoid calls within loops, check that loop index cannot be user-controlled or is bounded.

Calls to external contracts inside a loop are dangerous (especially if the loop index can be user-controlled) because  it could lead to DoS if one of the calls reverts or execution runs out of gas

Avoid calls within loops, check that loop index cannot be user-controlled or is bounded.

[SWC-113 · Overview](https://swcregistry.io/docs/SWC-113)

it is better to isolate each external call into its own transaction that can be initiated by the recipient of the call. This is especially relevant for payments, where it is better to let users withdraw funds rather than push funds to them automatically (this also reduces the chance of problems with the gas limit).
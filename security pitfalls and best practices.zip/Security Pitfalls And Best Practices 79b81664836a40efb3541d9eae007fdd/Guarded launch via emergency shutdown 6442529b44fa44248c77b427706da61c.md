# Guarded launch via emergency shutdown

Checkbox: No
Tags: guarded launch
Text: start with emergency shutdown capabolities then remove this

****
Implement capabilities that allow governance to 
shutdown new activity in the system and allow users to reclaim assets 
may reduce impact due to initial vulnerabilities or exploits. (See [here](https://medium.com/electric-capital/derisking-defi-guarded-launches-2600ce730e0a#:~:text=Guarded%20Launches:%20Protecting%20Users%20with%20Limits&text=A%20new%20contract%20is%20deployed,product%20in%20a%20limited%20scope.))

auth . users can emergency shutdown and users can reclaims assets and also auth users can resetart
# Function invocation order

Checkbox: No
Tags: function
Text: Do not assume that functions will be called in a specific order only

****
Externally accessible functions (*external*
/*public*

 visibility) may be called in any order (with respect to other defined 
functions). It is not safe to assume they will only be called in the 
specific order that makes sense to the system design or is implicitly 
assumed in the code. For e.g., initialization functions (used with 
upgradeable contracts that cannot use constructors) are meant to be 
called before other system functions can be called.
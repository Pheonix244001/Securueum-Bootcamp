# ERC20 name, decimals, and symbol functions

Checkbox: No
Tags: erc20, function
Text: Do not assume that these primitives are always present coz they are optional

Are present if used. These functions are optional in the ERC20 standard and might not be present. (See [here](https://github.com/crytic/building-secure-contracts/blob/master/development-guidelines/token_integration.md#erc-conformity)
)

[building-secure-contracts/token_integration.md at master · crytic/building-secure-contracts](https://github.com/crytic/building-secure-contracts/blob/master/development-guidelines/token_integration.md#erc-conformity)

any contract that is interacting with these contracts should make sure that these primitives are already present in the contract if they want to use it
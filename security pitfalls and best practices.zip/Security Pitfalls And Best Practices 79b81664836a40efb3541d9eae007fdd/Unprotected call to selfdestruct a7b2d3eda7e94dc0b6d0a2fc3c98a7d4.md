# Unprotected call to selfdestruct

Checkbox: No
Tags: access control, reentrancy, selfdestruct
Text: ERC721 , nft , proxy , lendborrow, ERC20 , swap

A user/attacker can mistakenly/intentionally kill the contract. Protect access to such functions

---

[SWC-106 · Overview](https://swcregistry.io/docs/SWC-106)

[Introduction to Smart Contracts - Solidity 0.8.17 documentation](https://docs.soliditylang.org/en/v0.8.17/introduction-to-smart-contracts.html)

[EIP-4758: Deactivate SELFDESTRUCT](https://eips.ethereum.org/EIPS/eip-4758)

[Solidity by Example](https://solidity-by-example.org/hacks/self-destruct/)

---

We need to make sure that selfdectruct can only be acccessed by the owner only

HIGHS

[https://github.com/code-423n4/2022-07-fractional-findings/issues/200](https://github.com/code-423n4/2022-07-fractional-findings/issues/200) 

[https://github.com/code-423n4/2022-11-non-fungible-findings/issues/96](https://github.com/code-423n4/2022-11-non-fungible-findings/issues/96)

MEDS

[https://github.com/code-423n4/2021-05-yield-findings/issues/49](https://github.com/code-423n4/2021-05-yield-findings/issues/49)

[https://github.com/code-423n4/2022-01-trader-joe-findings/issues/170](https://github.com/code-423n4/2022-01-trader-joe-findings/issues/170)

[https://github.com/code-423n4/2022-08-fiatdao-findings/issues/75](https://github.com/code-423n4/2022-08-fiatdao-findings/issues/75)

[https://github.com/code-423n4/2021-11-unlock-findings/issues/186](https://github.com/code-423n4/2021-11-unlock-findings/issues/186)

[https://github.com/code-423n4/2022-03-maple-findings/issues/23](https://github.com/code-423n4/2022-03-maple-findings/issues/23)

[https://github.com/code-423n4/2022-03-maple-findings/issues/23](https://github.com/code-423n4/2022-03-maple-findings/issues/23)

[https://github.com/code-423n4/2022-07-axelar-findings/issues/20](https://github.com/code-423n4/2022-07-axelar-findings/issues/20)

## It has been found that the attacker is gaining access and calling the selfdestruct

What is happening is that the attacker is calling the selfdestruct function using proxy contract and delegatecall

 

### Some key attacks

1. destroy it by doing a delegate call (via the `execute`function) to a function with the `selfdestruct`
 opcode
2. Destroy refinancer contract by calling selfdestruct
3. The attacker can create a lock contract and set the token address to a special gas saving token, which will selfdestruct to get a gas refund on `transfer`
4. Attacker can interact with the system and selfdestruct his contract,
5. owner intentionally or accidentally destroys their proxy by `delegatecall` ing a target that calls `selfdestruct`
# Assembly usage

Checkbox: No
Tags: assembly
Text: assembly is prone to errors . if used , then double check

Use of EVM assembly is error-prone and should be avoided or double-checked for correctness.

[https://github.com/crytic/slither/wiki/Detector-Documentation#assembly-usage](https://github.com/crytic/slither/wiki/Detector-Documentation#assembly-usage)

assembly bypass solidity checks . assembly language is yul
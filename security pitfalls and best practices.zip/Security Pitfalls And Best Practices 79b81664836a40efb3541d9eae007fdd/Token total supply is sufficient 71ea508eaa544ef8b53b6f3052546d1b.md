# Token total supply is sufficient

Checkbox: No
Tags: erc20, supply
Text: Increased manipulation rsik

Tokens with a low total supply can be easily manipulated. (See [here](https://github.com/crytic/building-secure-contracts/blob/master/development-guidelines/token_integration.md#token-scarcity))

Low supply means ownership will be concentrated then they will have the influence of price and liquidity
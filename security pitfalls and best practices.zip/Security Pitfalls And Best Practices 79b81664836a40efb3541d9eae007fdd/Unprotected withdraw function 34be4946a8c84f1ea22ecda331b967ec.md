# Unprotected withdraw function

Checkbox: No
Tags: access control, withdraw
Text: Implement controls so withdrawals can only be triggered by authorized parties or according to the specs of the smart contract system.

: Unprotected (*external*/*public*) function calls sending Ether/tokens to user-controlled addresses may allow users to withdraw unauthorized funds

[SWC-105 · Overview](https://swcregistry.io/docs/SWC-105)

1. if unprotected , public/external or no modifier that it may let attackers call this unprotected function and leads to unauthorized withdrawl
# Calldata structs with statically sized and dynamically encoded members with ABIEncoderV2

Checkbox: No
Tags: struct
Text: fixed

Reading from calldata structs that contain dynamically encoded, but statically sized members can result in incorrect values.

This is due to a compiler bug introduced in *v0.5.6*
 and fixed in *v0.5.11*
.

[https://docs.soliditylang.org/en/v0.8.9/bugs.html](https://docs.soliditylang.org/en/v0.8.9/bugs.html)
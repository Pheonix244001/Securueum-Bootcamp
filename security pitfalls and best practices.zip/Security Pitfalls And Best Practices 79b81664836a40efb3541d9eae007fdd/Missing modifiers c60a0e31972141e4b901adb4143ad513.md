# Missing modifiers

Checkbox: No
Tags: modifier
Text: review modifiers

Access control is typically enforced on functions using modifiers that check if specific addresses/roles are calling these functions. Ensure that such modifiers are present on all relevant functions which require that specific access control.
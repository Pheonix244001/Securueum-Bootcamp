# Costly operations inside a loop

Checkbox: No
Tags: dos, gas, loop
Text: Use Local variables

Operations such as state variable updates (use SSTOREs) inside a loop cost a lot of gas, are expensive and may lead to out-of-gas errors.

Optimizations using local variables are preferred.

[Detector Documentation · crytic/slither Wiki](https://github.com/crytic/slither/wiki/Detector-Documentation#costly-operations-inside-a-loop)
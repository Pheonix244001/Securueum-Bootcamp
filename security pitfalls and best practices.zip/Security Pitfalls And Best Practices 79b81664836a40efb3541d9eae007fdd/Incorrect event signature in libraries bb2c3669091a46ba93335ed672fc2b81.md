# Incorrect event signature in libraries

Checkbox: No
Tags: events

Contract types used in events in libraries cause an incorrect event signature hash.

Instead of using the type `address` in the hashed signature, the actual contract name was used, leading to a wrong hash in the logs.

This is due to a compiler bug introduced in *v0.5.0*
 and fixed in *v0.5.8*
.

[List of Known Bugs - Solidity 0.8.1 documentation](https://docs.soliditylang.org/en/v0.8.1/bugs.html)
# Return values of low-level calls

Checkbox: No
Tags: return, unchecked
Text: Low level methods does not throw exception . Ensure that they are checked

Solidity offers low-level call methods that work on raw addresses: `address.call()`,
`address.callcode()`, `address.delegatecall()`, and `address.send()`. These low-level methods never
throw an exception, but will return `false` if the call encounters an exception. On the other hand,
*contract calls* (e.g., `ExternalContract.doSomething()`) will automatically propagate a throw (for
example, `ExternalContract.doSomething()` will also `throw` if `doSomething()` throws).

If you choose to use the low-level call methods, make sure to handle the possibility that the call
will fail, by checking the return value.

Ensure that return values of low-level calls (*call*/*callcode*/*delegatecall*/*send*/etc.) are checked to avoid unexpected failures.

[SWC-104 · Overview](https://swcregistry.io/docs/SWC-104)

[External Calls](https://consensys.github.io/smart-contract-best-practices/development-recommendations/general/external-calls/#handle-errors-in-external-calls)
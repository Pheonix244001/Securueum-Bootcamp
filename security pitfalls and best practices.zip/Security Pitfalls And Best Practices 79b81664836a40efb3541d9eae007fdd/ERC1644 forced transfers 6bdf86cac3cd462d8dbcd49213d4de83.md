# ERC1644 forced transfers

Checkbox: No
Tags: erc1644
Text: Unbounded transfer

Controller has the ability to steal funds. (See [here](https://gist.github.com/shayanb/cd495e23c7cf1a8b269f8ce7fd198538#file-token_checklist-md))
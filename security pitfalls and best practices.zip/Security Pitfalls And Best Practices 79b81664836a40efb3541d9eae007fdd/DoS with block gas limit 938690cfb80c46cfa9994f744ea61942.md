# DoS with block gas limit

Checkbox: No
Tags: array, dos, gas
Text: check if loop index is user controlled

Programming patterns such as looping over arrays of unknown size may lead to DoS when the gas cost of execution exceeds the block gas limit.

[SWC-128 · Overview](https://swcregistry.io/docs/SWC-128)

[GovernMental's 1100 ETH jackpot payout is stuck because it uses too much gas](https://www.reddit.com/r/ethereum/comments/4ghzhv/governmentals_1100_eth_jackpot_payout_is_stuck/)

[How to clear large arrays without blowing the gas limit?](https://ethereum.stackexchange.com/questions/3373/how-to-clear-large-arrays-without-blowing-the-gas-limit)

In general, it seems like we need one
 new piece of standard advice for contract developers: make sure that if
 you have arrays that users can extend then either find some way for 
each user to separately handle the array elements associated with 
themselves (eg. this is how slock DAO splitting works) or split up the 
work among several transactions (eg. as done in my [two-phase auction](https://github.com/ethereum/dapp-bin/blob/master/ether_ad/two_phase_auction.sol#L116) implementation).
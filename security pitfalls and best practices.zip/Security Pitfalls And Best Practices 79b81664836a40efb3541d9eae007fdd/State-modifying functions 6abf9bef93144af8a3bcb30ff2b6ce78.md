# State-modifying functions

Checkbox: No

Functions that modify state (in assembly or otherwise) but are labelled *constant*/*pure*/*view*
 revert in *solc >=0.5.0* (work in prior versions) because of the use of *STATICCALL* opcode

[Detector Documentation · crytic/slither Wiki](https://github.com/crytic/slither/wiki/Detector-Documentation#constant-functions-using-assembly-code)
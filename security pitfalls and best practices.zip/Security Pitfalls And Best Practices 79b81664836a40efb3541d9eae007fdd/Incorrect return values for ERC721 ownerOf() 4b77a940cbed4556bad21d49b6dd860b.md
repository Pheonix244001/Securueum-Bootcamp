# Incorrect return values for ERC721 ownerOf()

Checkbox: No
Tags: erc721, ownerOf()
Text: Use openzeppelin Erc721

Contracts compiled with *solc >= 0.4.22*
 interacting with ERC721 *ownerOf()*
 that returns a *bool*
 instead of *address*
 type will revert

Use OpenZeppelin’s ERC721 contracts.

[Detector Documentation · crytic/slither Wiki](https://github.com/crytic/slither/wiki/Detector-Documentation#incorrect-erc721-interface)
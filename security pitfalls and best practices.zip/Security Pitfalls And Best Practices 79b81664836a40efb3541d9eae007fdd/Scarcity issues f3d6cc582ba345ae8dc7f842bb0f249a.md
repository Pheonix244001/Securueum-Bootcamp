# Scarcity issues

Checkbox: No
Text: incorrect of scarcity

Incorrect assumptions about the scarcity of tokens/funds available to any system actor will lead to unexpected outcomes which may lead to security issues. For e.g., flash loans.
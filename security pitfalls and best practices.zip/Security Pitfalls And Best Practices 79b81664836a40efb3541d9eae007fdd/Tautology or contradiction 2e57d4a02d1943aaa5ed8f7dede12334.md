# Tautology or contradiction

Checkbox: No
Tags: tautology

Tautologies (always true) or contradictions (always false) indicate potential flawed logic or redundant checks. e.g.     *x >= 0* which is always true if *x* is *uint*

[Detector Documentation · crytic/slither Wiki](https://github.com/crytic/slither/wiki/Detector-Documentation#tautology-or-contradiction)
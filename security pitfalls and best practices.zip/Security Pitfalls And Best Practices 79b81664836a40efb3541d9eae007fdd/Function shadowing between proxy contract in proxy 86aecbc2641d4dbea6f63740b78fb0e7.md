# Function shadowing between proxy/contract in proxy-based upgradeable contracts

Checkbox: No
Tags: function, proxy
Text: Rename the function. Avoid public functions in the proxy.

Shadow functions in proxy contract prevent functions in logic contract from being invoked.

[https://github.com/crytic/slither/wiki/Upgradeability-Checks#functions-shadowing](https://github.com/crytic/slither/wiki/Upgradeability-Checks#functions-shadowing)

```solidity
contract Contract{
    function get() public {
        // ...
    }
}

contract Proxy{
    function get() public {
        // ...
    }
}
```

`Proxy.get` will shadow any call to `get()`. As a result `get()` is never executed in the logic contract and cannot be updated.
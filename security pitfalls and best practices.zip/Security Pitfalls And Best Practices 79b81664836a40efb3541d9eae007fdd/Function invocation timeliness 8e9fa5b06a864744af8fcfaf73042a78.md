# Function invocation timeliness

Checkbox: No
Tags: function, timing
Text: Do not assume that functions will be called in a timely manner . Robust handling of system state transition should be done

Externally accessible functions (*external*/*public* visibility) may be called at any time (or never). It is not safe to 
assume they will only be called at specific system phases (e.g. after 
initialization, when unpaused, during liquidation) that is meaningful to
 the system design. The reason for this can be accidental or malicious. 
Function implementation should be robust enough to track system state 
transitions, determine meaningful states for invocations and withstand 
arbitrary calls. For e.g., initialization functions (used with 
upgradeable contracts that cannot use constructors) are meant to be 
called atomically along with contract deployment to prevent anyone else 
from initializing with arbitrary values.

proxy based upgradable contracts that we
have discussed
where initialization functions are
required to be used instead of
constructors
such functions
are meant to be called atomically along
with contract deployment during
construction
to prevent anyone else from initializing
those contracts with arbitrary values
and such initialization functions are
not meant or not
allowed to be called after deployment
# Access control changes

Checkbox: No
Tags: access control
Text: if access control is to be changed , validate / two step process

Ensure that changes to access control (e.g. change of ownership to new addresses) are handled with extra security so that such transitions happen smoothly without contracts getting locked out or compromised due to use of incorrect credentials.
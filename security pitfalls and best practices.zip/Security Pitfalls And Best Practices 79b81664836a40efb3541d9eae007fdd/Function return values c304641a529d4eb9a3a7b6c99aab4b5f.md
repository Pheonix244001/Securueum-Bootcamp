# Function return values

Checkbox: No
Tags: function, return
Text: Make sure that correct return value is returned by function . also the call sites should use those return values approprietely

Ensure that the appropriate return value(s) are returned from functions and checked without ignoring at function call sites, so that error conditions are caught and handled appropriately.
# Dangerous strict equalities

Checkbox: No
Tags: equality
Text: Consider using >= or <=  instead of ==

Use of strict equalities with tokens/Ether can accidentally/maliciously cause unexpected behavior

Consider using *>=*
 or *<=*
 instead of *==*
 for such variables depending on the contract logic

[Detector Documentation · crytic/slither Wiki](https://github.com/crytic/slither/wiki/Detector-Documentation#dangerous-strict-equalities)
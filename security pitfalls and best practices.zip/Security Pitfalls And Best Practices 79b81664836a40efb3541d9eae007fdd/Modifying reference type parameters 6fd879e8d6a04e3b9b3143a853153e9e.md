# Modifying reference type parameters

Checkbox: No
Tags: function
Text: Ensure correct usage of memory and storage in function parameters and make all data locations explicit.

Structs/Arrays/Mappings passed as arguments to a function may be 
by value (memory) or reference (storage) as specified by the data 
location (optional before *solc 0.5.0*).

Ensure correct usage of memory and storage in function parameters and make all data locations explicit.

[https://github.com/crytic/slither/wiki/Detector-Documentation#modifying-storage-array-by-value](https://github.com/crytic/slither/wiki/Detector-Documentation#modifying-storage-array-by-value)
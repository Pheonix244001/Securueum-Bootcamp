# No token user owns most of the supply

Checkbox: No
Tags: erc20, owner
Text: Centralization risk can be manifested into security risk

If a few users own most of the tokens, they can influence operations based on the token's repartition. (See [here](https://github.com/crytic/building-secure-contracts/blob/master/development-guidelines/token_integration.md#token-scarcity))
# Auditing/logging issues

Checkbox: No

Incorrect or insufficient emission of events will impact off-chain monitoring and incident response capabilities which may lead to security issues.
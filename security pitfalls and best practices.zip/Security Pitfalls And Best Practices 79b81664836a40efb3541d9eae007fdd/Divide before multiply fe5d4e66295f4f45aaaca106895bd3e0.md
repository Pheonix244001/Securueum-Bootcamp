# Divide before multiply

Checkbox: No
Text: First multiplication then division

Performing multiplication before division is 
generally better to avoid loss of precision because Solidity integer 
division might truncate

[Detector Documentation · crytic/slither Wiki](https://github.com/crytic/slither/wiki/Detector-Documentation#divide-before-multiply)
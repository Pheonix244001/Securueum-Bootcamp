# Tokens are located in more than a few exchanges

Checkbox: No
Tags: erc20, listing

If all the tokens are in one exchange, a compromise of the exchange can compromise the contract relying on the token. (See [here](https://github.com/crytic/building-secure-contracts/blob/master/development-guidelines/token_integration.md#token-scarcity))

CEX vs DEX 

if token is listed to very fwe centralized exchanges . and if those exchanges are hacked , then there is a possibility that the token will be inaccessible then volatility of token comes into place
# Token contract avoids unneeded complexity

Checkbox: No
Tags: erc20, token complexity
Text: complexity → Bugs . Avoid unnecesssary complexities

The token should be a simple contract; a token with complex code requires a higher standard of review. (See [here](https://github.com/crytic/building-secure-contracts/blob/master/development-guidelines/token_integration.md#contract-composition))
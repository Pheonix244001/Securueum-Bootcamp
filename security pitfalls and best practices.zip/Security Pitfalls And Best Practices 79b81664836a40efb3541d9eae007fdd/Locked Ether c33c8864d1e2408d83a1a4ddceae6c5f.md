# Locked Ether

Checkbox: No
Tags: payable, withdraw
Text: Remove payable attribute or add withdraw function.

Contracts that accept Ether via *payable*
 functions but without withdrawal mechanisms will lock up that Ether

Remove *payable*
 attribute or add withdraw function.

[Detector Documentation · crytic/slither Wiki](https://github.com/crytic/slither/wiki/Detector-Documentation#contracts-that-lock-ether)
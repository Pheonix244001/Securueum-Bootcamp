# Incorrectly implemented modifiers

Checkbox: No
Tags: modifier
Text: modifiers are enforcing correctly in case of RBAC

Access control is typically enforced on functions using modifiers that check if specific addresses/roles are calling these functions. A system can have multiple roles with different privileges. Ensure that modifiers are implementing the expected checks on the correct roles/addresses with the right composition e.g. incorrect use of || instead of && is a common vulnerability while composing access checks.
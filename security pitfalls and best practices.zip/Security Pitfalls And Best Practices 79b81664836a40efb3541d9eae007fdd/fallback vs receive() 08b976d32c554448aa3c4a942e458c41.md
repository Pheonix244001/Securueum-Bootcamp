# fallback vs receive()

Checkbox: No
Tags: fallback(), recieve()

Check that all precautions and subtleties of *fallback*
/*receive* functions related to visibility, state mutability and Ether transfers have been considered

[Contracts - Solidity 0.8.17 documentation](https://docs.soliditylang.org/en/latest/contracts.html#fallback-function)

[https://docs.soliditylang.org/en/latest/contracts.html#receive-ether-function](https://docs.soliditylang.org/en/latest/contracts.html#receive-ether-function)
# Weak PRNG

Checkbox: Yes

PRNG relying on *block.timestamp*
, *now*
 or *blockhash* 
can be influenced by miners to some extent and should be avoided.

[SWC-120 · Overview](https://swcregistry.io/docs/SWC-120)

creating a strong enough source of randomness in Ethereum is very challenging.
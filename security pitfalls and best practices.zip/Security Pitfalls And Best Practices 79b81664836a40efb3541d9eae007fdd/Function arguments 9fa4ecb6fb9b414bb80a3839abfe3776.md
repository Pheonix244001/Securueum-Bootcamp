# Function arguments

Checkbox: No
Tags: function
Text: check function arguments

Ensure that the arguments to function calls at the caller sites are the correct ones and in the right order as expected by the function definition.

at a high level the arguments that are
used at the call sites that's the
callers should match the parameters that
are required by the functions or the

the arguments at the call sides should
be valid in that smart contract
applications context to what the
function parameters expect
and the order of such arguments should
match the order of the function
parameters as expected
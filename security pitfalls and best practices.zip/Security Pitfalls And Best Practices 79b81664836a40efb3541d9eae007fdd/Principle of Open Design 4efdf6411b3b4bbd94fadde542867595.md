# Principle of Open Design

Checkbox: No

“The design should not be secret” — Smart contracts are expected 
to be open-sourced and accessible to everyone. Security by obscurity of 
code or underlying algorithms is not an option. Security should be 
derived from the strength of the design and implementation under the 
assumption that (byzantine) attackers will study their details and try 
to exploit them in arbitrary ways. (See [Saltzer and Schroeder's Secure Design Principles](https://en.wikipedia.org/wiki/Saltzer_and_Schroeder's_design_principles))
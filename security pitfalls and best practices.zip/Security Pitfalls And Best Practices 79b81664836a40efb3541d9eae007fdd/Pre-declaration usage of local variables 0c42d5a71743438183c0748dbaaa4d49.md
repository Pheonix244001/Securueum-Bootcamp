# Pre-declaration usage of local variables

Checkbox: No
Text: variable used before declaration will result in unintendted consequences

Usage of a variable before its declaration (either declared later or in another scope) leads to unexpected behavior in *solc < 0.5.0* 
but *solc >= 0.5.0*

 implements C99-style scoping rules where variables can only be used 
after they have been declared and only in the same or nested scopes.

[Detector Documentation · crytic/slither Wiki](https://github.com/crytic/slither/wiki/Detector-Documentation#pre-declaration-usage-of-local-variables)
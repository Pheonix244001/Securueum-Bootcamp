# Configuration issues

Checkbox: No
Text:

Misconfiguration of system components such contracts, parameters, addresses and permissions may lead to security issues.
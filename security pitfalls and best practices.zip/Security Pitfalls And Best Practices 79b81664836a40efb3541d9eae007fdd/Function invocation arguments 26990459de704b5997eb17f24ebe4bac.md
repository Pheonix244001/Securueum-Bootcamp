# Function invocation arguments

Checkbox: No
Tags: function
Text: Do not assume the the arguments input to the function will be valid

Externally accessible functions (*external*
/*public*

 visibility) may be called with any possible arguments. Without complete
 and proper validation (e.g. zero address checks, bound checks, 
threshold checks etc.), they cannot be assumed to comply with any 
assumptions made about them in the code.
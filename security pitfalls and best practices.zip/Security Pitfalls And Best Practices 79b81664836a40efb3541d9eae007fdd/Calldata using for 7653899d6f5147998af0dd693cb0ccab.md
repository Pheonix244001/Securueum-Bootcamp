# Calldata
 using for

Checkbox: No
Tags: calldata
Text: fixed

Function calls to internal library functions with calldata parameters called via “*using for”*
 can result in invalid data being read. This is due to a compiler bug introduced in *v0.6.9*
 and fixed in *v0.6.10*

[https://docs.soliditylang.org/en/v0.8.9/bugs.html](https://docs.soliditylang.org/en/v0.8.9/bugs.html)
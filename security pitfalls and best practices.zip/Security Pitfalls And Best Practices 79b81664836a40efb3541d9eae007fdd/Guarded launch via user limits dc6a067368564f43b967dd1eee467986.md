# Guarded launch via user limits

Checkbox: No
Tags: guarded launch, user limit
Text: Launch for few trusted users first

Limiting the total number of users that can 
interact with a system initially upon launch and gradually increasing it
 over time may reduce impact due to initial vulnerabilities or exploits.
 Initial users may also be whitelisted to limit to trusted actors before
 opening the system to everyone. (See [here](https://medium.com/electric-capital/derisking-defi-guarded-launches-2600ce730e0a#:~:text=Guarded%20Launches:%20Protecting%20Users%20with%20Limits&text=A%20new%20contract%20is%20deployed,product%20in%20a%20limited%20scope.))
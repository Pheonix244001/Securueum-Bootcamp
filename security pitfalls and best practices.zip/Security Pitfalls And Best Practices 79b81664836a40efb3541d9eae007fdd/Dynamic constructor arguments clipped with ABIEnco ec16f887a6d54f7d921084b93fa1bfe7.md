# Dynamic constructor arguments clipped with ABIEncoderV2

Checkbox: No
Tags: constructor
Text: fixed

contract's constructor which takes structs or arrays that contain dynamically sized arrays reverts or decodes to invalid data when ABIEncoderV2 is used.

This is due to a compiler bug introduced in *v0.4.16*
 and fixed in *v0.5.9*

[https://docs.soliditylang.org/en/v0.8.9/bugs.html](https://docs.soliditylang.org/en/v0.8.9/bugs.html)
# Token Inflation via interest

Checkbox: No
Tags: erc20, token inflation
Text: check inflation trapped in contract

Potential interest earned from the token should be taken into 
account. Some tokens distribute interest to token holders. This interest
 might be trapped in the contract if not taken into account. (See [here](https://github.com/crytic/building-secure-contracts/blob/master/development-guidelines/token_integration.md#erc-conformity))

On the opp. this will increase the number of token . recipient will reciveve more

guarded launch approach
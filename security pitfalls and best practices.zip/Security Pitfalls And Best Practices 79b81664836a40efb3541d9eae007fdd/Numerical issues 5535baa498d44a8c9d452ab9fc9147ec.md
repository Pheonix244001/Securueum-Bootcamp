# Numerical issues

Checkbox: No

Incorrect numerical computation will cause unexpected behavior which may lead to security issues.
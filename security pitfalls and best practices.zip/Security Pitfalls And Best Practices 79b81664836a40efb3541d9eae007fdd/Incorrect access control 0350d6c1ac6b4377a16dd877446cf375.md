# Incorrect access control

Checkbox: No
Tags: access control, modifier

Contract functions executing critical logic should have appropriate access control enforced via address checks (e.g. owner, controller etc.)

typically in modifiers. Missing checks allow attackers to control critical logic

[Access - OpenZeppelin Docs](https://docs.openzeppelin.com/contracts/3.x/api/access)

[DASP - TOP 10](https://dasp.co/#item-2)

1. we need to make sure that right access control is used by using correct modifier 
2. it might allow atttacker to control the central logic if not used properly
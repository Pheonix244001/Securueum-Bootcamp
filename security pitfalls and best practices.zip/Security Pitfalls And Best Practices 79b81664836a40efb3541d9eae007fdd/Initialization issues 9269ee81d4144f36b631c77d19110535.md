# Initialization issues

Checkbox: No
Text: check Initialization

Lack of initialization, initializing with incorrect values or allowing untrusted actors to initialize system parameters may lead to security issues.
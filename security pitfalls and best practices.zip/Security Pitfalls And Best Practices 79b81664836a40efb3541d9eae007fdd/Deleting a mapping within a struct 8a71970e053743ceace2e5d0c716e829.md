# Deleting a mapping within a struct

Checkbox: No
Tags: mapping, struct
Text: use alternative Lock vs Delete

: Deleting a *struct* that contains a *mapping*  will not delete the *mapping*
 contents which may lead to unintended consequences.

[Detector Documentation · crytic/slither Wiki](https://github.com/crytic/slither/wiki/Detector-Documentation#deletion-on-mapping-containing-a-structure)
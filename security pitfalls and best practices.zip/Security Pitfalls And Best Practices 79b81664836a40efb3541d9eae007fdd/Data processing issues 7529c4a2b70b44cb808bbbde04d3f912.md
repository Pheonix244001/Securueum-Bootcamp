# Data processing issues

Checkbox: No

Processing data incorrectly will cause unexpected behavior which may lead to security issues.
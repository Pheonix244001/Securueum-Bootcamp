# Function ID collision between proxy/implementation in proxy-based upgradeable contracts

Checkbox: No
Tags: function, proxy
Text: Rename the function. Avoid public functions in the proxy.

Malicious proxy contracts may exploit function ID collision to invoke unintended proxy functions instead of delegating to implementation functions. Check for function ID collisions.

[https://github.com/crytic/slither/wiki/Upgradeability-Checks#functions-ids-collisions](https://github.com/crytic/slither/wiki/Upgradeability-Checks#functions-ids-collisions)

[https://forum.openzeppelin.com/t/beware-of-the-proxy-learn-how-to-exploit-function-clashing/1070](https://forum.openzeppelin.com/t/beware-of-the-proxy-learn-how-to-exploit-function-clashing/1070)

```solidity
contract Contract{
    function gsf() public {
        // ...
    }
}

contract Proxy{
    function tgeo() public {
        // ...
    }
}
```

`Proxy.tgeo()` and `Contract.gsf()` have the same function id (0x67e43e43).
As a result, `Proxy.tgeo()` will shadow Contract.gsf()`.
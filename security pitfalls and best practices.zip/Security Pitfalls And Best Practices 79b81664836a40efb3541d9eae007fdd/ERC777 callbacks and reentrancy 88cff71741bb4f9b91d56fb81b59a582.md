# ERC777 callbacks and reentrancy

Checkbox: Yes
Tags: erc777, reentrancy

ERC777 tokens allow arbitrary callbacks via hooks that are called during token transfers.

Malicious contract addresses may cause reentrancy on such callbacks if reentrancy guards are not use

[How the dForce hacker used reentrancy to steal 25 million](https://quantstamp.com/blog/how-the-dforce-hacker-used-reentrancy-to-steal-25-million)
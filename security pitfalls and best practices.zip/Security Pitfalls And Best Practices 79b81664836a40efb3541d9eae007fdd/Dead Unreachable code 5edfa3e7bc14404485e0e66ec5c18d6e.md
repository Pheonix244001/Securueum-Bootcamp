# Dead/Unreachable code

Checkbox: No
Tags: dead code
Text: oppurtunity for gas optimization . use dead code or remove it

Dead code may be indicative of programmer error, missing logic or potential optimization opportunity, which needs to be flagged for removal or addressed appropriately.

[https://en.wikipedia.org/wiki/Dead_code](https://en.wikipedia.org/wiki/Dead_code)

1. code is dead but dev does not realize will be ignored . they will reduce security 
2. dead code bu dev realized . in that case they could ignore them since it is dead code 
3. mistaken identiy , dev thinks code is dead and removes it
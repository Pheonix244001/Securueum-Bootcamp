# assert()/require() state change

Checkbox: No
Tags: assert, require
Text: Consider whether the condition checked in the assert() is actually an invariant. If not, replace the assert() statement with a require() statement.

Invariants in *assert()*
 and *require()*
 statements should not modify the state per best practices

[SWC-110 · Overview](https://swcregistry.io/docs/SWC-110)

[The use of revert(), assert(), and require() in Solidity, and the new REVERT opcode in the EVM](https://media.consensys.net/when-to-use-revert-assert-and-require-in-solidity-61fb2c0e5a57)
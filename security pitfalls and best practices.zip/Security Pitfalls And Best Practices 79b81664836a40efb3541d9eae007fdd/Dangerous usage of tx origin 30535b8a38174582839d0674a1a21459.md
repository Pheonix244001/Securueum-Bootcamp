# Dangerous usage of tx.origin

Checkbox: No
Tags: msg.sender, tx.origin
Text: Use msg.sender instead

Use of *tx.origin*
 for authorization may be abused by a MITM malicious contract forwarding calls from the legitimate user who interacts with it.

Use *msg.sender*
 instead.

[SWC-115 · Overview](https://swcregistry.io/docs/SWC-115)
# Dangerous shadowing

Checkbox: No

Local variables, state variables, functions, modifiers, or events 
with names that shadow (i.e. override) builtin Solidity symbols e.g. *now* 
or other declarations from the current scope are misleading and may lead to unexpected usages and behavior

[Detector Documentation · crytic/slither Wiki](https://github.com/crytic/slither/wiki/Detector-Documentation#builtin-symbol-shadowing)
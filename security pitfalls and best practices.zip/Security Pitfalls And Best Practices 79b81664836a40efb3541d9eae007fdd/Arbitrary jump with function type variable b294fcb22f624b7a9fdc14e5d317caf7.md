# Arbitrary jump with function type variable

Checkbox: No
Tags: function
Text: The use of assembly should be minimal. A developer should not allow a user to assign arbitrary values to function type variables.

****
Function type variables should be carefully handled and avoided in assembly manipulations to prevent jumps to arbitrary code locations.

[https://swcregistry.io/docs/SWC-127](https://swcregistry.io/docs/SWC-127)

The problem arises when a user has the ability to arbitrarily 
change the function type variable and thus execute random code 
instructions. As Solidity doesn't support pointer arithmetics, it's 
impossible to change such variable to an arbitrary value. However, if 
the developer uses assembly instructions, such as `mstore`
 or
 assign operator, in the worst case scenario an attacker is able to 
point a function type variable to any code instruction, violating 
required validations and required state changes.

[Types - Solidity 0.4.25 documentation](https://docs.soliditylang.org/en/v0.4.25/types.html#function-types)
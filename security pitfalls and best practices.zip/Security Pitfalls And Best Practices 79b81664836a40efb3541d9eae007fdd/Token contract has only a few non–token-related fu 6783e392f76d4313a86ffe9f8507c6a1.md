# Token contract has only a few non–token-related functions

Checkbox: No
Tags: erc20, non token
Text: avoid non-token related functions

Non–token-related functions increase the likelihood of an issue in the contract. (See [here](https://github.com/crytic/building-secure-contracts/blob/master/development-guidelines/token_integration.md#contract-composition))

erc20 contract should
only or mostly have functions that are
relevant to erc20 tokens they should not
include any non-token related functions
in that contract

 that will increase complexity
# Dynamic array cleanup

Checkbox: No
Tags: array
Text: latest bug in 0.7 , fixed

When assigning a dynamically sized array with types of size at 
most 16 bytes in storage causing the assigned array to shrink, some 
parts of deleted slots were not zeroed out. This is due to a compiler 
bug fixed in *v0.7.3*
.

[https://docs.soliditylang.org/en/v0.8.9/bugs.html](https://docs.soliditylang.org/en/v0.8.9/bugs.html)
# Token is not upgradeable

Checkbox: No
Tags: erc20, upgradeable
Text: make sure that token are not upgradable .

Upgradeable contracts might change their rules over time. (See [here](https://github.com/crytic/building-secure-contracts/blob/master/development-guidelines/token_integration.md#owner-privileges))

 when it comes to erc20 token contracts upgradability is a concern and the reason is because any change in
functionality that is introduced by this credibility is detrimental to the trust that the users place in these contracts
and the rationale is that these token functions in this contract
are meant to be very simple

the mint burn and transfer
functions
are required to adhere to the
specifications so that all the contracts
or all the users interacting with this
token contract
are assured of the functionality
implemented by these functions
# Guarded launch via usage limits

Checkbox: No
Tags: guarded launch, usage limit
Text: usage is limited upon launch

Enforcing transaction size limits, daily volume limits, 
per-account limits, or rate-limiting transactions may reduce impact due 
to initial vulnerabilities or exploits. (See [here](https://medium.com/electric-capital/derisking-defi-guarded-launches-2600ce730e0a#:~:text=Guarded%20Launches:%20Protecting%20Users%20with%20Limits&text=A%20new%20contract%20is%20deployed,product%20in%20a%20limited%20scope.))
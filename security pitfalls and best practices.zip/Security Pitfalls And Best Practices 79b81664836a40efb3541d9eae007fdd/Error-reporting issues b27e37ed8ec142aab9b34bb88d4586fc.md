# Error-reporting issues

Checkbox: No
Text: ensure sufficient error reporting

Incorrect or insufficient detecting, reporting and handling of error conditions will cause exceptional behavior to go unnoticed which may lead to security issues.
# Insufficient gas griefing

Checkbox: No
Tags: gas

Transaction relayers need to be trusted to provide enough gas for the transaction to succeed.

[https://swcregistry.io/docs/SWC-126](https://swcregistry.io/docs/SWC-126)

[What does griefing mean?](https://ethereum.stackexchange.com/questions/62829/what-does-griefing-mean)

[Griefing Attacks: Are they profitable for the attacker?](https://ethereum.stackexchange.com/questions/73261/griefing-attacks-are-they-profitable-for-the-attacker)
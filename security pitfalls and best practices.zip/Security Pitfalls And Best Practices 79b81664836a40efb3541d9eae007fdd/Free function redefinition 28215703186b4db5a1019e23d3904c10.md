# Free function redefinition

Checkbox: No
Tags: function
Text: bug 0.7 , fixed

The compiler does not flag an error when two or more free 
functions (functions outside of a contract) with the same name and 
parameter types are defined in a source unit or when an imported free 
function alias shadows another free function with a different name but 
identical parameter types. This is due to a compiler bug introduced in *v0.7.1*
 and fixed in *v0.7.2*
.

[https://docs.soliditylang.org/en/v0.8.9/bugs.html](https://docs.soliditylang.org/en/v0.8.9/bugs.html)
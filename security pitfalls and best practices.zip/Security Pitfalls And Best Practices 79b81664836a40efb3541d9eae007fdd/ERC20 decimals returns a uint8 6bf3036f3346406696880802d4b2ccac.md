# ERC20 decimals returns a uint8

Checkbox: No
Tags: erc20, uint
Text: check which type is being used by contract if uint256 is used then make sure that the decimal value is  ≤ 255

Several tokens incorrectly return a uint256. If this is the case, ensure the value returned is below 255. (See [here](https://github.com/crytic/building-secure-contracts/blob/master/development-guidelines/token_integration.md#erc-conformity)
)
# Principle of Psychological Acceptability

Checkbox: No

“It is essential that the human interface be designed for ease of 
use, so that users routinely and automatically apply the protection 
mechanisms correctly” — Ensure that security aspects of smart contract 
interfaces and system designs/flows are user-friendly and intuitive so 
that users can interact with minimal risk. (See [Saltzer and Schroeder's Secure Design Principles](https://en.wikipedia.org/wiki/Saltzer_and_Schroeder's_design_principles))
# Incorrect shift in assembly

Checkbox: No
Tags: assembly
Text: check for shift operation in solidity assembly

Shift operators (*shl(x, y)*,[shift left] *shr(x, y)*,[shift right] *sar(x, y)[shift arithmatic right]* ) 

in Solidity assembly apply the shift operation of *x* bits on *y* and not the other way around, which may be confusing. Shifts y by x bits and not the other way around

Check if the values in a shift operation are reversed.

[https://github.com/crytic/slither/wiki/Detector-Documentation#incorrect-shift-in-assembly](https://github.com/crytic/slither/wiki/Detector-Documentation#incorrect-shift-in-assembly)
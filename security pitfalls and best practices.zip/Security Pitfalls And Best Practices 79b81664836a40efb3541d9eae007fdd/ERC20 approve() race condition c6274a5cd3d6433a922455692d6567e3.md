# ERC20 approve() race condition

Checkbox: No
Tags: erc20, frontrunning, race condition
Text: safeApprove depricated , use safeIncreaseAllowance()

****
Use *safeIncreaseAllowance()* and *safeDecreaseAllowance()* from OpenZeppelin’s *SafeERC20*
 implementation to prevent race conditions from manipulating the allowance amounts

[SWC-114 · Overview](https://swcregistry.io/docs/SWC-114)

## Remediation

A possible way to remedy for race conditions in submission of 
information in exchange for a reward is called a commit reveal hash 
scheme. Instead of submitting the answer the party who has the answer 
submits hash(salt, address, answer) [salt being some number of their 
choosing] the contract stores this hash and the sender's address. To 
claim the reward the sender then submits a transaction with the salt, 
and answer. The contract hashes (salt, msg.sender, answer) and checks 
the hash produced against the stored hash, if the hash matches the 
contract releases the reward.

The best fix for the ERC20 race condition is to add a field to the 
inputs of approve which is the expected current value and to have 
approve revert if Eve's current allowance is not what Alice indicated 
she was expecting. However this means that your contract no longer 
conforms to the ERC20 standard. If it important to your project to have 
the contract conform to ERC20, you can add a safe approve function. From
 the user perspective it is possible to mediate the ERC20 race condition
 by setting approvals to zero before changing them.
# Empty byte array copy

Checkbox: No
Tags: array
Text: 0.7 bug , fixed

Copying an empty byte array (or string) from memory or calldata to
 storage can result in data corruption if the target array's length is 
increased subsequently without storing new data. This is due to a 
compiler bug fixed in *v0.7.4*
.

[https://docs.soliditylang.org/en/v0.8.9/bugs.html](https://docs.soliditylang.org/en/v0.8.9/bugs.html)
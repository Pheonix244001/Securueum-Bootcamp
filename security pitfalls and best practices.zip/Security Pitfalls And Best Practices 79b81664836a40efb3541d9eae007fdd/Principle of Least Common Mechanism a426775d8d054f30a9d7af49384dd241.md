# Principle of Least Common Mechanism

Checkbox: No

“Minimize the amount of mechanism common to more than one user and
 depended on by all users” — Ensure that only the least number of 
security-critical modules/paths as required are shared amongst the 
different actors/code so that impact from any vulnerability/compromise 
in shared components is limited and contained to the smallest possible 
subset. (See [Saltzer and Schroeder's Secure Design Principles](https://en.wikipedia.org/wiki/Saltzer_and_Schroeder's_design_principles))
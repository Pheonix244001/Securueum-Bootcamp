# Missing events

Checkbox: No
Tags: events
Text: add events where critical operation are happening

Events for critical state changes (e.g. owner and other critical parameters) should be emitted for tracking this off-chain.

[Detector Documentation · crytic/slither Wiki](https://github.com/crytic/slither/wiki/Detector-Documentation#missing-events-access-control)
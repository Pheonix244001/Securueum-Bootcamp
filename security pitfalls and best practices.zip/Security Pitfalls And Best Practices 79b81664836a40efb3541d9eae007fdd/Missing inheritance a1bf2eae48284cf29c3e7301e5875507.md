# Missing inheritance

Checkbox: No
Tags: inheritance

A contract might appear (based on name or functions implemented) to inherit from another interface or abstract contract without actually doing so

[https://github.com/crytic/slither/wiki/Detector-Documentation#missing-inheritance](https://github.com/crytic/slither/wiki/Detector-Documentation#missing-inheritance)
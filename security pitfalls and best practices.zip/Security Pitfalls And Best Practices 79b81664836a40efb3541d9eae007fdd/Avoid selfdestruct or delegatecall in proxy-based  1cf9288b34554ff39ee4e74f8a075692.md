# Avoid selfdestruct or delegatecall in proxy-based upgradeable contracts

Checkbox: No
Tags: delegatecall, proxy, selfdestruct
Text: parity hack

This will cause the logic contract to be destroyed and all contract instances will end up delegating calls to an address without any code.

[https://docs.openzeppelin.com/upgrades-plugins/1.x/writing-upgradeable#potentially-unsafe-operations](https://docs.openzeppelin.com/upgrades-plugins/1.x/writing-upgradeable#potentially-unsafe-operations)
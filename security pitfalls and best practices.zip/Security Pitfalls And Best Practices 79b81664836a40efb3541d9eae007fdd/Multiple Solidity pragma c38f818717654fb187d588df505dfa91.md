# Multiple Solidity pragma

Checkbox: No
Tags: version

use one Solidity compiler version across all contracts instead of different versions with different bugs and security checks.

[Detector Documentation · crytic/slither Wiki](https://github.com/crytic/slither/wiki/Detector-Documentation#different-pragma-directives-are-used)
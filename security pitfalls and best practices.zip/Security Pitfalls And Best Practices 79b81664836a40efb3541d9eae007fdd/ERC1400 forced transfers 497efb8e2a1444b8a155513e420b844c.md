# ERC1400 forced transfers

Checkbox: No
Tags: erc1400
Text: Unbounded transfer

Trusted actors have the ability to transfer funds however they choose. (See [here](https://gist.github.com/shayanb/cd495e23c7cf1a8b269f8ce7fd198538#file-token_checklist-md))
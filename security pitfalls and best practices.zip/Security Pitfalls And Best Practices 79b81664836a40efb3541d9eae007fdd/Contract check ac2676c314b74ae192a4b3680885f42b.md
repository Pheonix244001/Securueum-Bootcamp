# Contract check

Checkbox: No
Tags: extcodesize
Text: Avoid using extcodesize to check for Externally Owned Accounts.

Checking if a call was made from an Externally Owned Account (EOA) or a contract account is typically done using *extcodesize*
 check which may be circumvented by a contract during construction when it does not have source code available.

Checking if *tx.origin == msg.sender* 
is another option. Both have implications that need to be considered.

[Solidity Best Practices for Smart Contract Security | ConsenSys](https://consensys.net/blog/blockchain-development/solidity-best-practices-for-smart-contract-security/)

[EXTCODESIZE Checks - Ethereum Smart Contract Best Practices](https://consensys.github.io/smart-contract-best-practices/development-recommendations/solidity-specific/extcodesize-checks/)

The idea is straightforward: if an address contains code, it's not an EOA but a contract account.
However, **a contract does not have source code available during construction**
. This means that
while the constructor is running, it can make calls to other contracts, but `extcodesize`
 for its
address returns zero. Below is a minimal example that shows how this check can be circumvented:
# Block values as time proxies

Checkbox: No
Tags: block.timestamp
Text: dont use block.timestamp

*****block.timestamp*
 and *block.number* 
are
 not good proxies (i.e. representations, not to be confused with smart 
contract proxy/implementation pattern) for time because of issues with 
synchronization, miner manipulation and changing block times

[SWC-116 · Overview](https://swcregistry.io/docs/SWC-116)
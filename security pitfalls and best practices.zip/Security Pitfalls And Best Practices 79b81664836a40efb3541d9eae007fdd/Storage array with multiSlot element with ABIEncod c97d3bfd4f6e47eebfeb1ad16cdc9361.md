# Storage array with multiSlot element with ABIEncoderV2

Checkbox: No
Tags: abi
Text: fixed

Storage arrays containing structs or other statically sized arrays
 are not read properly when directly encoded in external function calls 
or in *abi.encode()*
.

This is due to a compiler bug introduced in *v0.4.16*
 and fixed in *v0.5.10*
.

[https://docs.soliditylang.org/en/v0.8.9/bugs.html](https://docs.soliditylang.org/en/v0.8.9/bugs.html)
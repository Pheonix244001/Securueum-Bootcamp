# ERC20 transfer() does not return boolean

Checkbox: No
Tags: erc20, transfer()
Text: use SafeERC20

Contracts compiled with *solc >= 0.4.22*
 interacting with such functions will revert.

Use OpenZeppelin’s SafeERC20 wrappers

[Detector Documentation · crytic/slither Wiki](https://github.com/crytic/slither/wiki/Detector-Documentation#incorrect-erc20-interface)

[Missing return value bug - At least 130 tokens affected](https://medium.com/coinmonks/missing-return-value-bug-at-least-130-tokens-affected-d67bf08521ca)
# Undefined behavior issues

Checkbox: No

Any behavior that is undefined in the specification but is allowed in the implementation will result in unexpected outcomes which may lead to security issues.
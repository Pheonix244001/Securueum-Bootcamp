# Critical address change

Checkbox: No
Tags: address
Text: Reg. New address then replace the old address

Changing critical addresses in contracts should be a two-step process where the first transaction (from the old/current address) registers the new address (i.e. grants ownership) and the second transaction (from the new address) replaces the old address with the new one (i.e. claims ownership).

This gives an opportunity to recover from incorrect addresses mistakenly used in the first step. If not, contract functionality might become inaccessible.

[https://github.com/OpenZeppelin/openzeppelin-contracts/issues/1488](https://github.com/OpenZeppelin/openzeppelin-contracts/issues/1488)

[https://github.com/OpenZeppelin/openzeppelin-contracts/issues/2369](https://github.com/OpenZeppelin/openzeppelin-contracts/issues/2369)
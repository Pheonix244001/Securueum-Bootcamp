# Guarded launch via asset types

Checkbox: No
Tags: asset types, guarded launch
Text: Launch with few asset type and overtime increase

****Limiting types of assets that can be used in the
 protocol initially upon launch and gradually expanding to other assets 
over time may reduce impact due to initial vulnerabilities or exploits. 
(See [here](https://medium.com/electric-capital/derisking-defi-guarded-launches-2600ce730e0a#:~:text=Guarded%20Launches:%20Protecting%20Users%20with%20Limits&text=A%20new%20contract%20is%20deployed,product%20in%20a%20limited%20scope.))

launch known assets first that are securely recognized
# Unindexed event parameters

Checkbox: No
Tags: erc20, events
Text: Add the indexed keyword to event parameters that should include it, according to the ERC20 specification.

Parameters of certain events are expected to be indexed (e.g. ERC20 Transfer/Approval events) so that they’re included in the block’s bloom filter for faster access.

Failure to do so might confuse off-chain tooling looking for such indexed events.

[Detector Documentation](https://github.com/crytic/slither/wiki/Detector-Documentation#unindexed-erc20-event-parameters)
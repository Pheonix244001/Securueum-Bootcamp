# ERC20 approve race-condition

Checkbox: No
Tags: erc20, race condition
Text: use increae/decrease allowance

The ERC20 standard has a known ERC20 race condition that must be mitigated to prevent attackers from stealing tokens. (See [here](https://github.com/ethereum/EIPs/issues/20#issuecomment-263524729))
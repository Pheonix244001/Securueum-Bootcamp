# Implicit constructor callValue check

Checkbox: No
Tags: constructor, inheritance

~~The creation code of a contract that does not define a constructor but has a base (inheritance / derived ) that does, did not revert for calls with non-zero callValue when such a constructor was not explicitly payable~~ 

# REPHRASE

- lets say there are 2 contracts A and B and lets says that B is the derived contract from A   ( contract B is A )
- Now lets say that A has a defined constructor and B does not have a defined constructor
- In a logical scenario , if we send a non-zero callValue ( some amout of ether attached to the call ) the creation code ( *the code that is executed when a new contract is being created.* ) that of contract B should give an error because the inheritied constructor of A is non payable by default
- Note - a constructor is payable marked if it needs some ether at the time of contract initialization .

[creation code more info](Implicit%20constructor%20callValue%20check%20378c919888654e379269a13320444827/creation%20code%20more%20info%20d45f3a01fc4746ae9012758c69c3c459.md)

- But this doesn’t happen until we mark A’s constructor as payable .

This is due to a compiler bug introduced in *v0.4.5* and fixed in *v0.6.8*

 Starting from Solidity 0.4.5 the creation code of contracts without 
explicit payable constructor is supposed to contain a callvalue check 
that results in contract creation reverting, if non-zero value is passed

However, this check was missing in case no explicit constructor was defined in a contract at all, but the contract has a base that does define a constructor. In these cases it is possible to send value in a contract creation transaction or using inline assembly without revert, even though the creation code is supposed to be non-payable

[List of Known Bugs - Solidity 0.8.9 documentation](https://docs.soliditylang.org/en/v0.8.9/bugs.html)
# Avoid transfer()/send() as reentrancy mitigations

Checkbox: Yes

Although *transfer()*
 and *send()*

 have been recommended as a security best-practice to prevent reentrancy
 attacks because they only forward 2300 gas, the gas repricing of 
opcodes may break deployed contracts

Use *call()*
 instead, without hardcoded gas 
limits along with checks-effects-interactions pattern or reentrancy 
guards for reentrancy protection.

[Stop Using Solidity's transfer() Now | ConsenSys Diligence](https://consensys.net/diligence/blog/2019/09/stop-using-soliditys-transfer-now/)

[SWC-134 · Overview](https://swcregistry.io/docs/SWC-134)

Avoid the use of `transfer()`
 and `send()`
 and do not otherwise specify a fixed amount of gas when performing calls. Use `.call.value(...)("")`
 instead. Use the checks-effects-interactions pattern and/or reentrancy locks to prevent reentrancy attacks.
# Memory array creation overflow

Checkbox: No
Tags: array
Text: fixed

The creation of very large memory arrays can result in overlapping
 memory regions and thus memory corruption. This is due to a compiler 
bug introduced in *v0.2.0*
 and fixed in *v0.6.5*
.

[https://solidity.ethereum.org/2020/04/06/memory-creation-overflow-bug/](https://solidity.ethereum.org/2020/04/06/memory-creation-overflow-bug/)
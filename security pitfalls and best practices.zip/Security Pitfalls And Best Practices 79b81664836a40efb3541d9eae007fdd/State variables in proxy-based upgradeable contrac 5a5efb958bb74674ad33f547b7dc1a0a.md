# State variables in proxy-based upgradeable contracts

Checkbox: No
Tags: proxy, state variables
Text: same → order/layout/type/mutability

The declaration order/layout and type/mutability of state variables in such contracts should be preserved exactly while upgrading to prevent critical storage layout mismatch errors

[https://docs.openzeppelin.com/upgrades-plugins/1.x/writing-upgradeable#modifying-your-contracts](https://docs.openzeppelin.com/upgrades-plugins/1.x/writing-upgradeable#modifying-your-contracts)

in the proxy and the corresponding implementation or different versions of the
implementation should be preserved exactly while upgrading to prevent storage
layout mismatch errors
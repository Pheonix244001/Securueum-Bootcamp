# Token owner cannot blacklist the contract

Checkbox: Yes
Tags: blacklist, erc20
Text: Cannot Blacklist

Malicious or compromised owners can trap contracts relying on tokens with a blacklist. (See [here](https://github.com/crytic/building-secure-contracts/blob/master/development-guidelines/token_integration.md#owner-privileges))

Owner → Malicious 

can trap funds
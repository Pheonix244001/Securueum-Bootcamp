# Modifier side-effects

Checkbox: No
Tags: modifier, reentrancy

****
Modifiers should only implement checks and not make state changes and external calls violates the [checks-effects-interactions](https://solidity.readthedocs.io/en/develop/security-considerations.html#use-the-checks-effects-interactions-pattern) pattern

These side-effects may go unnoticed by developers/auditors because the modifier code is typically far from the function implementation.

[Solidity Best Practices for Smart Contract Security | ConsenSys](https://consensys.net/blog/developers/solidity-best-practices-for-smart-contract-security/)

Most functions will first perform some checks (who called the function, are the arguments in range, did they send enough Ether, does the person have tokens, etc.). These checks should be done first.

As the second step, if all checks passed, effects to the state variables of the current contract should be made. Interaction with other contracts should be the very last step in any function.

****
Use [modifiers](https://solidity.readthedocs.io/en/develop/contracts.html#function-modifiers) to replace duplicate condition checks in multiple functions, such as `isOwner()`
, otherwise use `require`or `revert` inside the function. This makes your smart contract code more readable and easier to audit.

---

meds

[https://github.com/code-423n4/2021-07-spartan-findings/issues/172](https://github.com/code-423n4/2021-07-spartan-findings/issues/172)

other reports include either reentrancy due to no or incorrect use of modifier or the modifier has some logic flaw 

## Incorrect use of modifier is creating a logic flaw in smart contracts . Reentrancy is the most common threat

Recommended Mitigation steps mostly include 

1. adding non reentrant modifier 
2. adding a modifier accordingly 

We also have to make sure that modifier used should revert flow accordingly 

Add `nonReentrant` modifier to `withdrawToken()`

the isDisaster modifier to revert when price of a pegged asset is equal to the strike price of a Vault

The lock modifier guards against reentrancy but not against cross function reentrancy.also violates the Checks Effects Interactions best practices further widening the attack surface.
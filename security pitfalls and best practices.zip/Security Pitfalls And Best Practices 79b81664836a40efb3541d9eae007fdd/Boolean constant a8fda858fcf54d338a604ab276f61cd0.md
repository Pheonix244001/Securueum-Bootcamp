# Boolean constant

Checkbox: No
Tags: bool
Text: Use of Boolean Constant within conditional is flawed logic

: Use of Boolean constants (*true*
/*false*
) in code (e.g. conditionals) is indicative of flawed logic.

[Detector Documentation · crytic/slither Wiki](https://github.com/crytic/slither/wiki/Detector-Documentation#misuse-of-a-boolean-constant)
# Guarded launch via composability limits

Checkbox: No
Tags: guarded launch
Text: gradual increase of exposure with other apps

Restricting the composability of the system to interface only with
 whitelisted trusted contracts before expanding to arbitrary external 
contracts may reduce impact due to initial vulnerabilities or exploits. 
(See [here](https://medium.com/electric-capital/derisking-defi-guarded-launches-2600ce730e0a#:~:text=Guarded%20Launches:%20Protecting%20Users%20with%20Limits&text=A%20new%20contract%20is%20deployed,product%20in%20a%20limited%20scope.))
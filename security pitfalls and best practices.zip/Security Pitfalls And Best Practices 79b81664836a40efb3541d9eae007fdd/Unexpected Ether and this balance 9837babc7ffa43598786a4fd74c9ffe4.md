# Unexpected Ether and this.balance

Checkbox: Yes
Tags: erc20, payable, selfdestruct

A contract can receive Ether via *payable*
 functions, *selfdestruct(), coinbase*  transaction or pre-sent before creation

Contract logic depending on *this.balanc*e can therefore be manipulated.

[GitHub - sigp/solidity-security-blog: Comprehensive list of known attack vectors and common anti-patterns](https://github.com/sigp/solidity-security-blog#3-unexpected-ether-1)

[SWC-132 · Overview](https://swcregistry.io/docs/SWC-132)

[How to Secure Your Smart Contracts: 6 Solidity Vulnerabilities and how to avoid them (Part 2)](https://medium.com/loom-network/how-to-secure-your-smart-contracts-6-solidity-vulnerabilities-and-how-to-avoid-them-part-2-730db0aa4834)

[Solidity security patterns - forcing ether to a contract](http://danielszego.blogspot.com/2018/03/solidity-security-patterns-forcing.html)

[Security Considerations - Solidity 0.8.17 documentation](https://docs.soliditylang.org/en/develop/security-considerations.html#sending-and-receiving-ether)

[Gridlock (a smart contract bug)](https://medium.com/@nmcl/gridlock-a-smart-contract-bug-73b8310608a9)

[Solidity Security: Comprehensive list of known attack vectors and common anti-patterns](https://blog.sigmaprime.io/solidity-security.html#ether)

Contracts which rely on code execution for every ether sent to the contract can be vulnerable to attacks where ether is forcibly sent to a contract.

A contract without a receive Ether function can receive Ether as a
recipient of a *coinbase transaction* (aka *miner block reward*)
or as a destination of a `selfdestruct`.

A contract cannot react to such Ether transfers and thus also
cannot reject them. This is a design choice of the EVM and
Solidity cannot work around it.

It also means that `address(this).balance` can be higher
than the sum of some manual accounting implemented in a
contract (i.e. having a counter updated in the receive Ether function).
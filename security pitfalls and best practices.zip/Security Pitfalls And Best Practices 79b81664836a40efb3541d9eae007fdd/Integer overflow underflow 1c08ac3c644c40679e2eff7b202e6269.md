# Integer overflow/underflow

Checkbox: No

Not using OpenZeppelin’s SafeMath (or similar libraries) that check for overflows/underflows may lead to vulnerabilities or unexpected behavior if user/attacker can control the integer operands of such arithmetic operations.

*Solc v0.8.0*
 introduced default overflow/underflow checks for all arithmetic operations

[SWC-101 · Overview](https://swcregistry.io/docs/SWC-101)

[Solidity 0.8.x Preview Release](https://blog.soliditylang.org/2020/10/28/solidity-0.8.x-preview/)
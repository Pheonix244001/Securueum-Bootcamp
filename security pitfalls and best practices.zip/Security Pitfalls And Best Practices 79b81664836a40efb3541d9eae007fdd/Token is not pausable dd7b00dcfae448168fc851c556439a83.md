# Token is not pausable

Checkbox: No
Tags: erc20, guarded launch, pause

Malicious or compromised owners can trap contracts relying on pausable tokens. (See [here](https://github.com/crytic/building-secure-contracts/blob/master/development-guidelines/token_integration.md#owner-privileges))
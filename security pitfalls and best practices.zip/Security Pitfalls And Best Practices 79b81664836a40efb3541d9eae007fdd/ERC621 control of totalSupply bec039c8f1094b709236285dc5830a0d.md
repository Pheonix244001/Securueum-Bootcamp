# ERC621 control of totalSupply

Checkbox: No
Tags: erc621
Text: Token Supply Risk

totalSupply can be changed by trusted actors (See [here](https://gist.github.com/shayanb/cd495e23c7cf1a8b269f8ce7fd198538#file-token_checklist-md))
# Out-of-range enum

Checkbox: No
Tags: enum
Text: out of range enum - compiler , it is fixed

*****Solc < 0.4.5* 
produced unexpected behavior with out-of-range enums*.*

Check enum conversion or use a newer compiler.

[https://github.com/crytic/slither/wiki/Detector-Documentation#dangerous-enum-conversion](https://github.com/crytic/slither/wiki/Detector-Documentation#dangerous-enum-conversion)
# Constant state variables

Checkbox: No
Tags: constant, state variables
Text: unchanged state variable should be declared as constant

Constant state variables should be declared constant to save gas.

[https://github.com/crytic/slither/wiki/Detector-Documentation#state-variables-that-could-be-declared-constant](https://github.com/crytic/slither/wiki/Detector-Documentation#state-variables-that-could-be-declared-constant)
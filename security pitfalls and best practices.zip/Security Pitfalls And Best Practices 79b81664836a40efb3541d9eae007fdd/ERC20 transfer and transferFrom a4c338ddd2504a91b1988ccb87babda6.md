# ERC20 transfer and transferFrom

Checkbox: No
Tags: bool, erc20
Text: Use safeErc20

If not returned , callers that assume the returned boolean value may fail
# Unprotected initializers in proxy-based upgradeable contracts

Checkbox: No
Tags: proxy
Text: use openzeppelin initializable lib.

Proxy-based upgradeable contracts need to use *public*

 initializer functions instead of constructors that need to be 
explicitly called only once. Preventing multiple invocations of such 
initializer functions (e.g. via *initializer*
 modifier from OpenZeppelin’s *Initializable*
 library) is a must.

[https://docs.openzeppelin.com/upgrades-plugins/1.x/writing-upgradeable#initializers](https://docs.openzeppelin.com/upgrades-plugins/1.x/writing-upgradeable#initializers)

[https://github.com/crytic/slither/wiki/Upgradeability-Checks#initializer-is-not-called](https://github.com/crytic/slither/wiki/Upgradeability-Checks#initializer-is-not-called)

Due to a requirement of the proxy-based upgradeability system, no constructors can be used in upgradeable contracts. 

However, while Solidity ensures that a `constructor`
 is called only once in the lifetime of a contract, a regular function can 
be called many times. To prevent a contract from being *initialized*
 multiple times, you need to add a check to ensure the `initialize`
 function is called only once:

Another difference between a `constructor`
 and a regular 
function is that Solidity takes care of automatically invoking the 
constructors of all ancestors of a contract. When writing an 
initializer, you need to take special care to manually call the 
initializers of all parent contracts. Note that the `initializer`
 modifier can only be called once even when using inheritance, so parent contracts should use the `onlyInitializing`
 modifier:
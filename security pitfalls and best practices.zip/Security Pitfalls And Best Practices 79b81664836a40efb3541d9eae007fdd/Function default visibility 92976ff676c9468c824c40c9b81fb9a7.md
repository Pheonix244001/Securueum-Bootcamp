# Function default visibility

Checkbox: No
Tags: function
Text: mention the visibility of a function explicitly

Functions without a visibility type specifier are *public*
 by default in *solc < 0.5.0*
.

This can lead to a vulnerability where a malicious user may make unauthorized state changes. *solc >= 0.5.0*
 requires explicit function visibility specifiers.

[SWC-100 · Overview](https://swcregistry.io/docs/SWC-100)

[GitHub - sigp/solidity-security-blog: Comprehensive list of known attack vectors and common anti-patterns](https://github.com/sigp/solidity-security-blog#visibility)
# Function parameters

Checkbox: No
Tags: function
Text: Input validation of every function param should be done specially if public

Ensure input validation for all function parameters especially if the visibility is external/public where (untrusted) users can control values. This is especially required for address parameters where maliciously/accidentally used incorrect/zero addresses can cause vulnerabilities or unexpected behavior.
# Uninitialized state/local variables

Checkbox: No
Tags: address, bool
Text: state and local variables should be initialized with reasonable values

Uninitialized state/local variables are assigned zero values by the compiler and may cause unintended results e.g. transferring tokens to zero address.

Explicitly initialize all state/local variables.

[https://github.com/crytic/slither/wiki/Detector-Documentation#uninitialized-state-variables](https://github.com/crytic/slither/wiki/Detector-Documentation#uninitialized-state-variables)

[https://github.com/crytic/slither/wiki/Detector-Documentation#uninitialized-local-variables](https://github.com/crytic/slither/wiki/Detector-Documentation#uninitialized-local-variables)

Uninitialized variables as a default value of zero 

this can end up as zero address in case of uninitialzied address variable and false in case of bool
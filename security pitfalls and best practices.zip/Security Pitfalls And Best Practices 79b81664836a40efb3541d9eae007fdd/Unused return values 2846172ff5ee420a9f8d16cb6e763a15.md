# Unused return values

Checkbox: No
Tags: return, variable
Text: Ensure that all the return values of the function calls are used.

Unused return values of function calls are indicative of programmer errors which may have unexpected behavior.

[https://github.com/crytic/slither/wiki/Detector-Documentation#unused-return](https://github.com/crytic/slither/wiki/Detector-Documentation#unused-return)
# Access control specification

Checkbox: No
Tags: access control
Text: Should be specified in great detail

Ensure that the various system actors, their access control privileges and trust assumptions are accurately specified in great detail so that they are correctly implemented and enforced across different contracts, functions and system transitions/flows.
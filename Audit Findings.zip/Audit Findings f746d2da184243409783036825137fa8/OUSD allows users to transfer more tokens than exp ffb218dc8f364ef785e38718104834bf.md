# OUSD allows users to transfer more tokens than expected

Checkbox: No
Linked to : spbp[158 169 170]
Problem: user could tranfer more token then it has due to rounding issue
Recommendation: make sure that the balances are correctly checked before arithmetic is performed 
Tags: data validation

[publications/OriginDollar.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/OriginDollar.pdf)

**Eve interacts with the OUSD token, trying to transfer more tokens that she has. Instead of failing, the transaction succeeds, allowing it to credit more tokens than expected to another account.**

This issue seems to be caused by a rounding issue when the creditsDeducted is calculated

and subtracted:

```solidity
function _executeTransfer(
address _from,
address _to,
uint256 _value
) internal {

bool isNonRebasingTo = _isNonRebasingAccount(_to);

bool isNonRebasingFrom = _isNonRebasingAccount(_from);

// Credits deducted and credited might be different due to the

// differing creditsPerToken used by each account

uint256 creditsCredited = _value.mulTruncate(_creditsPerToken(_to));

uint256 creditsDeducted = _value.mulTruncate(_creditsPerToken(_from));

_creditBalances[_from] = _creditBalances[_from].sub(

creditsDeducted,

"Transfer amount exceeds balance"

);

_creditBalances[_to] = _creditBalances[_to].add(creditsCredited);

...
```
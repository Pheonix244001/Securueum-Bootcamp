# GenesisGroup.commit overwrites previously-committed values

Checkbox: No
Problem: Commit function was overwriting previous commits
Recommendation: Ensure the committed amount is added to the existing commitment.
Tags: logic

[Fei Protocol | ConsenSys Diligence](https://consensys.net/diligence/audits/2021/01/fei-protocol/#genesisgroupcommit-overwrites-previously-committed-values)

The amount stored in the recipient’s *committedFGEN* balance overwrites any previously-committed value. Additionally, this  also allows anyone to commit an amount of “0” to any account, deleting 
their commitment entirely.
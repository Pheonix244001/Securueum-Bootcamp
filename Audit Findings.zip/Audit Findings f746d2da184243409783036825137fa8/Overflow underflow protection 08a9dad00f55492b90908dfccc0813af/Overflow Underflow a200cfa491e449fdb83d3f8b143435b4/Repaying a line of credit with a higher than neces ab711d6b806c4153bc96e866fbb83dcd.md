# Repaying a line of credit with a higher than necessary claimed revenue amount will force the borrower into liquidation

Checkbox: No
URL: https://github.com/code-423n4/2022-11-debtdao-findings/issues/461

thinking , what will happen if I pay more amount than needed 

as soon as he thought of this , he found underflow 

codebase understanding . which function is doing what
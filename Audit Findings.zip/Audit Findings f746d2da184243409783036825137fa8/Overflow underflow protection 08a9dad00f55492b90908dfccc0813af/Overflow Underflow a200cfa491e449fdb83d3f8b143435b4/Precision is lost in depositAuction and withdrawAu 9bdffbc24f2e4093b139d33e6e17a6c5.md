# Precision is lost in depositAuction and withdrawAuction user amount due calculations

Checkbox: No
URL: https://github.com/sherlock-audit/2022-11-opyn-judging/issues/201

underflow situation 

checking the formula used and determing the use cases in case of different decimals or correctness of formula

codebase understanding 

what the codebase is doing , how is it doing that 

what are the different variables being used
# Variable shadowing from OUSD to ERC20

Checkbox: No
Linked to : sol [  106 136 ] spbp [ 188 ]  
Problem: OUSD inherits from ERC20 but redefines allowance and total supply so accessign those could leas to differenrt values from what expected . dev clarity <<
Recommendation: remove shadowed variables 
Tags: undefined behaviour

[publications/OriginDollar.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/OriginDollar.pdf)

OUSD inherits from ERC20, but redefines the _ *allowances* and _ *totalSupply* state variables. As a result, access to these variables can lead to returning different values.

1. Recommendation: Remove the shadowed variables (_ *allowances* and _ *totalSupply*) in OUSD.
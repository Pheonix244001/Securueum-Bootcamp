# Whitelisted tokens limit

Checkbox: No
Linked to : spbp [142 44 176 182]
Problem: interation over all whitelisited tokens , if too big can make function run out of gas 
Recommendation: limiting the number of whitelisted tokens or add function that removes the token from whitelist
Tags: dos

[The LAO | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/01/the-lao/#emergency-processing-can-be-blocked)

mitigated by having separate limits for number of whitelisted tokens (for non-zero balance and for zero balance) in [486f1b3](https://github.com/MolochVentures/moloch/commit/486f1b3e72c8e48f614c3b22a0220de63b5320bd)
 and follow up commits. That’s helpful because it’s much cheaper to 
process tokens with zero balance in the guild bank and you can have much
 more whitelisted tokens overall.

```solidity
uint256 constant MAX_TOKEN_WHITELIST_COUNT = 400; // maximum number of whitelisted tokens
uint256 constant MAX_TOKEN_GUILDBANK_COUNT = 200; // maximum number of tokens with non-zero balance in guildbank
uint256 public totalGuildBankTokens = 0; // total tokens with non-zero balance in guild bank
```

It should be noted that this is an estimated limit based on the [manual calculations](https://docs.google.com/spreadsheets/d/1LFtETGOsghYVJeTIF4v1L9cBB3IKu1LS9ypb7b-GtVY/edit#gid=0)
 and current OP code gas costs. DAO members should consider splitting 
the DAO into two if more than 100 tokens with non-zero balance are used 
in the DAO to be safe.
# External calls in loop can lead to denial of service

Checkbox: No
Linked to : spbp[43 176 182]
Problem: function calls are made in unbounded loop 
Recommendation: review all the loops 
Tags: dos

[publications/OriginDollar.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/OriginDollar.pdf)

tags used - unbounded loop

### The Pattern

Several function calls are made in unbounded loops. This pattern is error-prone as it can trap the contracts due to the gas limitations or failed transactions. For example, AaveStrategy has several loops that iterate over the assetsMapped items, including safeApproveAllTokens:

```solidity
function safeApproveAllTokens() external onlyGovernor {
uint256 assetCount = assetsMapped.length;
address lendingPoolVault = _getLendingPoolCore();
// approve the pool to spend the bAsset
for (uint256 i = 0; i < assetCount; i++) {
address asset = assetsMapped[i];
// Safe approval
IERC20(asset).safeApprove(lendingPoolVault, 0);
IERC20(asset).safeApprove(lendingPoolVault, uint256(-1));
}
}
```

assetsMapped is an unbounded array that can only grow. safeApproveAllTokens can be trapped if:

● A call to an asset fails (for example, the asset is paused)

● Items in assetsMapped increases the gas cost beyond a certain limit
# Contract Owner Can Arbitrarily Change Minting Fees and Interest Rates

Checkbox: Yes
Linked to : spbp [ 163 165 184 ] 
Problem: owner is able to control the minting fees 
Recommendation: consider making minting fee to be constant and cannot be changed by the owner 
Tags: configuration

[public-audits/review.pdf at master · sigp/public-audits](https://github.com/sigp/public-audits/blob/master/synthetix/ethercollateral/review.pdf)
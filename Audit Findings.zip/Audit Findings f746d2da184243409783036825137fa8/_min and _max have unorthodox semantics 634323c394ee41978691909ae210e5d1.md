# _min* and _max* have unorthodox semantics

Checkbox: No
Linked to : spbp [ 28 136 137 170 ] 
Problem: _minTargetAmount_maxOriginAmount are used as open ranges which contradicts the conventional def. of minimum and maximum 
Recommendation: use conventional norms or document otherwise 
Tags: specification

[protocol-v1-deprecated/2021-05-03-Trail_of_Bits.pdf at main · dfx-finance/protocol-v1-deprecated](https://github.com/dfx-finance/protocol/blob/main/audits/2021-05-03-Trail_of_Bits.pdf)

Throughout the Curve contract, *_minTargetAmount* and *_maxOriginAmount*
 are used as open ranges (i.e., ranges that exclude the value itself). 
This contravenes the standard meanings of the terms “minimum” and 
“maximum,” which are generally used to describe closed ranges.

1. Recommendation: Short term, unless they are intended to be strict, make the
inequalities in the require statements non-strict. Alternatively,
consider refactoring the variables or providing additional documentation to convey that they are meant to be exclusive bounds. Long term, ensure that mathematical terms such as “minimum,” “at least,” and “at most”
are used in the typical way—that is, to describe values inclusive of
minimums or maximums (as relevant).
# Functions with unexpected side-effects

Checkbox: No
Linked to : sol [97] spbp [ 136 137 188 197 ]
Problem: name of the function was not clear . name was sounding like getters but they were setters too . A new developer can wrongly modify the code 
Recommendation: split the function into separate getters and setters
Tags: specification

[UMA Audit - Phase 4 - OpenZeppelin blog](https://blog.openzeppelin.com/uma-audit-phase-4/)
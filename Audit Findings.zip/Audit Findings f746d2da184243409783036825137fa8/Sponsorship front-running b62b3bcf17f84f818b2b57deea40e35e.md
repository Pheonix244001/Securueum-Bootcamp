# Sponsorship front-running

Checkbox: Yes
Linked to : spbp [21 176]
Recommendation: use Pull mechanism
Tags: dos, timing

[The LAO | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/01/the-lao/#sponsorship-front-running)
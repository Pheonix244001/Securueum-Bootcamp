# Mismatches between contracts and interfaces

Checkbox: No
Linked to : spbp [ 136 179 188 ] 
Problem: interface had some function that were not defined in the parent contract`
Recommendation: syn mismatches 
Tags: specification

[Opyn Gamma Protocol Audit - OpenZeppelin blog](https://blog.openzeppelin.com/opyn-gamma-protocol-audit/)

Interfaces define the exposed functionality of the implemented 
contracts. However, in several interfaces there are functions from the 
counterpart contracts that are not defined.

1. Recommendation: Consider applying the necessary changes in the mentioned interfaces and contracts so that definitions and implementations fully match.
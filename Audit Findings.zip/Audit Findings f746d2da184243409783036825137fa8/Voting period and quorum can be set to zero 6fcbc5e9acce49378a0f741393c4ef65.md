# Voting period and quorum can be set to zero

Checkbox: No
Linked to : spbp [ 138 146 169 ]
Problem: even though the value of votingPeriod and votingQuorum are checked that they are greater than 0 but the setter function were allowing them to become zero
Recommendation: adding the validation to the setter functions.
Tags: data validation

[Audius Contracts Audit - OpenZeppelin blog](https://blog.openzeppelin.com/audius-contracts-audit/#medium)

When the `Governance` contract is initialized, the values of `[votingPeriod](https://github.com/AudiusProject/audius-protocol/blob/6f3b31562b9d4c43cef91af0a011986a2580fba2/eth-contracts/contracts/Governance.sol#L132)` and `[votingQuorum](https://github.com/AudiusProject/audius-protocol/blob/6f3b31562b9d4c43cef91af0a011986a2580fba2/eth-contracts/contracts/Governance.sol#L135)` are checked to make sure that they are greater than 0. However, the corresponding setter functions `[setVotingPeriod](https://github.com/AudiusProject/audius-protocol/blob/6f3b31562b9d4c43cef91af0a011986a2580fba2/eth-contracts/contracts/Governance.sol#L457)` and `[setVotingQuorum](https://github.com/AudiusProject/audius-protocol/blob/6f3b31562b9d4c43cef91af0a011986a2580fba2/eth-contracts/contracts/Governance.sol#L467)` allow these to variables to be reset to 0.

Setting the `votingPeriod` to zero would cause spurious proposals that cannot be voted. Setting the `quorum` to zero is worse because it would allow proposals with 0 votes to be executed.

Consider adding the validation to the setter functions.

***Update:** Fixed in [pull request #568](https://github.com/AudiusProject/audius-protocol/pull/568).*
# Owners can never be removed

Checkbox: No
Linked to : spbp [ 149 153 172 ] 
Problem: old owners can never be removed 
Recommendation: before adding new owners , loop through the current set of owners and clear there is owner booleans 
Tags: access control

[Paxos | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/11/paxos/#owners-can-never-be-removed)

The intention of `setOwners()` is to replace the current set of owners with a new set of owners. However, the `isOwner`
 mapping is never updated, which means any address that was ever 
considered an owner is permanently considered an owner for purposes of 
signing transactions.

### Recommendation

In `setOwners_()`, before adding new owners, loop through the current set of owners and clear their `isOwner` booleans, as in the following code:

`for (uint256 i = 0; i < ownersArr.length; i++) {
   isOwner[ownersArr[i]] = false;
}`
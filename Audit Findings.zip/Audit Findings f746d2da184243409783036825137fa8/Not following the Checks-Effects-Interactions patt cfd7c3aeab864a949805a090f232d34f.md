# Not following the Checks-Effects-Interactions pattern

Checkbox: No
Linked to : sol [157] spbp [13 177 ] 
Problem: not following check-effect interaction pattern causes reentrancy 
Recommendation: always follow CEI pattern and use reentrancy guard 
Tags: timing

[Endaoment Audit - OpenZeppelin blog](https://blog.openzeppelin.com/endaoment-audit/)

The `[finalizeGrant](https://github.com/endaoment/endaoment-contracts/blob/f60aa253d3d869ad6460877f23e6092acb313add/contracts/Fund.sol#L119)` function of the `Fund` contract is setting the `grant.complete` storage variable [after a token `transfer`](https://github.com/endaoment/endaoment-contracts/blob/f60aa253d3d869ad6460877f23e6092acb313add/contracts/Fund.sol#L133).

[Solidity recommends the usage of the Check-Effects-Interaction Pattern](https://solidity.readthedocs.io/en/latest/security-considerations.html#use-the-checks-effects-interactions-pattern) to avoid potential security issues, such as reentrancy.

The `finalizeGrant` function can be used to conduct a reentrancy attack, where the `[token transfer in line 129](https://github.com/endaoment/endaoment-contracts/blob/f60aa253d3d869ad6460877f23e6092acb313add/contracts/Fund.sol#L129)` can call back again the same function, sending to the `admin` multiple times an amount of `fee`, [before setting the `grant` as completed](https://github.com/endaoment/endaoment-contracts/blob/f60aa253d3d869ad6460877f23e6092acb313add/contracts/Fund.sol#L133).

In this way the `grant.recipient` can receive less than expected and the contract funds can be drained unexpectedly leading to an unwanted loss of funds.

Consider always following the “Check-Effects-Interactions” pattern, 
thus modifying the contract’s state before making any external call to 
other contracts
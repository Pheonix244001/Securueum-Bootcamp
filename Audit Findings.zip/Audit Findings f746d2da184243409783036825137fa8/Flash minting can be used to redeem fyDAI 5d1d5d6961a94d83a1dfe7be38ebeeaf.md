# Flash minting can be used to redeem fyDAI

Checkbox: Yes
Linked to : spbp [181 186]
Recommendation: Disallow Flash Minting  
Tags: undefined behaviour

[publications/YieldProtocol.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/YieldProtocol.pdf)
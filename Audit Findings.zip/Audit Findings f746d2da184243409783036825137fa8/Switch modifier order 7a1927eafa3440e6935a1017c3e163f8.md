# Switch modifier order

Checkbox: No
Linked to : spbp [ 141 152 178 191 ] 
Problem: reentrancy is after another modifier 
Recommendation: reentrancy modifier should be in precedence 
Tags: ordering

NOTE the order of execution for modifiers is from left to right for the modifiers 

 THAT IT IS IMPORTANT TO HAVE A CORRECT ORDER OF MODIFIERS IN PLACE . THE FIRST MODIFIER WILL BE CHECKED BEFORE THE SECOND ORDER AND SO WE HAVE TO TAKE CARE OF THAT 

FOR EX - REENTRANCY SHOULD BE CHECKED BEFORE OTHER OPEREATIONS AND SO WE SOULD PLACE REENTRANCY MODIFIER FIRST 

[Balancer Finance | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/05/balancer-finance/#switch-modifier-order-in-bpool)

*BPool* functions often use modifiers in the following order: *_logs_*, *_lock_*. Because *_lock_* is a reentrancy guard, it should take precedence over *_logs_.*

1. Recommendation: Place *_lock_* before other modifiers; ensuring it is the very first and very last thing to run when a function is called.
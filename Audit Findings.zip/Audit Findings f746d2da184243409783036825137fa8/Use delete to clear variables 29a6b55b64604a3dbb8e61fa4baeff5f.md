# Use delete to clear variables

Checkbox: Yes
Linked to : spbp [ 164 167 188 ] 
Problem: Controller contract sets a variable to the zero address in order to clear it.
Recommendation: Consider replacing assignments of zero with delete statements.
Tags: patching

[Set Protocol Audit - OpenZeppelin blog](https://blog.openzeppelin.com/set-protocol-audit/)

The Controller contract sets a variable to the zero address in order to clear it. Similarly, the *SetToken* clears the locker by assigning the zero address.

1. Recommendation: The *delete* key better conveys the intention and is also more idiomatic. Consider replacing assignments of zero with *delete* statements.
# Incorrect event emission

Checkbox: No
Linked to : spbp [ 173 178 185 ]
Problem: emitting event before relevant state changes causing incorrect event emission
Recommendation: emit after state changes 
Tags: auditing & logging

[Compound Open Price Feed - Uniswap Integration Audit - OpenZeppelin blog](https://blog.openzeppelin.com/compound-open-price-feed-uniswap-integration-audit/)

The `UniswapWindowUpdate` event of the `UniswapAnchoredView` contract is currently [being emitted in the `pokeWindowValues` function](https://github.com/compound-finance/open-oracle/blob/d0a0d0301bff08457d9dfc5861080d3124d079cd/contracts/Uniswap/UniswapAnchoredView.sol#L241) using incorrect values. In particular, as it is being emitted *[before* relevant state changes are applied](https://github.com/compound-finance/open-oracle/blob/d0a0d0301bff08457d9dfc5861080d3124d079cd/contracts/Uniswap/UniswapAnchoredView.sol#L242-L246) to the `oldObservation` and `newObservation` variables, the data logged by the event will be outdated.

Consider emitting the `UniswapWindowUpdate` event *after* changes are applied so that all logged data is up-to-date.
# Owner can front-run traders by updating adapters

Checkbox: Yes
Linked to : spbp [21 163 181 184 ] 
Problem: delegatecalled adapters can overwrite logic regardless of any policies . Users must fully trust adapters 
Recommendation: disallow modification of existing adapters. Instead, simply add new adapters and disable the old ones.
Tags: timing

[FrontRunning](Owner%20can%20front-run%20traders%20by%20updating%20adapters%20a3c7b7e1c1764cb5b8e6694ee53fcacc/FrontRunning%20c8fc7f92d9d94184ba9d94dcce620379.md)

[Metaswap | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/08/metaswap/#owner-can-front-run-traders-by-updating-adapters)

Tags used - frontrun
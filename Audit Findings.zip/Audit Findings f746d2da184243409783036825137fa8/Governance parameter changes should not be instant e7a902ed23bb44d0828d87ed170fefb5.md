# Governance parameter changes should not be instant

Checkbox: Yes
Tags: timing

[MCDEX Mai Protocol Audit - OpenZeppelin blog](https://blog.openzeppelin.com/mcdex-mai-protocol-audit/)

Many sensitive changes can be made by any account with the `[WhitelistAdmin` role](https://github.com/OpenZeppelin/openzeppelin-contracts/blob/5fe8f4e93bd1d4f5cc9a6899d7f24f5ffe4c14aa/contracts/access/roles/WhitelistAdminRole.sol#L21-L24) via the functions `setGovernanceParameter` within the `[AMMGovernance](https://github.com/mcdexio/mai-protocol-v2/blob/4b198083ec4ae2d6851e101fc44ea333eaa3cd92/contracts/liquidity/AMMGovernance.sol#L22)` and `[PerpetualGovernance](https://github.com/mcdexio/mai-protocol-v2/blob/4b198083ec4ae2d6851e101fc44ea333eaa3cd92/contracts/perpetual/PerpetualGovernance.sol#L39)` contracts. For example, the `WhitelistAdmin` can change the [fee schedule](https://github.com/mcdexio/mai-protocol-v2/blob/4b198083ec4ae2d6851e101fc44ea333eaa3cd92/contracts/perpetual/PerpetualGovernance.sol#L57-L60), the [initial](https://github.com/mcdexio/mai-protocol-v2/blob/4b198083ec4ae2d6851e101fc44ea333eaa3cd92/contracts/perpetual/PerpetualGovernance.sol#L40-L44) and [maintenance](https://github.com/mcdexio/mai-protocol-v2/blob/4b198083ec4ae2d6851e101fc44ea333eaa3cd92/contracts/perpetual/PerpetualGovernance.sol#L45-L50) margin rates, or the [lot size parameters](https://github.com/mcdexio/mai-protocol-v2/blob/4b198083ec4ae2d6851e101fc44ea333eaa3cd92/contracts/perpetual/PerpetualGovernance.sol#L61-L69), and these new parameters instantly take effect in the protocol with important effects.

For example, raising the maintenance margin rate could cause `[isSafe](https://github.com/mcdexio/mai-protocol-v2/blob/4b198083ec4ae2d6851e101fc44ea333eaa3cd92/contracts/perpetual/Perpetual.sol#L243)` to [return `False`](https://github.com/mcdexio/mai-protocol-v2/blob/4b198083ec4ae2d6851e101fc44ea333eaa3cd92/contracts/perpetual/Perpetual.sol#L251-L252) when it would have previously returned `True`. This would allow the user’s position [to be liquidated](https://github.com/mcdexio/mai-protocol-v2/blob/4b198083ec4ae2d6851e101fc44ea333eaa3cd92/contracts/perpetual/Perpetual.sol#L272). By changing `tradingLotSize`, trades may [revert](https://github.com/mcdexio/mai-protocol-v2/blob/4b198083ec4ae2d6851e101fc44ea333eaa3cd92/contracts/exchange/Exchange.sol#L63)
 when being matched, where they would not have before the change. These 
are only examples; the complexity of the protocol, combined with 
unpredictable market conditions and user actions means that many other 
negative effects likely exist as well.

Since these changes are occasionally needed, but can create risk for 
the users of the protocol, consider implementing a time-lock mechanism 
for such changes to take place. By having a delay between the signal of 
intent and the actual change, users will have time to remove their funds
 or close trades that would otherwise be at risk if the change happened 
instantly. A simple timelock can follow the same pattern as applying for
 withdrawals ([setting](https://github.com/mcdexio/mai-protocol-v2/blob/4b198083ec4ae2d6851e101fc44ea333eaa3cd92/contracts/perpetual/Collateral.sol#L62) an `appliedHeight`, then [checking it when the withdrawal is executed](https://github.com/mcdexio/mai-protocol-v2/blob/4b198083ec4ae2d6851e101fc44ea333eaa3cd92/contracts/perpetual/Collateral.sol#L71)).
 If a timelock is implemented for governance parameter changes, the 
delay should be on the order of multiple days, to give users time to 
consider the effects of potential changes and act accordingly.

**Update:** *Acknowledged. The Monte Carlo team will implement a delay in the external governance mechanism*
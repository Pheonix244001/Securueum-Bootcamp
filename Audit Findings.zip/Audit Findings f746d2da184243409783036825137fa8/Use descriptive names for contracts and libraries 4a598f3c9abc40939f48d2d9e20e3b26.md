# Use descriptive names for contracts and libraries

Checkbox: No
Linked to : sol [ 97- 101 ] spbp [ 188 197 199 ] 
Problem: difficult navigation with no descriptive naming convention
Recommendation: use descriptive names 
Tags: readability

[Growth Defi V1 | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/12/growth-defi-v1/#use-descriptive-names-for-contracts-and-libraries)
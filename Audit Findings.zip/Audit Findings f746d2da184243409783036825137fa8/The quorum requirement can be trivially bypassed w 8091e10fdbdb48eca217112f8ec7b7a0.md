# The quorum requirement can be trivially bypassed with sybil accounts

Checkbox: No
Linked to : spbp [ 159 171 172 ] 
Problem: quorum check can be easily bypassed by splitting one’s token over multiple account and voting with each account 
Recommendation: measure the quorum size by the percentrage of existing tokens that have voted rather than number of unique accounts that have voted 
Tags: identification

[Audius Contracts Audit - OpenZeppelin blog](https://blog.openzeppelin.com/audius-contracts-audit/#high)

While the final vote on a proposal is determined via a token-weighted vote, [the quorum check](https://github.com/AudiusProject/audius-protocol/blob/6f3b31562b9d4c43cef91af0a011986a2580fba2/eth-contracts/contracts/Governance.sol#L366) in the `evaluateProposalOutcome`
 function can be trivially bypassed by splitting one’s tokens over 
multiple accounts and voting with each of the accounts. Each of these 
sybil votes [increases the `proposals[_proposalId].numVotes` variable](https://github.com/AudiusProject/audius-protocol/blob/6f3b31562b9d4c43cef91af0a011986a2580fba2/eth-contracts/contracts/Governance.sol#L281). This means anyone can make the quorum check pass.

Consider measuring quorum size by the percentage of existing tokens 
that have voted, rather than the number of unique accounts that have 
voted.

***Update:** Fixed in [pull request #574](https://github.com/AudiusProject/audius-protocol/pull/574). However, note that the `[setVotingQuorumPercent` function](https://github.com/AudiusProject/audius-protocol/pull/574/files#diff-cdd717eae25ddcfc7ccd2b9bd6be68c1R466) is not validating that the value set is between 0 and 100.*
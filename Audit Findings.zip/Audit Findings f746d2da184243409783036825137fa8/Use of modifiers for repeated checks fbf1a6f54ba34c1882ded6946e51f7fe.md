# Use of modifiers for repeated checks

Checkbox: No
Linked to : spbp [ 141 188 190 ] 
Recommendation: use modifiers for common checks within different functions  
Tags: code refactoring

[Balancer Finance | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/05/balancer-finance/#use-of-modifiers-for-repeated-checks)

It is recommended to use modifiers for common checks within 
different functions. This will result in less code duplication in the 
given smart contract and adds significant readability into the code 
base.

1. Recommendation: Use of modifiers for repeated checks
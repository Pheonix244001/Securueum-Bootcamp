# Staking Before Initial notifyRewardAmount Can Lead to Disproportionate Rewards

Checkbox: No
Linked to : spbp [145 178 191 ]
Recommendation: dont call the stake() function before notifyRewardAmount() is called for the first time . Alternatively, set lastUpdatetime to block.timestamp during the first execution of notifyRewardAmount() .
Tags: ordering, timing

[public-audits/review.pdf at master · sigp/public-audits](https://github.com/sigp/public-audits/blob/master/synthetix/unipool/review.pdf)

[https://github.com/k06a/Unipool](https://github.com/k06a/Unipool)

- `notifyRewardAmount()`: This is a function in smart contracts that is called to notify the contract about the amount of rewards that are going to be distributed to the stakers. This function is typically called by the contract owner or administrator.
- `userRewardPerTokenPaid`: This is a variable that keeps track of the amount of rewards that have been paid to each staker per token they have staked. It is updated every time a staker makes a stake or withdraws their stake, and the amount paid is calculated based on the time the staker held their stake.
- `rewardRate`: This is a variable that represents the rate at which rewards are being distributed to stakers. It is usually calculated by dividing the total amount of rewards by the duration of the reward period.
- `periodFinish`: This is a variable that represents the timestamp when the current reward period will end.
- `lastUpdateTime`: This is a variable that represents the timestamp when the user's rewardPerTokenPaid was last updated.
- `earned()`: This is a function that calculates the total amount of rewards earned by a staker based on the number of tokens they have staked and the time they held their stake. It takes into account the user's rewardPerTokenPaid, the current rewardRate, and the time since the last update.

If a staker successfully stakes UNI tokens in a smart contract before the `notifyRewardAmount()` function is called for the first time, their initial `userRewardPerTokenPaid` will be set to zero. This means that when the staker calls the `earned()` function, their earned reward balance will also be zero, since both `lastUpdateTime` and `userRewardPerTokenPaid` are zero.

However, when the `notifyRewardAmount()` function is called for the first time, the `rewardRate` and `periodFinish` variables will be set in the smart contract to reflect the amount and duration of the new reward period. This means that the staker's earned reward balance will begin to increase from that point forward, based on the `rewardRate` and their proportion of the total staked tokens.

If the staker chooses to wait and call the `getReward()` function at a later date, when the contract has accumulated more rewards or the value of the rewards has increased, they may receive a payout that is greater than their share of the SNX rewards. This is because the value of the rewards may have increased due to external factors such as an increase in the value of the underlying asset, and the staker will be entitled to a share of the total rewards based on their proportion of the staked tokens.
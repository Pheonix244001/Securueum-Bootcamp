# Only whitelist validated assets

Checkbox: No
Linked to : spbp [ 132 159 180 183 ] 
Problem: malicious token can block people from voting 
Recommendation: whitelisted tokens should also be audited 
Tags: validation

[Aave Governance Dao | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/08/aave-governance-dao/#only-whitelist-validated-assets)

Because some of the functionality relies on correct token 
behavior, any whitelisted token should be audited in the context of this
 system. Problems can arise if a malicious token is whitelisted because 
it can block people from voting with that specific token or gain unfair 
advantage if the balance can be manipulated.

1. Recommendation: Make sure to audit any new whitelisted asset.
# No incentive for bidders to vote earlier

Checkbox: No
Linked to : spbp[177 187] 
Problem: Users can change the outcome of voting by bidding with more funds in the last minute 
Recommendation: Incentize users to vote earlier . Consider weight of bid decreasing over time 
Tags: timing

[publications/hermez.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/hermez.pdf)
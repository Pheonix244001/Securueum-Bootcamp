# ERC20 token Curve does not implement symbol, name, or decimals

Checkbox: No
Linked to : spbp [ 103 169 ] 
Problem: no name , symbol or decimals was implemented in ERC20 token Curve 
Recommendation: implement simple names symbols and decimals 
Tags: configuration

[protocol-v1-deprecated/2021-05-03-Trail_of_Bits.pdf at main · dfx-finance/protocol-v1-deprecated](https://github.com/dfx-finance/protocol/blob/main/audits/2021-05-03-Trail_of_Bits.pdf)

*Curve.sol* is an ERC20 token and implements all six required ERC20 methods: *balanceOf*, *totalSupply*, *allowance*, *transfer*, *approve*, and *transferFrom*. However, it does not implement the optional but extremely common view methods *symbol*, *name*, and *decimals*.

1. Recommendation: Short term, implement *symbol*, *name*, and *decimals* on Curve contracts. Long term, ensure that contracts conform to all required and recommended industry standards.
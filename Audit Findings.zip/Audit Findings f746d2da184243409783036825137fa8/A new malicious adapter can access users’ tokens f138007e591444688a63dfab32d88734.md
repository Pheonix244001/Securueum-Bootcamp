# A new malicious adapter can access users’ tokens

Checkbox: Yes
Linked to : spbp [4 148 149 159 181]
Problem:  Malicious Adapter could access user tokens 
Recommendation: Make MetaSwap contract the only contract that receives token approval.
Tags: access control

[Metaswap | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/08/metaswap/#a-new-malicious-adapter-can-access-users-tokens)

The purpose of the *MetaSwap* contract is to save users gas costs when dealing with a number of different aggregators. They can just approve() their tokens to be spent by *MetaSwap* (or in a later architecture, the Spender contract). They can then  perform trades with all supported aggregators without having to 
reapprove anything. A downside to this design is that a malicious (or  buggy) adapter has access to a large collection of valuable assets. Even  a user who has diligently checked all existing adapter code before 
interacting with *MetaSwap*  runs the risk of having their funds intercepted by a new malicious adapter that’s added later.
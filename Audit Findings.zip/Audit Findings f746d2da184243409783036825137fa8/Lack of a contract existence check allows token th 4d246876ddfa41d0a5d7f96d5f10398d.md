# Lack of a contract existence check allows token theft

Checkbox: Yes
Linked to : sol [87] spbp[38 174]
Problem: Contract existence was not checked so you can steal token by registering a contract that is not even deployed 
Recommendation: Check for the contract existence 
Tags: data validation

[publications/hermez.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/hermez.pdf)

The low-level call, delegatecall and callcode will return success if the called account is

non-existent, as part of the design of EVM. Existence must be checked prior to calling if desired

As a result, _safeTransferFrom will return success even if the token is not yet deployed, or

was self-destructed.

An attacker that knows the address of a future token can register the token in Hermez, and

deposit any amount prior to the token deployment. Once the contract is deployed and

tokens have been deposited in Hermez, the attacker can steal the funds.

The address of a contract to be deployed can be determined by knowing the address of its

deployer
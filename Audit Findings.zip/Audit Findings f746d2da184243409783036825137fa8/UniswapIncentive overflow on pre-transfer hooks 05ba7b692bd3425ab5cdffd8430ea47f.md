# UniswapIncentive overflow on pre-transfer hooks

Checkbox: Yes
Linked to : sol [177 ] spbp [19 , 138 , 146 ]
Recommendation: Use SafeCast 
Tags: data validation

[Fei Protocol | ConsenSys Diligence](https://consensys.net/diligence/audits/2021/01/fei-protocol/#uniswapincentive-overflow-on-pre-transfer-hooks)

allowing a caller to mint tokens before transferring them, or burn tokens from their recipient.

Overflow Prone Casting 

from a user supplied uint256 to int256 which is a downcast , may have overflowed without appropriate checks 

Downcasting from uint256/int256 in Solidity does not revert on overflow. This can easily result in undesired exploitation or bugs, since developers usually assume that overflows raise errors. `SafeCast` restores this intuition by reverting the transaction when such an operation overflows.
# safeApprove does not check return values for approve call

Checkbox: Yes
Linked to : spbp [ 142 175 190 ] 
Problem: custom made approve function check that  a call to approve was successful but does not check returndata to verify wether the call returned true
Recommendation: use openzeppelin safeApprove and also ensure that all the low level calls have accompanying contract existence checks and return value checks where appropriate 
Tags: error handling

[protocol-v1-deprecated/2021-05-03-Trail_of_Bits.pdf at main · dfx-finance/protocol-v1-deprecated](https://github.com/dfx-finance/protocol/blob/main/audits/2021-05-03-Trail_of_Bits.pdf)

```solidity
//WRONG IMPLEMENTATION IN CONTRACT 
function safeApprove(
        address _token,
        address _spender,
        uint256 _value
    ) private {
        (bool success, ) =
            // solhint-disable-next-line
     _token.call(abi.encodeWithSignature("approve(address,uint256)", _spender, _value));

        require(success, "SafeERC20: low-level call failed");
    }
```

```solidity
// RIGHT IMPLEMENTATION FROM OPENZEPPELIN 
function safeApprove(IERC20 token, address spender, uint256 value) internal {
        // safeApprove should only be called when setting an initial allowance,
        // or when resetting it to zero. To increase and decrease it, use
        // 'safeIncreaseAllowance' and 'safeDecreaseAllowance'
        require(
            (value == 0) || (token.allowance(address(this), spender) == 0),
            "SafeERC20: approve from non-zero to non-zero allowance"
        );
    _callOptionalReturn(token, abi.encodeWithSelector(token.approve.selector, spender, value));
    }
```

Although the Router contract uses OpenZeppelin’s *SafeERC20* library to perform safe calls to ERC20’s approve function, the Orchestrator library defines its own *safeApprove*
 function. This function checks that a call to approve was successful 
but does not check returndata to verify whether the call returned true. 
In contrast, OpenZeppelin’s *safeApprove* function 
checks return values appropriately. This issue may result in uncaught 
approve errors in successful Curve deployments, causing undefined 
behavior.

1. Recommendation: Short term, leverage OpenZeppelin’s *safeApprove* function wherever possible. Long term, ensure that all low-level calls
have accompanying contract existence checks and return value checks
where appropriate.
# Lack of two-step procedure for critical operations leaves them error-prone

Checkbox: No
Linked to : spbp[50 162]
Problem: Several critical operations in one call → error  prone 
Recommendation: Use the two procedure for all such critical address updates to prevent an irrecoverable mistake 
Tags: data validation

[publications/hermez.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/hermez.pdf)

for example the setter for the white hat
group address sets the address to the
provided argument
if the address is incorrect then the new
address would take on the functionality
of that role immediately
leaving it open to misuse by anyone who
controlled that new address
or if the new address
was one without an available private key
it would log access to that role forever
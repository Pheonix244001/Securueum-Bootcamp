# Insufficient Input Validation

Checkbox: No
Linked to : spbp [ 49 138 149 169 ]
Problem: constructor has no zero address check 
Recommendation: check address 
Tags: input validation

[public-audits/review.pdf at master · sigp/public-audits](https://github.com/sigp/public-audits/blob/master/synthetix/ethercollateral/review.pdf)

The constructor of the *EtherCollateral* 
smart contract does not check the validity of the addresses provided as 
input parameters. It is possible to deploy an instance of the *EtherCollateral* contract with the *synthProxy* , *sUSDProxy* and depot addresses set to zero. Similarly, the effective interest rate can be equal to zero if *interestRate* is set to any value lesser than 31536000 ( *SECONDS_IN_A_YEAR* ), as *interestPerSecond* will be null.

1. Recommendation: Consider introducing require statements to perform adequate input validation.
# Unchecked return value for IWETH.transfer call

Checkbox: No
Linked to : sol[149] spbp [142 175]
Problem: Unchecked Return Value of ERC20 transfer
Recommendation: Add require of safeErc20 
Tags: error handling

[Transfer and safeTransfer](Unhandled%20return%20values%20of%20transfer%20and%20transferFr%20c0eaab98f33f4580b5cb71b180c5edb8/Transfer%20and%20safeTransfer%20e01adc721f74425690e3f93a69047d48.md) 

[Fei Protocol | ConsenSys Diligence](https://consensys.net/diligence/audits/2021/01/fei-protocol/#unchecked-return-value-for-iwethtransfer-call)

If you are sure that the token will always revert in case of failure then no worries

otherwise use safeTransfer or add a require statement to check the return value
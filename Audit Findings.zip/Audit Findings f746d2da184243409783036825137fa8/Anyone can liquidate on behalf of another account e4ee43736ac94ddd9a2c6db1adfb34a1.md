# Anyone can liquidate on behalf of another account

Checkbox: No
Linked to : spl [23] spbp [ 4 140 148 149 172 181 ] 
Problem: one function bypass the checks of other function 
Recommendation: considering restricting visibility to internal 
Tags: access control

[MCDEX Mai Protocol Audit - OpenZeppelin blog](https://blog.openzeppelin.com/mcdex-mai-protocol-audit/)

The `Perpetual` contract has a [public `liquidateFrom` function](https://github.com/mcdexio/mai-protocol-v2/blob/4b198083ec4ae2d6851e101fc44ea333eaa3cd92/contracts/perpetual/Perpetual.sol#L270) that bypasses the checks in the `[liquidate` function](https://github.com/mcdexio/mai-protocol-v2/blob/4b198083ec4ae2d6851e101fc44ea333eaa3cd92/contracts/perpetual/Perpetual.sol#L291).

This means that it can be called to liquidate a position when the contract is in the `SETTLED` state. Additionally, any user can set an arbitrary `from`
 address, causing a third-party user to confiscate the 
under-collateralized trader’s position. This means that any trader can 
unilaterally rearrange another account’s position. They could also 
liquidate on behalf of the [Perpetual Proxy](https://github.com/mcdexio/mai-protocol-v2/blob/4b198083ec4ae2d6851e101fc44ea333eaa3cd92/contracts/proxy/PerpetualProxy.sol), which could break some of the [Automated Market Maker](https://github.com/mcdexio/mai-protocol-v2/blob/4b198083ec4ae2d6851e101fc44ea333eaa3cd92/contracts/liquidity/AMM.sol) invariants, such as the condition that it only holds `LONG` positions.

Consider restricting `liquidateFrom` to `internal` visibility.

**Update:** *Fixed. The `liquidateFrom` function has been removed.*
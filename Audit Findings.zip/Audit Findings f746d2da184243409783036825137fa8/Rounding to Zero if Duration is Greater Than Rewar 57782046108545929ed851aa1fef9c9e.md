# Rounding to Zero if Duration is Greater Than Reward

Checkbox: No
Linked to : spbp [ 20 169 170 ] 
Problem: rounding to zero if the duration > reward ( check the formula below for calculating the rewardRate ) 
Recommendation: document the issue and also provide a way to claim rewards after rounding 
Tags: data validation

[public-audits/review.pdf at master · sigp/public-audits](https://github.com/sigp/public-audits/blob/master/synthetix/unipool/review.pdf)

The *rewardRate* value is calculated as follows: *rewardRate = reward/duration*. Due to the integer representation of these variables, if duration is larger than reward the value of *rewardRate*
 will round to zero. Thus, stakers will not receive any of the reward 
for their stakes. Furthermore, due to the integer rounding, the total 
rewards distributed may be rounded down by up to one less than duration .
 As a result, the Unipool contract may slowly accumulate SNX.

1. Recommendation: Beware of the rounding issues when calling the *notifyRewardAmount*() function. We also recommend some way of allowing the excess SNX reward
from rounding to be claimed or withdrawn from the Unipool contract.
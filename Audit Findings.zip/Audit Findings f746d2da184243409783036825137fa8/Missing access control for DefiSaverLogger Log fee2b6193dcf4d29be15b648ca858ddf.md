# Missing access control for DefiSaverLogger.Log

Checkbox: No
Linked to : spbp [ 149 173 ]
Problem: anyone can create logs since there is no access control in the Log function 
Recommendation: add access control 
Tags: access control

[DeFi Saver | ConsenSys Diligence](https://consensys.net/diligence/audits/2021/03/defi-saver/#missing-access-control-for-defisaverloggerlog)
# smartWallet address is not guaranteed correct. ETH may be lost

Checkbox: No
Tags: M
URL: https://github.com/code-423n4/2022-11-stakehouse-findings/issues/317
# Vaults can be griefed to not be able to be used for deposits

Checkbox: No
Tags: M
URL: https://github.com/code-423n4/2022-11-stakehouse-findings/issues/422
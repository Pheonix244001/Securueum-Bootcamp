# BondBaseSDA.setDefaults doesn't validate inputs

Checkbox: No
Tags: M
URL: https://github.com/sherlock-audit/2022-11-bond-judging/issues/11
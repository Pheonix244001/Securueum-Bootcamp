# bringUnusedETHBackIntoGiantPool in GiantMevAndFeesPool can be used to steal LPTokens

Checkbox: No
Tags: H
URL: https://github.com/code-423n4/2022-11-stakehouse-findings/issues/366
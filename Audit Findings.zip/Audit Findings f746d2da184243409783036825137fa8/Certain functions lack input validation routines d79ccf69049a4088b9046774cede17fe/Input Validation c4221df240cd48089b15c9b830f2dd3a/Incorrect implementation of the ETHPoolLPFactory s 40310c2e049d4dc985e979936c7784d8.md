# Incorrect
 implementation of the ETHPoolLPFactory.sol#rotateLPTokens let user 
stakes ETH more than maxStakingAmountPerValidator in StakingFundsVault, 
and DOS the stake function in LiquidStakingManager

Checkbox: No
Tags: M
URL: https://github.com/code-423n4/2022-11-stakehouse-findings/issues/132
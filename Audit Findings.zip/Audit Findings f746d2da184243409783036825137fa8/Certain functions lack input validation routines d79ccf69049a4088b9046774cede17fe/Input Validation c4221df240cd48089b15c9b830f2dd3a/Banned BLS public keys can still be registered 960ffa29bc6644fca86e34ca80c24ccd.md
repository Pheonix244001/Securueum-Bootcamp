# Banned BLS public keys can still be registered

Checkbox: No
Tags: M
URL: https://github.com/code-423n4/2022-11-stakehouse-findings/issues/144
# Lack of sanity check for stoptime

Checkbox: No
Tags: M
URL: https://github.com/sherlock-audit/2022-11-nounsdao-judging/issues/66
# GiantPool should not check ETH amount on withdrawal

Checkbox: No
Tags: M
URL: https://github.com/code-423n4/2022-11-stakehouse-findings/issues/92
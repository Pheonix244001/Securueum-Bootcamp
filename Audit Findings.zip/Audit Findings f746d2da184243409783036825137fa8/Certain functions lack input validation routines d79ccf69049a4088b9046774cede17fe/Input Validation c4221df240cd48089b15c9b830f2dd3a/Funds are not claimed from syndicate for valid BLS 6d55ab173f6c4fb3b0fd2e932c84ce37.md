# Funds are not claimed from syndicate for valid BLS keys of first key is invalid (no longer part of syndicate).

Checkbox: No
Tags: M
URL: https://github.com/code-423n4/2022-11-stakehouse-findings/issues/408
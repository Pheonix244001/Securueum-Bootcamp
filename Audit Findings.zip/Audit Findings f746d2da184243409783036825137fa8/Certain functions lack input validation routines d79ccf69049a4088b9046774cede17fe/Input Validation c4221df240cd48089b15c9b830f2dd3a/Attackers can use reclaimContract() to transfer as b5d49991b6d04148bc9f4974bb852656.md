# Attackers can use reclaimContract() to transfer assets in protocol to address(0)

Checkbox: No
Tags: H
URL: https://github.com/sherlock-audit/2022-11-bullvbear-judging/issues/127
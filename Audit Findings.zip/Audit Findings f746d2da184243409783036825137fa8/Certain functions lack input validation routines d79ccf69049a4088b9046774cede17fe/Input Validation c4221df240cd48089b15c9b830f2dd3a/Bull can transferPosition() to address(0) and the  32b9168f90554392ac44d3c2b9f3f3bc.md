# Bull can transferPosition() to address(0) and the original order can be matched again

Checkbox: No
Tags: H
URL: https://github.com/sherlock-audit/2022-11-bullvbear-judging/issues/114
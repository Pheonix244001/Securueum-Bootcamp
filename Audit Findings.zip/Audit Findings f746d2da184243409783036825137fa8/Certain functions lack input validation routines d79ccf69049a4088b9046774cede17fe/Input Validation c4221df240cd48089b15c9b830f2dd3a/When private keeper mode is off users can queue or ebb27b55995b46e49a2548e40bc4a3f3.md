# When private keeper mode is off users can queue orders with the wrong asset

Checkbox: No
Tags: H
URL: https://github.com/sherlock-audit/2022-11-buffer-judging/issues/85
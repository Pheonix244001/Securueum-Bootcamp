# Withdrawing wrong LPToken from GiantPool leads to loss of funds

Checkbox: No
Tags: M
URL: https://github.com/code-423n4/2022-11-stakehouse-findings/issues/98
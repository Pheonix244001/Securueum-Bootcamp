# cancelOrdersUpTo can be used to permanently block future orders

Checkbox: Yes
Linked to : spbp [169]
Problem: function can cancel future orders if called with very large value such as unit 256 -1 
Recommendation: document this behaviour or disallow this feature 
Tags: data validation

[publications/0x-protocol.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/0x-protocol.pdf)

the cancelOrdersUpTo function, the salt is used as a parameter to discard any order with a salt less than the input value. By doing so, the function ensures that only the orders that need to be cancelled are cancelled, and future orders are not affected
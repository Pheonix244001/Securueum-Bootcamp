# Consider an iterative approach to launching. Be aware of and prepare for worst-case scenarios

Checkbox: No
Linked to : spbp [ 128-135 197 200 ] 
Problem: system has many components with complex functionality but no apparent upgrade path if any vuln is  discovered after launch 
Recommendation: identify which components were curcial for min viable system to focus efforts on ensuring security of those first . also have a method of pausing and upgrading  
Tags: configuration

[Lien Protocol | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/05/lien-protocol/#consider-an-iterative-approach-to-launching)

The system has many components with complex functionality and no apparent upgrade path.

1. Recommendation: We recommend identifying which components are crucial for a minimum
viable system, then focusing efforts on ensuring the security of those
components first, and then moving on to the others. During the early
life of the system, have a method for pausing and upgrading the system.
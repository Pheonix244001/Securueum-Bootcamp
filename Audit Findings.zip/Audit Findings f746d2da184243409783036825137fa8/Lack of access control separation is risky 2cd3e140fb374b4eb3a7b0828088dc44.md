# Lack of access control separation is risky

Checkbox: No
Linked to : spbp[148 149 172 194]
Problem: Using same account to change both frequent and less frequent update is an error prone architecture 
Recommendation: Use Seperate accounts for handling different functions , and document the access control and set up proper authorization in long term 
Tags: access control

[publications/hermez.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/hermez.pdf)

if there is one contract that has frequent interaction with blockchain , its compromise will have if a higher likelihood of compromise of other functions in that same contract , if they are present
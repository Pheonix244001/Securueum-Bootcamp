# Tokens with more than 18 decimal points will cause issues

Checkbox: No
Recommendation: Use SafeMath
Tags: input validation

[Decimals](Tokens%20with%20more%20than%2018%20decimal%20points%20will%20cause%2093e8423199d741c2856e6b16cd35443d/Decimals%20556898aa3dad4fcf8badad832eebb146.md)

**********************INPUT VALIDATION**********************

Assumption of the code that token will only be upto 18 decimal points caused this problem . There can be token with > 18 decimal places .

Tags - Decimals 

1. The requirements for `tokenAmount >= stopTime - startTime` will not be suitable for all tokens and therefore need to be made less applicable for certain tokens like WBTC and EURS.

[Why ](Tokens%20with%20more%20than%2018%20decimal%20points%20will%20cause%2093e8423199d741c2856e6b16cd35443d/Why%202ec141a126ba4e82942b768c3e120ddd.md)

USDC has 6 decimals that means that 1$ is 1_000_000 tokens.
One day has 86400 seconds.
1_000_000 / 86400 = 11.57. This states that if you want to pay 1 token per second than you will spend 1$ in 11.57 days.

So if you want to have Stream that pays 1$ in 15 days(or 
2$ in 30 days, or 100$ in 1500 days and so on) you will not be able to 
do that.
But as for me it's possible to have a contract that pays 1$ in 15 days for smth.

1. In case of price normalization , check for the validity of the formula used in case of token with varying token decimals 

[Price Normalization ](Tokens%20with%20more%20than%2018%20decimal%20points%20will%20cause%2093e8423199d741c2856e6b16cd35443d/Price%20Normalization%207f1f593ec1c84c25a33d13469a054288.md)
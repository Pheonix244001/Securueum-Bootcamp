# System always assumes USDC is equivalent to USD

Checkbox: No
Linked to : spbp [169 184] 
Problem: incorrect assumption without using oracle 
Recommendation: replace the hard-coded integer literal and use oracle 
Tags: data validation

[protocol-v1-deprecated/2021-05-03-Trail_of_Bits.pdf at main · dfx-finance/protocol-v1-deprecated](https://github.com/dfx-finance/protocol/blob/main/audits/2021-05-03-Trail_of_Bits.pdf)
# Test and production constants in the same codebase

Checkbox: Yes
Problem: test and production constants being in the same codebase  
Tags: testing

[Fei Protocol Audit - OpenZeppelin blog](https://blog.openzeppelin.com/fei-protocol-audit/)

The *CoreOrchestrator* contract defines the *TEST_MODE*
 boolean variable which is used to define several constants in the 
system. This decreases legibility of production code, and makes the 
system’s integral values more error-prone.

1. Recommendation: Consider having different environments for production and testing, with different contracts.
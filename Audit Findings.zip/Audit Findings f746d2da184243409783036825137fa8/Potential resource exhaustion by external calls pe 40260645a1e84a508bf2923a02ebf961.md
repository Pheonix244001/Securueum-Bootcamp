# Potential resource exhaustion by external calls performed within an unbounded loop

Checkbox: No
Linked to : spbp [ 42 43 44 176 182 ] 
Problem: unbounded loop will exhaust gas and will create dos 
Recommendation: reconsider the logic or bound the loop
Tags: dos

[Growth Defi V1 | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/12/growth-defi-v1/#potential-resource-exhaustion-by-external-calls-performed-within-an-unbounded-loop)

```
uint256 _numMarkets = SoloMargin(_solo).getNumMarkets();
for (uint256 _i = 0; _i < _numMarkets; _i++) {
	address _address = SoloMargin(_solo).getMarketTokenAddress(_i);
	if (_address == _token) {
		_marketId = _i;
		break;
	}
}
```

This is unbounded in nature because , the limit of loop depends upon a variable which is not bounded , the more the value of the variable , the more iterations it will take . but there is a limit to how much gas can be used for a particular block . This means that it could be possible that the loop exhaust all the gas and create a situation where there is denial of service
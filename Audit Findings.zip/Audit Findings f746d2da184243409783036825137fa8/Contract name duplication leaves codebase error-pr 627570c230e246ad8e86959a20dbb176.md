# Contract name duplication leaves codebase error-prone

Checkbox: No
Linked to : sol [ 97-101 ] spbp [ 188 197 199 ] 
Problem: contract have duplicate names that will lead to incorrect json artifacts preventing 3rd party to use their tools 
Recommendation: avoid duplicate contract names or use slither 
Tags: undefined behaviour

[publications/hermez.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/hermez.pdf)

The codebase has multiple contracts that share the same name. 
This allows buidler-waffle to generate incorrect json artifacts, 
preventing third parties from using their tools. Buidler-waffle does not
 correctly support a codebase with duplicate contract names. The 
compilation overwrites compilation artifacts and prevents the use of 
third-party tools, such as Slither.

1. Recommendation: Short term, prevent the re-use of duplicate contract names or change
the compilation framework. Long term, use Slither, which will help
detect duplicate contract names.
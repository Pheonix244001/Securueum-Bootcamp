# Timed.isTimeEnded returns true if the timer has not been initialized

Checkbox: No
Linked to : spbp [145 178 143 177]
Problem: The method returning true for most values, even though the timer has not technically been started
Recommendation: If Timed has not been initialized, isTimeEnded() should return false, or revert
Tags: error handling

[Fei Protocol | ConsenSys Diligence](https://consensys.net/diligence/audits/2021/01/fei-protocol/#timedistimeended-returns-true-if-the-timer-has-not-been-initialized)

Timed initialization is a process that is used to set up a new blockchain or smart contract protocol. During this period, there are certain actions or settings that can be done, but the protocol is not fully activated yet. Once the initialization period is over, the protocol is fully operational and can be used by users. This process is often used to ensure that the protocol is set up properly and that certain parameters or actions are approved before it is fully activated. The duration of the initialization period can vary, and it is typically predetermined or set through community governance.

### Description

`Timed` initialization is a 2-step process:

- `Timed.duration` is set in the constructor
- `Timed.startTime` is set when the method `_initTimed` is called:

Before this second method is called, `isTimeEnded()` calculates remaining time using a `startTime` of 0, resulting in the method returning `true` for most values, even though the timer has not technically been started.
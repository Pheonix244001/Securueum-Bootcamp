# Use of hardcoded gas limits can be problematic

Checkbox: No
Linked to : spbp [ 42 43 44 182 ]
Problem: hardcoded gas assumption is problematic 
Recommendation: be prepared and document that 
Tags: dos

[1inch Liquidity Protocol | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/12/1inch-liquidity-protocol/#use-of-hardcoded-gas-limits-can-be-problematic)
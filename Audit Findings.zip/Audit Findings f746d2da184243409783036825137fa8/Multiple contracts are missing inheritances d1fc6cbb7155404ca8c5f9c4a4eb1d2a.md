# Multiple contracts are missing inheritances

Checkbox: Yes
Linked to : spbp [ 156 179 ] 
Problem: Multiple contracts are the implementation of their interfaces, but do not inherit from them.
Recommendation: ensure ChainlinkOracle and OpenUniswapOracle inherits from IPriceOracle, and that RebaseHooks inherits from IRebaseHooks
Tags: undefined behaviour

[publications/OriginDollar.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/OriginDollar.pdf)

Multiple contracts are the implementation of their interfaces, but do not inherit from them.

This behavior is error-prone and might lead the implementation to not follow the interface

if the code is updated.

The contracts missing the inheritance are:

● ChainlinkOracle should inherit from IPriceOracle

● OpenUniswapOracle should inherit from IPriceOracle

● RebaseHooks should inherit from IRebaseHooks

Exploit Scenario

IPriceOracle is updated and one of its functions has a new signature. ChainlinkOracle is

not updated. As a result, any call to the updated function using ChainlinkOracle will fail.

Recommendation

Short term, ensure ChainlinkOracle and OpenUniswapOracle inherits from

IPriceOracle, and that RebaseHooks inherits from IRebaseHooks.

Long term, subscribe to crytic.io. Crytic catches the bug.
# Permission-granting is too simplistic and not flexible enough

Checkbox: No
Linked to : spbp [ 148 149 160 172 192 193 ] 
Problem: All the authorized addresses can call any restricted function
Recommendation: rewrite the authorization system to allow only certain addresses to access certain functions (e.g., the minter address can only call mint in YDai
Tags: access control

[publications/YieldProtocol.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/YieldProtocol.pdf)

The Yield Protocol contracts implement an oversimplified 
permission system that can be abused by the administrator. The Yield 
Protocol implements several contracts that need to call privileged 
functions from each other. However, there is no way to specify which 
operation can be called for every privileged user. All the authorized 
addresses can call any restricted function, and the owner can add any 
number of them. Also, the privileged addresses are supposed to be smart 
contracts; however, there is no check for that. Moreover, once an 
address is added, it cannot be deleted.

1. Recommendation: Rewrite the authorization system to allow only certain addresses to access certain functions
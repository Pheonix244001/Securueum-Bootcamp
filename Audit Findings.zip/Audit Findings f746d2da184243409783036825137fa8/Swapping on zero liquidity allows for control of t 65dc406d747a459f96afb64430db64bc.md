# Swapping on zero liquidity allows for control of the pool’s price

Checkbox: Yes
Tags: application logic, data validation

[v3-core/audit.pdf at main · Uniswap/v3-core](https://github.com/Uniswap/uniswap-v3-core/blob/main/audits/tob/audit.pdf)
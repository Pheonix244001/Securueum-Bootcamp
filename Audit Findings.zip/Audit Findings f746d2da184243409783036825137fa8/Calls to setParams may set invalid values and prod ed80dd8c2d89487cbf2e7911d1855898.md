# Calls to setParams may set invalid values and produce unexpected behavior in the staking contracts

Checkbox: No
Linked to : spbp [137 18 146 169 ]
Problem: lack of sanity check when setting parameters 
Recommendation: add proper validation check and if its too complex then document the potential issues 
Tags: data validation

[publications/0x-protocol.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/0x-protocol.pdf)
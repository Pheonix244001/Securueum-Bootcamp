# Prevent contracts from being used before they are entirely initialized

Checkbox: No
Linked to : spbp [ 166 177 178 ] 
Problem: Users could deposit/withdraw before that contract is completely initialized 
Recommendation: Initialize before Interaction
Tags: timing

[Growth Defi V1 | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/12/growth-defi-v1/#prevent-contracts-from-being-used-before-they-are-entirely-initialized)
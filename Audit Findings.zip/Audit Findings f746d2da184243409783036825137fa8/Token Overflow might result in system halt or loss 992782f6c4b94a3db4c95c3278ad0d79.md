# Token Overflow might result in system halt or loss of funds

Checkbox: No
Linked to : spbp [176 19]
Problem: SafeMath reverts can break some system functionality due to overflow by artifically inflating the token price 
Recommendation: allow overflow for broken or malicious tokens
Tags: dos

[The LAO | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/01/the-lao/#emergency-processing-can-be-blocked)
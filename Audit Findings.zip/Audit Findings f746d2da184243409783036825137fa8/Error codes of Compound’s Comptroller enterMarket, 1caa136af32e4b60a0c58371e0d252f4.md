# Error codes of Compound’s Comptroller.enterMarket, Comptroller.exitMarket are not checked

Checkbox: No
Problem: Error Codes were not checked . Early checks of error codes is necessary
Recommendation: Check Error Code . Revert if necessary
Tags: error handling

[DeFi Saver | ConsenSys Diligence](https://consensys.net/diligence/audits/2021/03/defi-saver/#error-codes-of-compounds-comptrollerentermarket-comptrollerexitmarket-are-not-checked)

Error Codes of few functions were not checked , causing them to not react to excptional cases where reverting is required 

The `enterMarket` function allows a user to enter a market on a lending protocol, which means they can start borrowing or lending assets on the platform. When a user enters a market, they typically deposit collateral to secure their loans and earn interest on their deposits.

On the other hand, the `exitMarket` function allows a user to exit a market on a lending protocol, which means they can no longer borrow or lend assets on the platform. When a user exits a market, they typically withdraw their remaining collateral and any accrued interest.

These functions are essential for managing user positions on DeFi platforms, and the proxy smart contract that implements them can provide additional security and functionality, such as allowing the contract to interact with other protocols or perform additional checks before executing the transactions.
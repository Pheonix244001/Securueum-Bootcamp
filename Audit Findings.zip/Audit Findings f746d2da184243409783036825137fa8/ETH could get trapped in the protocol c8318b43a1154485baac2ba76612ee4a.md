# ETH could get trapped in the protocol

Checkbox: No
Linked to : spbp [ 29 170 171 176 ] 
Problem: lack of withdrawETH function cause the remaining ETH to lock up rather than refunding if more than required ETH is sent 
Recommendation: eiher return all the remaining eth or create a function for doing so 
Tags: dos

[Opyn Gamma Protocol Audit - OpenZeppelin blog](https://blog.openzeppelin.com/opyn-gamma-protocol-audit/)

The `[Controller` contract](https://github.com/opynfinance/GammaProtocol/blob/d151621b33134789b29dc78eb89dad2b557b25b9/contracts/Controller.sol#L27) allows users to send arbitrary actions such as possible [flash loans](https://blog.openzeppelin.com/flash-loans-and-the-advent-of-episodic-finance/) through the `[_call` internal function](https://github.com/opynfinance/GammaProtocol/blob/d151621b33134789b29dc78eb89dad2b557b25b9/contracts/Controller.sol#L763).

Among other features, it allows sending ETH with the action to then perform a call to a `[CalleeInterface` type of contract](https://github.com/opynfinance/GammaProtocol/blob/d151621b33134789b29dc78eb89dad2b557b25b9/contracts/interfaces/CalleeInterface.sol#L9).

To do so, it saves the original `msg.value` sent with the `[operate` function call](https://github.com/opynfinance/GammaProtocol/blob/d151621b33134789b29dc78eb89dad2b557b25b9/contracts/Controller.sol#L331) in the `[ethLeft` variable](https://github.com/opynfinance/GammaProtocol/blob/d151621b33134789b29dc78eb89dad2b557b25b9/contracts/Controller.sol#L460) and it [updates the remaining ETH left](https://github.com/opynfinance/GammaProtocol/blob/d151621b33134789b29dc78eb89dad2b557b25b9/contracts/Controller.sol#L769) after each one of those calls to revert in case that it is not enough.

Nevertheless, if the user sends more than the necessary ETH for the batch of actions, the remaining ETH (stored in the `ethLeft` variable after the last iteration) will not be returned to the user and will be locked in the contract due to the lack of a `withdrawEth` function.

Consider either returning all the remaining ETH to the user or 
creating a function that allows the user to collect the remaining ETH 
after performing a `Call` action type, taking into account that sending ETH with a push method may trigger the fallback function on the caller’s address.

**Update:** *Fixed in [PR#304](https://github.com/opynfinance/GammaProtocol/pull/304) where the `payable` property is removed from the `operate` function. However this change also means it is impossible to do outbound calls which require ETH through the `operate` function.*
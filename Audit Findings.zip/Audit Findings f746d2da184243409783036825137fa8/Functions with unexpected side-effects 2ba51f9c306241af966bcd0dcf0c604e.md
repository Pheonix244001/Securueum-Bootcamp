# Functions with unexpected side-effects

Checkbox: No
Linked to : sol [ 97-101 ]  spbp [ 188 197 199 ] 
Problem: function names with unexpected side - effects were not clear in names of the function 
Recommendation: sync names of functions with action or separate into getters and setters 
Tags: specification

[UMA Audit - Phase 4 - OpenZeppelin blog](https://blog.openzeppelin.com/uma-audit-phase-4/)

Some functions have side-effects. For example, the *_getLatestFundingRate* function of the *FundingRateApplier* contract might also update the funding rate and send rewards. The getPrice function of the *OptimisticOracle*
 contract might also settle a price request. These side-effect actions 
are not clear in the name of the functions and are thus unexpected, 
which could lead to mistakes when the code is modified by new developers
 not experienced in all the implementation details of the project.

1. Recommendation: Consider splitting these functions in separate getters and setters.
Alternatively, consider renaming the functions to describe all the
actions that they perform.
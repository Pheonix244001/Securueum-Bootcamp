# Named return variables

Checkbox: Yes
Linked to : spbp [ 142 164 188  ] 
Problem: inconsistent use of named return variables 
Recommendation: removing named return variables 
Tags: readability

[Holdefi Audit - OpenZeppelin blog](https://blog.openzeppelin.com/holdefi-audit)

There is an inconsistent use of named return variables across the entire codebase.

1. Recommendation: Consider removing all named return variables, explicitly declaring them as local variables in the body of the function, and adding the
necessary explicit return statements where appropriate. This should
favor both explicitness and readability of the project.
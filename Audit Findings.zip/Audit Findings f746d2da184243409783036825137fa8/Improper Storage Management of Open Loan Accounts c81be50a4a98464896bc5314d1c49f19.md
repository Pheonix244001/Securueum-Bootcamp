# Improper Storage Management of Open Loan Accounts

Checkbox: No
Linked to : spbp [169 171 176 ]
Problem: array is used to keep track of whoever has opened a loan . however , this gets added to array reagardless if the user has opened a loan before
Recommendation: Consider changing the  function to only push the account to the array if the loan to be stored is the first one for that particular account . Introduce a limit to the number of loans each account can have.
Tags: data validation, dos

[public-audits/review.pdf at master · sigp/public-audits](https://github.com/sigp/public-audits/blob/master/synthetix/ethercollateral/review.pdf)
# Full test suite is recommended

Checkbox: No
Linked to : spbp [ 155 ]
Problem: Test suite was not complete and had incomplete coverage 
Recommendation: Add a full coverage test suite 
Tags: testing

- **Full test suite is recommended**: The test suite at this stage is not complete and many of the tests fail to execute. For complicated systems such as DeFi Saver, which uses many different modules and interacts with different DeFi protocols, it is
crucial to have a full test coverage that includes the edge cases and
failed scenarios. Especially this helps with safer future development
and upgrading each module. As we’ve seen in some smart contract
incidents, a complete test suite can prevent issues that might be hard
to find with manual reviews.
    1. Recommendation: Add a full coverage test suite.
    
    [DeFi Saver | ConsenSys Diligence](https://consensys.net/diligence/audits/2021/03/defi-saver/#full-test-suite-is-recommended)
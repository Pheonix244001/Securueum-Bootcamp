# BondingCurve allows users to acquire FEI before launch

Checkbox: No
Linked to : spbp [ 26 158 145 178 143 177 ] 
Problem: allocate function can be called before genesis launch and bypass majority checks 
Recommendation: Ensure that function that any function should not be called before or after lauch if it is not intended to do so 
Tags: timing

[Fei Protocol | ConsenSys Diligence](https://consensys.net/diligence/audits/2021/01/fei-protocol/#bondingcurve-allows-users-to-acquire-fei-before-launch)

`allocate` can be called before genesis launch, as long as
 the contract holds some nonzero PCV. By force-sending the contract 1 
wei, anyone can bypass the majority of checks and actions in `allocate`, and mint themselves FEI each time the timer expires.
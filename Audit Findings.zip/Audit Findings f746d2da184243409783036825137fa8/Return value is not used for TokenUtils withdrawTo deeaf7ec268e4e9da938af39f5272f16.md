# Return value is not used for TokenUtils.withdrawTokens

Checkbox: No
Linked to : spbp [ 142 171 ]
Problem: Unchecked Return value Transferred Tokens
Recommendation: check the return value and use that in the event created 
Tags: error handling

[DeFi Saver | ConsenSys Diligence](https://consensys.net/diligence/audits/2021/03/defi-saver/#return-value-is-not-used-for-tokenutilswithdrawtokens)

this could cause discrepancy in the case when requested transfer amount is uint256 max for some reason in which case the amount that will be transferred would be less than requested and return back but never check
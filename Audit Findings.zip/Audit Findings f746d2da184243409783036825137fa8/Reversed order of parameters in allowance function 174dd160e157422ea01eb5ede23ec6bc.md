# Reversed order of parameters in allowance function call

Checkbox: No
Problem: Prameter order used in allowance function was not same as param order of safeTransferfrom 
Recommendation: Check for ordering of parameters as this might cause unintended errors 
Tags: ordering

[DeFi Saver | ConsenSys Diligence](https://consensys.net/diligence/audits/2021/03/defi-saver/#reversed-order-of-parameters-in-allowance-function-call)

the parameters that are used for the `allowance`  function call are not in the same order that is used later in the call to `safeTransferFrom`.

```solidity
function pullTokens( // changed to 
    function pullTokensIfNeeded(
        address _token,
        address _from,
        uint256 _amount
    ) internal returns (uint256) {
        // handle max uint amount
        if (_amount == type(uint256).max) {
            uint256 allowance = IERC20(_token).allowance(address(this), _from); // changed to 
            uint256 userAllowance = IERC20(_token).allowance(_from, address(this));
            uint256 balance = getBalance(_token, _from);

            _amount = (balance > allowance) ? allowance : balance; // changed to 
            // pull max allowance amount if balance is bigger than allowance
            _amount = (balance > userAllowance) ? userAllowance : balance;
        }

        if (_from != address(0) && _from != address(this) && _token != ETH_ADDR && _amount != 0) {
```

this was the main function that has the flaw . so at any place where this function is called is a problem 

1. **`allowance(address owner, address spender) → uint256`**
2. **`safeTransferFrom(contract IERC20 token, address from, address to, uint256 value)`**

***Note - `address(this)`refers to the address of the current contract instance. It is a built-in keyword that allows a smart contract to refer to its own address on the blockchain.***

Things that can happen if this is done are 

1. Unintended token transfer - the spender could be granted an allowance to transfer more tokens than intended. For example, if the allowance function call grants the spender an allowance of 100 tokens for a specific token contract, but the safeTransferFrom function call specifies a transfer of 200 tokens, the spender could potentially transfer 200 tokens and not just the allowed 100 tokens.
2. error - an error can occur. For example, if the safeTransferFrom function call specifies the wrong token contract or the wrong recipient address, the transfer will fail and an error will be thrown.
3. gas fees will still be paid even if error occured 
4. if the tokens being transferred have a high value, any mistake in the transfer process could result in a significant financial loss.
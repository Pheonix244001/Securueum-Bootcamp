# Review Chainlink’s performance at times of price volatility

Checkbox: No
Linked to : spbp  [155 180 185 ]  
Tags: testing

[Aave CPM Price Provider | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/05/aave-cpm-price-provider/#review-chainlink-s-performance-at-times-of-price-volatility)

In order to understand the risk of the Chainlink oracle 
deviating significantly, it would be helpful to compare historical 
prices on Chainlink when prices are moving rapidly, and see what the 
largest historical delta is compared to the live price on a large 
exchange.

1. Recommendation: Review Chainlink’s performance at times of price volatility
# Delegates can be added or removed repeatedly to bloat logs

Checkbox: No
Linked to : spbp [ 157 173 ] 
Problem: delegates could be added or removed repeatedly to bloat logs 
Recommendation: add a require statement to check that the delegate address is not already enabled or disabled for the user
Tags: auditing & logging

[publications/YieldProtocol.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/YieldProtocol.pdf)

Several contracts in the Yield Protocol system inherit the 
Delegable contract. This contract allows users to delegate the ability 
to perform certain operations on their behalf to other addresses. When a
 user adds or removes a delegate, a corresponding event is emitted to 
log this operation. However, there is no check to prevent a user from 
repeatedly adding or removing a delegation that is already enabled or 
revoked, which could allow redundant events to be emitted repeatedly.

1. Recommendation: Short term, add a *require* statement to check that the delegate address is not already enabled or
disabled for the user. This will ensure log messages are only emitted
when a delegate is activated or deactivated. Long term, review all
operations and avoid emitting events in repeated calls to idempotent
operations. This will help prevent bloated logs.
# Improve system documentation and create a complete technical specification

Checkbox: No
Linked to : spbp [ 136 137 179 188 ] 
Problem: no documentation , only a single readme file 
Recommendation: improve system documentaion and create a complete technical specification
Tags: documentation, specification

[Growth Defi V1 | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/12/growth-defi-v1/#improve-system-documentation-and-create-a-complete-technical-specification)
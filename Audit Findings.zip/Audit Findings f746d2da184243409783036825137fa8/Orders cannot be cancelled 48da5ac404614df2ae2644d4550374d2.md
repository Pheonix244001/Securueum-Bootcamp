# Orders cannot be cancelled

Checkbox: No
Linked to : spbp [ 169 176 ] 
Problem: cancel order function only change the mapping . validateOrderParam does not check if order has been cancelled 
Recommendation: Consider adding this check to the order validation to ensure cancelled orders cannot be filled.
Tags: dos

[MCDEX Mai Protocol Audit - OpenZeppelin blog](https://blog.openzeppelin.com/mcdex-mai-protocol-audit/)

When a user or broker calls `[cancelOrder](https://github.com/mcdexio/mai-protocol-v2/blob/4b198083ec4ae2d6851e101fc44ea333eaa3cd92/contracts/exchange/Exchange.sol#L180)`, [the `cancelled` mapping](https://github.com/mcdexio/mai-protocol-v2/blob/4b198083ec4ae2d6851e101fc44ea333eaa3cd92/contracts/exchange/Exchange.sol#L184) is updated, but this has no subsequent effects. In particular, `[validateOrderParam](https://github.com/mcdexio/mai-protocol-v2/blob/4b198083ec4ae2d6851e101fc44ea333eaa3cd92/contracts/exchange/Exchange.sol#L155)` does not check if the order has been cancelled.

Consider adding this check to the order validation to ensure cancelled orders cannot be filled.

**Update:** *Fixed. The validation now checks the cancellation status*
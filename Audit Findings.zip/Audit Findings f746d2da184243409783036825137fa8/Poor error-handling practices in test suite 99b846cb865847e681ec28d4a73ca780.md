# Poor error-handling practices in test suite

Checkbox: Yes
Linked to : spbp [ 155 ] 
Problem: test suite had poor error handling certain component lack error handling methods ( details below ) 
Recommendation: test operation against a specfic error messages 
Tags: error handling

[documents/dForceLending-Audit-Report-TrailofBits-Mar-2021.pdf at master · dforce-network/documents](https://github.com/dforce-network/documents/blob/master/audit_report/Lending/dForceLending-Audit-Report-TrailofBits-Mar-2021.pdf)

The test suite does not properly test expected behavior, as the
 contracts run in production. Additionally, certain components lack 
error-handling methods. These deficiencies can cause failed tests to be 
overlooked. In particular, the tests fail to properly check error 
messages. For example, errors are silenced with a try-catch statement. 
If this error is silenced, there will be no guarantee that a smart 
contract call has reverted for the right reason. As a result, if the 
test suite passes, it will provide no guarantee that the transaction 
call reverted correctly.

1. Recommendation: Short
term, test these operations against a specific error message. Testing
will ensure that errors are never silenced, and the test suite will
check that a contract call has reverted for the right reason. Long term, follow standard testing practices for smart contracts to minimize the
number of issues during development.
# Commented code

Checkbox: No
Linked to : spbp [ 154 188 ] 
Problem: codebase had lines of codes that has been commented out 
Recommendation: remove or uncomment the code 
Tags: patching

[BarnBridge Smart Yield Bonds Audit - OpenZeppelin blog](https://blog.openzeppelin.com/barnbridge-smart-yield-bonds-audit/)

Throughout the codebase there are lines of code that have been 
commented out with //. This can lead to confusion and is detrimental to 
overall code readability.

1. Recommendation: Consider removing commented out lines of code that are no longer needed.
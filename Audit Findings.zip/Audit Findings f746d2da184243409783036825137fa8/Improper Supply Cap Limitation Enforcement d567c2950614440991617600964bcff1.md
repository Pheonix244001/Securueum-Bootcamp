# Improper Supply Cap Limitation Enforcement

Checkbox: No
Linked to : spbp [ 159 169 171 ]
Problem: the value of loan issued can exceed the supply cap since there is nothing to check that 
Recommendation: add a require statement for this 
Tags: data validation

[public-audits/review.pdf at master · sigp/public-audits](https://github.com/sigp/public-audits/blob/master/synthetix/ethercollateral/review.pdf)
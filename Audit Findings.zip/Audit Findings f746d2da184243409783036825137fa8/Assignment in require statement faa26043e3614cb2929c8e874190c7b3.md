# Assignment in require statement

Checkbox: No
Linked to : spbp [ 51 175 188 ] 
Problem: assignment in a require statement deviation from the norm 
Recommendation: only use require for condition checking 
Tags: error checking

[BarnBridge Smart Yield Bonds Audit - OpenZeppelin blog](https://blog.openzeppelin.com/barnbridge-smart-yield-bonds-audit/)

In the *YieldOracle* contract, there is a *require* statement that makes an assignment. This deviates from the standard usage and intention of *require* statements and can easily lead to confusion.

1. Recommendation: Consider moving the assignment to its own line before the *require* statement and then using the *require* statement solely for condition checking.
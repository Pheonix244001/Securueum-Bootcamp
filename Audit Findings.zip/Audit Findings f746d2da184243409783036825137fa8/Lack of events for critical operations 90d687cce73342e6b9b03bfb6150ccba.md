# Lack of events for critical operations

Checkbox: No
Linked to : spbp [ 45 173 201 ] 
Problem: lack of events for critical operations 
Recommendation: add event where appropropriate 
Tags: auditing & logging

[publications/0x-protocol.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/0x-protocol.pdf)

w the correct behavior of the contracts once deployed. Users 
and blockchain monitoring systems will not be able to easily detect 
suspicious behaviors without events.

1. Recommendation: Short term, add events where appropriate for all critical operations.
Long term, consider using a blockchain monitoring system to track any
suspicious behavior in the contracts.
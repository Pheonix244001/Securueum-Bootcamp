# Evaluate all tokens prior to inclusion in the system

Checkbox: No
Linked to : spbp [ 107  108 129 159 136 137 171 ] 
Problem: token with non standard behaviour . eg . ERC777 . or infaltionary deflationary or rebasing tokens
Recommendation: Evaluate non standard tokens prior to inclusion in the system 
Tags: access control, specification

[Growth Defi V1 | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/12/growth-defi-v1/#evaluate-all-tokens-prior-to-inclusion-in-the-system)

[Token Interaction Checklist | ConsenSys Diligence](https://consensys.net/diligence/blog/2020/11/token-interaction-checklist/)

OpenZeppelin’s `SafeERC20`
 library, this library only protects against the more common deviations from the ERC20 standard.
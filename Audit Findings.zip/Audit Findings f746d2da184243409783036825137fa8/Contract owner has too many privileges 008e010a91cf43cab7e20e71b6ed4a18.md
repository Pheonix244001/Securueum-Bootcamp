# Contract owner has too many privileges

Checkbox: No
Linked to : spbp [ 148 149 160 172 192 193 ] 
Problem: contract owner had too many priviledge 
Recommendation: document the function and implementation the owner could change , and split privilidge such that no address has majority ownership 
Tags: access control

[documents/dForceLending-Audit-Report-TrailofBits-Mar-2021.pdf at master · dforce-network/documents](https://github.com/dforce-network/documents/blob/master/audit_report/Lending/dForceLending-Audit-Report-TrailofBits-Mar-2021.pdf)

The owner of the contracts has too many privileges relative to 
standard users. Users can lose all of their assets if a contract owner 
private key is compromised. The contract owner can do the following: 1) 
Upgrade the system’s implementation to steal funds 2) Upgrade the 
token’s implementation to act maliciously 3)  Increase the amount of *iTokens*
 for reward distribution to such an extent that rewards cannot be 
disbursed 4) Arbitrarily update the interest model contracts The 
concentration of these privileges creates a single point of failure. It 
increases the likelihood that the owner will be targeted by an attacker,
 especially given the insufficient protection on sensitive owner private
 keys. Additionally, it incentivizes the owner to act maliciously.

1. Recommendation: Short term: 1) Clearly document the functions and implementations the
owner can change. 2) Split privileges to ensure that no one address has
excessive ownership of the system. Long term, document the risks
associated with privileged users and single points of failure. Ensure
that users are aware of all the risks associated with the system.
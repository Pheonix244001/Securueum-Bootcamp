# Document potential edge cases for hook receiver contracts.

Checkbox: Yes
Problem: anyone could force a call 
Tags: access control, input validation

[Umbra Smart Contracts | ConsenSys Diligence](https://consensys.net/diligence/audits/2021/03/umbra-smart-contracts/#document-potential-edge-cases-for-hook-receiver-contracts)

[ERC-5902: Smart Contract Event Hooks](https://eips.ethereum.org/EIPS/eip-5902)

[Extending Contracts - OpenZeppelin Docs](https://docs.openzeppelin.com/contracts/3.x/extending-contracts#using-hooks)
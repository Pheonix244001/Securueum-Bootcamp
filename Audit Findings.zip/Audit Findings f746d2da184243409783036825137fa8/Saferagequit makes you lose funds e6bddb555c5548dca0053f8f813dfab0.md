# Saferagequit makes you lose funds

Checkbox: Yes
Linked to : spbp [ 176 ]
Problem: Partial Withdrawl Lose remaining tokens
Recommendation: Pull over push pattern implementation 
Tags: dos

[The LAO | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/01/the-lao/#saferagequit-makes-you-lose-funds)
# Unnecessary event emission

Checkbox: No
Tags: auditing & logging

[GEB Protocol Audit - OpenZeppelin blog](https://blog.openzeppelin.com/geb-protocol-audit/)

The *popDebtFromQueue* function of the *AccountingEngine* contract is emitting a useless event whenever someone tries to call it with a *debtBlockTimestamp* that has not been saved before.

1. Recommendation: To simplify the code and prevent wastage of gas, avoid emitting unnecessary events.
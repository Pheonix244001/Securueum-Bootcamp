# Remove stale comments

Checkbox: No
Linked to : spbp [ 154 157 137 ] 
Problem: Stale Comments about storage slots 
Recommendation: Remove Stale Comments 
Tags: documentation

[DAOfi | ConsenSys Diligence](https://consensys.net/diligence/audits/2021/02/daofi/#remove-stale-comments)
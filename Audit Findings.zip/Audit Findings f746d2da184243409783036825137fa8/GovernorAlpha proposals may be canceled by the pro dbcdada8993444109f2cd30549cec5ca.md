# GovernorAlpha proposals may be canceled by the proposer, even after they have been accepted and queued

Checkbox: No
Linked to : spbp [ 143 145 178 191 ] 
Problem: proposals can be cancelled even after they have been accepted as one of the conditions to cancel proposal has a complete control of proposer
Recommendation: prevent proposal from being cancelled unless they have been in pending or active state 
Tags: application logic

[Fei Protocol | ConsenSys Diligence](https://consensys.net/diligence/audits/2021/01/fei-protocol/#governoralpha-proposals-may-be-canceled-by-the-proposer-even-after-they-have-been-accepted-and-queued)
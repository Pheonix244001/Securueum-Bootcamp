# Overflow/underflow protection

Checkbox: Yes
Linked to : sol [ 142 146 175 ] spbp [19 ] 
Problem: Math Operations Overflow/Underflow
Recommendation: Use SafeMath or compiler ≥ 0.8.0
Tags: data validation

[Fei Protocol | ConsenSys Diligence](https://consensys.net/diligence/audits/2021/01/fei-protocol/#overflowunderflow-protection)

[Overflow/Underflow](Overflow%20underflow%20protection%2008a9dad00f55492b90908dfccc0813af/Overflow%20Underflow%20a200cfa491e449fdb83d3f8b143435b4.md)

On the other hand, some operations can’t be checked for overflow/underflow without going much deeper into the codebase that is out of scope
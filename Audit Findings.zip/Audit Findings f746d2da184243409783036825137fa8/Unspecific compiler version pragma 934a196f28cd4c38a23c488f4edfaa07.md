# Unspecific compiler version pragma

Checkbox: No
Linked to : spbp [ 2 155 ] 
Problem: floating pragma 
Recommendation: dont use floating pragma 
Tags: configuration

[1inch Liquidity Protocol | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/12/1inch-liquidity-protocol/#unspecific-compiler-version-pragma)
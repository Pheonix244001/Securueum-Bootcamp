# Gap Between Periods Can Lead to Erroneous Rewards

Checkbox: Yes
Tags: dos, timing

[public-audits/review.pdf at master · sigp/public-audits](https://github.com/sigp/public-audits/blob/master/synthetix/unipool/review.pdf)

[https://github.com/k06a/Unipool](https://github.com/k06a/Unipool)

gap b/w peroid refers to the time between the end of one reward distribution period and the start of the next one .
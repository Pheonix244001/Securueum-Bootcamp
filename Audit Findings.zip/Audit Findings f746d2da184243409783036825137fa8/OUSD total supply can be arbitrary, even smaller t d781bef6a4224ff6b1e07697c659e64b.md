# OUSD total supply can be arbitrary, even smaller than user balances

Checkbox: Yes
Linked to : spbp [159 169 170]
Problem: EIP-20 invariant balanceOf(x) <= totalSupply() was not met because changeSupply() function was not changing balance of rebaseOptOut users
Recommendation: clear all common invariants voliation for users and stakeholders
Tags: data validation

[publications/OriginDollar.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/OriginDollar.pdf)

feature is having an option to opt out of rebasing 

whoever does that , he/she will not have any impact of rebasing . 

however , changesupply function as only changing the total supply of token but it was not changing the balance of people who have opt out rebasing

as a reuslt total supply can be less than the user balance .

an external smart contract can therefore assume that user balance is greater than total supply which may have unintended consequences
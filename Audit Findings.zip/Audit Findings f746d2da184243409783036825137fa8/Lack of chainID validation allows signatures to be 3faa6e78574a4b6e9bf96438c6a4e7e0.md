# Lack of chainID validation allows signatures to be re-used across forks

Checkbox: Yes
Linked to : spbp[174]
Recommendation: Include chainId opcode in permit schema to avoid replay attack in post deployment hardfork
Tags: access control

[publications/YieldProtocol.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/YieldProtocol.pdf)

[Missing EIP-712 chainID validation](https://www.coinspect.com/missing-EIP-712-chainId-validation/)

ERC 2612 

[ERC-2612: Permit Extension for EIP-20 Signed Approvals](https://eips.ethereum.org/EIPS/eip-2612)

This ERC extends the EIP-20 standard with a new function `permit` , which allows users to modify the `allowance`
 mapping using a signed message, instead of through `msg.sender`.
# Random task execution

Checkbox: Yes
Tags: reentrancy

Malicious External Calls → Reentrancy 

[Reentrancy](Random%20task%20execution%20cb0fc738595a484880b2c37ffcc0e053/Reentrancy%200761fc6e5efe438b99425d9f1fa4d798.md)

Tags used - ReentrancyGuard

[DeFi Saver | ConsenSys Diligence](https://consensys.net/diligence/audits/2021/03/defi-saver/#random-task-execution)
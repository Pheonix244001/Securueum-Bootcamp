# Transfer and safeTransfer

**Use safeTransferFrom() instead of transferFrom()**

[https://github.com/sherlock-audit/2022-11-dodo-judging/issues/47](https://github.com/sherlock-audit/2022-11-dodo-judging/issues/47)

**Incorrect usage of safeTransferFrom**

[Papr contest](https://code4rena.com/reports/2022-12-backed#m-04-incorrect-usage-of-safetransferfrom-traps-fees-in-papr-controller)

**Limited support to a specific subset of ERC20 tokens**

[https://github.com/sherlock-audit/2022-11-buffer-judging/issues/73](https://github.com/sherlock-audit/2022-11-buffer-judging/issues/73)

**Solmate safetransfer and safetransferfrom does not check the code size of the token address, which may lead to funding loss**

[https://github.com/sherlock-audit/2022-11-bond-judging/issues/8](https://github.com/sherlock-audit/2022-11-bond-judging/issues/8)

**Using `ERC721.transferFrom()` instead of `safeTransferFrom()` may cause the user's NFT to be frozen in a contract that does not support**

[https://github.com/sherlock-audit/2022-11-frankendao-judging/issues/55](https://github.com/sherlock-audit/2022-11-frankendao-judging/issues/55)

**Code does not handle ERC20 tokens with special `transfer` implementation**

[https://github.com/sherlock-audit/2022-11-sense-judging/issues/10](https://github.com/sherlock-audit/2022-11-sense-judging/issues/10)

**Unhandled return values of transfer and transferFrom**

[https://github.com/code-423n4/2022-10-inverse-findings/issues/10](https://github.com/code-423n4/2022-10-inverse-findings/issues/10)
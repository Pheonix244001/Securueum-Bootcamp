# Malicious Users Can DOS/Hijack Requests From Chainlinked Contracts

Checkbox: Yes
Tags: dos, timing

[public-audits/review.pdf at master · sigp/public-audits](https://github.com/sigp/public-audits/blob/master/chainlink-1/review.pdf)
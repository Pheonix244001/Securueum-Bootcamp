# Remove unnecessary call to DAOfiV1Factory.formula()

Checkbox: No
Linked to : spbp [ 157 197 ] 
Problem: functions were using a private function to call factory and retrieve address which is set in constructor so cannot be changed 
Recommendation: Just replace function calls with variable reads
Tags: unnecessary code/logic

[DAOfi | ConsenSys Diligence](https://consensys.net/diligence/audits/2021/02/daofi/#remove-unnecessary-call-to-daofiv1factoryformula)
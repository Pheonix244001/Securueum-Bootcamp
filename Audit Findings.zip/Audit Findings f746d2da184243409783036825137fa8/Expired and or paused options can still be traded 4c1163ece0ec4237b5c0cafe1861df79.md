# Expired and/or paused options can still be traded

Checkbox: Yes
Linked to : spl [ 156 ] spbp [ 177 178 137 188 191 ] 
Problem: option tokens can still be freely transferred when the Option contract is either paused or expired (or both)
Recommendation: implement the necessary logic to prevent this transfer of token  or document it if not 
Tags: timing

[Primitive Audit - OpenZeppelin blog](https://blog.openzeppelin.com/primitive-audit/)

Every `Option` contract has an expiry date, [set during initialization](https://github.com/primitivefinance/primitive-protocol/blob/78a8e64b7618e9199203ab84042876c580ae1e90/packages/primitive-contracts/contracts/option/primitives/Option.sol#L68), after which the contract will no longer allow [minting](https://github.com/primitivefinance/primitive-protocol/blob/78a8e64b7618e9199203ab84042876c580ae1e90/packages/primitive-contracts/contracts/option/primitives/Option.sol#L148) new options nor [exercising](https://github.com/primitivefinance/primitive-protocol/blob/78a8e64b7618e9199203ab84042876c580ae1e90/packages/primitive-contracts/contracts/option/primitives/Option.sol#L187) existing ones. Similarly, [minting](https://github.com/primitivefinance/primitive-protocol/blob/78a8e64b7618e9199203ab84042876c580ae1e90/packages/primitive-contracts/contracts/option/primitives/Option.sol#L149) and [exercising](https://github.com/primitivefinance/primitive-protocol/blob/78a8e64b7618e9199203ab84042876c580ae1e90/packages/primitive-contracts/contracts/option/primitives/Option.sol#L188) are also prevented when the `Option` contract is paused by a privileged account in the system.

However, option tokens can still be freely transferred when the `Option`
 contract is either paused or expired (or both). This would allow 
malicious option holders to sell paused / expired options that cannot be
 exercised in the open market to exchanges and users who do not take the
 necessary precautions before buying an option minted by the Primitive 
protocol. Particularly, decentralized exchanges willing to trade 
Primitive’s option tokens should implement the necessary logic in their 
contracts to avoid accepting paused or expired options into their pools.

Should this be the system’s expected behavior, consider clearly 
documenting it in user-friendly documentation so as to raise awareness 
in option sellers and buyers. Moreover, the documentation should include
 a specific section aimed for developers willing to integrate the 
Primitive protocol into their platform, providing the necessary guidance
 on these particular scenarios. Lastly, it should be noted that the 
described behavior is not being covered with unit tests.

Alternatively, if the described behavior is not intended, consider implementing the necessary logic in the `Option`
 contract to prevent transfers of tokens during pause and after 
expiration. Note that the implementation should take into account that 
option tokens might be needed to be transferred back to the `Option` contract, even during pause or after expiration, to be able to still use other features of the protocol.

**Update:** *Not fixed. Expired options can still be 
transferred, and no additional documentation has been added to highlight
 it. Note that the issue no longer applies for paused options, since the
 pausing functionality has been removed altogether from the `Option` contract.*
# Unused Event Logs

Checkbox: No
Linked to : spbp [ 156 173 ] 
Problem: log events were declared but never emit 
Recommendation: emit these events or remove entirely 
Tags: auditing & logging

log events are declared but never emitted.

1. Recommendation: Remove these events from the EtherCollateral contract.

[public-audits/review.pdf at master · sigp/public-audits](https://github.com/sigp/public-audits/blob/master/synthetix/ethercollateral/review.pdf)
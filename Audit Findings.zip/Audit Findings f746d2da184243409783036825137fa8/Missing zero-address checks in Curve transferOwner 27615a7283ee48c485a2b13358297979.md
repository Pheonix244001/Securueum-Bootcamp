# Missing zero-address checks in Curve.transferOwnership and Router.constructor

Checkbox: No
Linked to : spbp [ 49 138 146 162 169 ] 
Problem: functions were missing zero address check  in  Curve.transferOwnershipand Router.constructor functions 
Recommendation: the code that set state variables should perform zero address check 
Tags: data validation

[protocol-v1-deprecated/2021-05-03-Trail_of_Bits.pdf at main · dfx-finance/protocol-v1-deprecated](https://github.com/dfx-finance/protocol/blob/main/audits/2021-05-03-Trail_of_Bits.pdf)

Like other similar functions, *Curve._transfer* and *Orchestrator.includeAsset* perform zero-address checks. However, *Curve.transferOwnership* and the Router constructor do not. This may make sense for *Curve.transferOwnership*,
 because without zero-address checks, the function may serve as a means 
of burning ownership. However, popular contracts that define similar 
functions often consider this case, such as OpenZeppelin’s *Ownable*
 contracts. Conversely, a zero-address check should be added to the 
Router constructor to prevent the deployment of an invalid Router, which
 would revert upon a call to the zero address.

1. Recommendation: Short term, consider adding zero-address checks to the Router’s constructor and Curve’s *transferOwnership* function to prevent operator errors. Long term, review state variables
which referencing contracts to ensure that the code that sets the state
variables performs zero-address checks where necessary
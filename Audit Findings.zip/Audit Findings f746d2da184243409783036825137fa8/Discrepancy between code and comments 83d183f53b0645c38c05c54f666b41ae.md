# Discrepancy between code and comments

Checkbox: No
Linked to : spbp [ 154 137 188 ] 
Problem: mistach between code implementation and comment description
Recommendation: Update the code or the comment to be consistent.
Tags: documentation

[mStable 1.1 | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/07/mstable-1.1/#discrepancy-between-code-and-comments)
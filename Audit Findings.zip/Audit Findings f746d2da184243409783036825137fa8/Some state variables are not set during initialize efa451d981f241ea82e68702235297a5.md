# Some state variables are not set during initialize

Checkbox: No
Linked to : sol [ 185-192] spbp [ 96 165 ]
Problem: some state variable were not set during the initialize
Recommendation: set all the variables in initializer or check that they should not be called before initilization
Tags: configuration

[Audius Contracts Audit - OpenZeppelin blog](https://blog.openzeppelin.com/audius-contracts-audit/#medium)

The Audius contracts can be upgraded using the [unstructured storage proxy pattern](https://docs.openzeppelin.com/upgrades/2.8/proxies).
 This pattern requires the use of an initializer instead of the 
constructor to set the initial values of the state variables. In some of
 the contracts, the initializer is not initializing all of the state 
variables.

For example, in the `[initializer` function of the `ClaimsManager` contract](https://github.com/AudiusProject/audius-protocol/blob/6f3b31562b9d4c43cef91af0a011986a2580fba2/eth-contracts/contracts/ClaimsManager.sol#L78) the `[stakingAddress` state variable](https://github.com/AudiusProject/audius-protocol/blob/6f3b31562b9d4c43cef91af0a011986a2580fba2/eth-contracts/contracts/ClaimsManager.sol#L17) is not set. It can be set later by calling `[setStakingAddress](https://github.com/AudiusProject/audius-protocol/blob/6f3b31562b9d4c43cef91af0a011986a2580fba2/eth-contracts/contracts/ClaimsManager.sol#L163)`. However, this means that it is possible to call the `[processClaim` function](https://github.com/AudiusProject/audius-protocol/blob/6f3b31562b9d4c43cef91af0a011986a2580fba2/eth-contracts/contracts/ClaimsManager.sol#L227) and some others without any staking address set, because they only [check that the contract has been initialized](https://github.com/AudiusProject/audius-protocol/blob/6f3b31562b9d4c43cef91af0a011986a2580fba2/eth-contracts/contracts/ClaimsManager.sol#L232).

The same happens in the `[initializer` function of the `Governance` contract](https://github.com/AudiusProject/audius-protocol/blob/6f3b31562b9d4c43cef91af0a011986a2580fba2/eth-contracts/contracts/Governance.sol#L122), which does not set the `[stakingAddress](https://github.com/AudiusProject/audius-protocol/blob/6f3b31562b9d4c43cef91af0a011986a2580fba2/eth-contracts/contracts/Governance.sol#L20)` either.

Consider setting all the required variables in the initializer. If 
there is a reason for leaving them uninitialized consider documenting 
it, and adding checks on the functions that use those variables to 
ensure that they are not called before initialization.

***Update**: Fixed in [pull request #589](https://github.com/AudiusProject/audius-protocol/pull/589).*
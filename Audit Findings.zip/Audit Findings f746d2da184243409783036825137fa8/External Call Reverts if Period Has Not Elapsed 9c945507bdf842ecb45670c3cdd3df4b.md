# External Call Reverts if Period Has Not Elapsed

Checkbox: No
Linked to : spbp [159 175]
Problem: mint process requires external call . if external call gets failed then mint process will halt 
Recommendation: Consider handling the case where the reward period has not elapsed without reverting the call.
Tags: error handling

[public-audits/review.pdf at master · sigp/public-audits](https://github.com/sigp/public-audits/blob/master/synthetix/unipool/review.pdf)

[https://github.com/k06a/Unipool](https://github.com/k06a/Unipool)

The function notifyRewardAmount() will revert if block.timestamp >= periodFinish . However this func-

tion is called indirectly via the Synthetix.mint() function.

This could be because the minting of a synthetic asset triggers a new 
reward period, or because the minting function is responsible for 
allocating rewards to stakers. By calling `notifyRewardAmount()`
 indirectly via `Synthetix.mint()`
, the smart contract can ensure that the reward period is updated correctly and that stakers receive their rewards on time.
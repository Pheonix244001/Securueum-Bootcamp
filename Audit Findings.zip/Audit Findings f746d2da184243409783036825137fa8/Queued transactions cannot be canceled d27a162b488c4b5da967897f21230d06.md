# Queued transactions cannot be canceled

Checkbox: Yes
Linked to : spbp{176]
Problem: no way to cancel incorrect queued transaction by governor 
Recommendation: add a function of cancelling for governor or let governor inherit form timelock
Tags: access control, dos

[publications/OriginDollar.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/OriginDollar.pdf)
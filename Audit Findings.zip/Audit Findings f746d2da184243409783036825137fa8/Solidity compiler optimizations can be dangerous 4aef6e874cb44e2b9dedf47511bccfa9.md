# Solidity compiler optimizations can be dangerous

Checkbox: No
Linked to : sol [ 1 77-94 ] spbp [ 183]
Problem: compiler optimizatons are error prone 
Recommendation: evaluate the tradeoff 
Tags: optimization

[publications/YieldProtocol.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/YieldProtocol.pdf)

Yield Protocol has enabled optional compiler optimizations in 
Solidity. There have been several bugs with security implications 
related to optimizations. Moreover, optimizations are actively being 
developed . Solidity compiler optimizations are disabled by default, and
 it is unclear how many contracts in the wild actually use them. 
Therefore, it is unclear how well they are being tested and exercised. 
High-severity security issues due to optimization bugs have occurred in 
the past . A high-severity bug in the emscripten -generated solc-js 
compiler used by Truffle and Remix persisted until late 2018. The fix 
for this bug was not reported in the Solidity CHANGELOG. Another 
high-severity optimization bug resulting in incorrect bit shift results 
was patched in Solidity 0.5.6 .

1. Recommendation:
Short term, measure the gas savings from optimizations, and carefully
weigh them against the possibility of an optimization-related bug. Long
term, monitor the development and adoption of Solidity compiler
optimizations to assess their maturity.
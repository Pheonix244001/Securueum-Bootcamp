# Use of uint instead of uint256

Checkbox: No
Linked to : spbp [ 164 188 ] 
Problem: using uint instead uin256 
Recommendation: replace all those instances 
Tags: specification

[Fei Protocol Audit - OpenZeppelin blog](https://blog.openzeppelin.com/fei-protocol-audit/)

Across the codebase, there are hundreds of instances of *uint*, as opposed to *uint256*.

1. Recommendation: In favor of explicitness, consider replacing all instances of *uint* with *uint256*.
# Wrong Order of Operations Leads to Exponentiation of rewardPerTokenStored

Checkbox: Yes
Tags: ordering

[public-audits/review.pdf at master · sigp/public-audits](https://github.com/sigp/public-audits/blob/master/synthetix/unipool/review.pdf)
# Delegate assignment front-running

Checkbox: Yes
Linked to : spbp[176 21]
Problem: front running possible
Recommendation: use commir reveal hash method
Tags: dos, timing

[The LAO | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/01/the-lao/#delegate-assignment-front-running)
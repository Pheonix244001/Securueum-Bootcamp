# Unchecked output of the ECDSA recover function

Checkbox: No
Linked to : sol [ 166] spbp [ 49 174 175 ] 
Problem: ECDSA function set address(0) if it is invalid , which can cause unitended behaviour . It can allow user to perform some interaction on behalf of zero address 
Recommendation: revert if the ECDSA.recover is ever address (0) . Also modify the Registry.addOracle such that address (0)  can never be added as an oracle
Tags: error handling

[Futureswap V2 Audit - OpenZeppelin blog](https://blog.openzeppelin.com/futureswap-v2-audit/)

The `[ECDSA.recover` function](https://github.com/OpenZeppelin/openzeppelin-contracts/blob/v2.5.1/contracts/cryptography/ECDSA.sol#L28) (in version `2.5.1`) returns `address(0)` if the signature provided is invalid. This function is used twice in the Futureswap code: Once [to recover an `oracleAddress` from an `oracleSignature`](https://github.com/futureswap/fs_core/blob/96255fc4a550a5f34681c117b5969b848d07b3a3/contracts/messageProcessor/MessageProcessor.sol#L845), and again [to recover the user’s address from their signature](https://github.com/futureswap/fs_core/blob/96255fc4a550a5f34681c117b5969b848d07b3a3/contracts/messageProcessor/MessageProcessor.sol#L535).

If the oracle signature was invalid, the `oracleAddress` is set to `address(0)`. Similarly, if the user’s signature is invalid, then [the `userMessage.signer`](https://github.com/futureswap/fs_core/blob/96255fc4a550a5f34681c117b5969b848d07b3a3/contracts/messageProcessor/MessageProcessor.sol#L517) or [the `withDrawer`](https://github.com/futureswap/fs_core/blob/96255fc4a550a5f34681c117b5969b848d07b3a3/contracts/messageProcessor/MessageProcessor.sol#L418) is set to `address(0)`.

This can result in unintended behavior. For example, it allows users 
to perform some interactions on behalf of the zero address, or (in the 
unlikely event that `address(0)` were ever added as an oracle) it could allow all invalid `oracleSignature`s to be accepted as valid.

Consider reverting if the output of the `ECDSA.recover` is ever `address(0)`. Also, consider modifying the `[Registry.addOracle` function](https://github.com/futureswap/fs_core/blob/96255fc4a550a5f34681c117b5969b848d07b3a3/contracts/registry/Registry.sol#L241) so that `address(0)` can never be added as an oracle.
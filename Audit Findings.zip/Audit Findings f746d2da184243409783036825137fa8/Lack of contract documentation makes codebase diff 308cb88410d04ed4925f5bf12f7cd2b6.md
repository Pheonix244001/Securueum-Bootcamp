# Lack of contract documentation makes codebase difficult to understand

Checkbox: No
Linked to : spbp [ 136 137 199 ] 
Problem: codebase lacking documentation 
Recommendation: properly document 
Tags: documentation

[publications/AdvancedBlockchain.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/AdvancedBlockchain.pdf)

The codebase lacks code documentation, high-level descriptions,
 and examples, making the contracts difficult to review and increasing 
the likelihood of user mistakes. The documentation would benefit from 
more detail.

1. Recommendation: Short term, review and properly document the above mentioned aspects of the codebase. Long
term, consider writing a formal specification of the protocol.
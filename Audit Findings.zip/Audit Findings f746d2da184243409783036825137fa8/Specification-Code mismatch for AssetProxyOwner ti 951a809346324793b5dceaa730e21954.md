# Specification-Code mismatch for AssetProxyOwner timelock period

Checkbox: Yes
Linked to : spbp [136 155 188] 
Tags: specification

[publications/0x-protocol.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/0x-protocol.pdf)
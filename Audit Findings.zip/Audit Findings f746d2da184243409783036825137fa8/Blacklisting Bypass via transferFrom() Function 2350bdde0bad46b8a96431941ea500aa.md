# Blacklisting Bypass via transferFrom() Function

Checkbox: No
Linked to : spbp [ 4 141 150 152 172 ]
Problem: transferfrom function does not verify wether the account is blacklisted or not . Blacklisting mechanism can be bypassed completly
Recommendation: notBlacklisted(address) modifier should be used a against the from address.
Tags: access control

[](https://github.com/sigp/public-audits/raw/master/infinigold/review.pdf)
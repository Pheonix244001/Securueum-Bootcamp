# Assimilators use a deprecated Chainlink API

Checkbox: No
Linked to : spbp [165 180 193 ]
Problem: usign depricated chainlink api
Recommendation: use the latest stable versions  of api
Tags: patching

[protocol-v1-deprecated/2021-05-03-Trail_of_Bits.pdf at main · dfx-finance/protocol-v1-deprecated](https://github.com/dfx-finance/protocol/blob/main/audits/2021-05-03-Trail_of_Bits.pdf)
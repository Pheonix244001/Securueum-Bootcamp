# Certain functions lack input validation routines

Checkbox: No
Linked to : spbp [138 146]
Problem: Lack of input validation
Recommendation: Add Check Testing and input validation Use check effect interaction pattern 
Tags: input validation

[Input Validation](Certain%20functions%20lack%20input%20validation%20routines%20d79ccf69049a4088b9046774cede17fe/Input%20Validation%20c4221df240cd48089b15c9b830f2dd3a.md)

```solidity
function includeAsset (address _numeraire, address _nAssim, address _reserve, address _rAssim, uint256 _weight) public onlyOwner {
    shell.includeAsset(_numeraire, _nAssim, _reserve, _rAssim, _weight);
}

// The internal function called by the public method includeAsset again doesn’t check any of the data.
```

[Shell Protocol | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/06/shell-protocol/#certain-functions-lack-input-validation-routines)

These checks should include, but not be limited to:

- `uint` should be larger than `0` when `0` is considered invalid
- `uint` should be within constraints
- `int` should be positive in some cases
- length of arrays should match if more arrays are sent as arguments
- addresses should not be `0x0`
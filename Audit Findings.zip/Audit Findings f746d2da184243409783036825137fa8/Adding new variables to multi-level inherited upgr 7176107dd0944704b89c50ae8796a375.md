# Adding new variables to multi-level inherited upgradeable contracts may break storage layout

Checkbox: Yes
Linked to : sol [ 185-192 ] spbp [ 99 165 ]
Problem: in an unstructured storage pattern and working with multilevel inheritance , new variable introduction in in parent contract can change storage layout of child 
Recommendation: prevent this scenario by adding a storage gap in each  upgradable parent contract at the end of all the storage variable definiton for future variable addition 
Tags: configuration

[Notional Audit - OpenZeppelin blog](https://blog.openzeppelin.com/notional-audit/)

The Notional protocol uses the [OpenZeppelin/SDK](https://github.com/OpenZeppelin/openzeppelin-sdk/tree/v2.8.2) contracts to manage upgradeability in the system, which follows the [unstructured storage pattern](https://blog.openzeppelin.com/upgradeability-using-unstructured-storage/).
 When using this upgradeability approach, and when working with 
multi-level inheritance, if a new variable is introduced in a parent 
contract, that addition can potentially overwrite the beginning of the 
storage layout of the child contract, causing critical misbehaviors in 
the system.

It has to be noted that this same issue can arise from adding new 
variables to any other external contract used in the inheritance chain, 
such as the `[Ownable](https://github.com/notional-finance/contracts/blob/b6fc6be4622422d0e34c90e77f2ec9da18596b8c/contracts/upgradeable/Ownable.sol)` contract in the `upgradeable` folder.

For custom contracts, consider preventing these scenarios by defining
 a storage gap in each upgradeable parent contract at the end of all the
 storage variable definitions as follows:

`uint256[50] __gap; // gap to reserve storage in the contract for future variable additions`

In such an implementation, the size of the gap would be intentionally
 decreased each time a new variable was introduced, thereby avoiding 
overwriting preexisting storage values.

Additionally, instead of using contracts copied from the `[OpenZeppelin/contracts](https://github.com/OpenZeppelin/openzeppelin-contracts/tree/v3.3.0)` such as `Ownable`, consider using the `[openzeppelin-contracts-upgradeable` package](https://github.com/OpenZeppelin/openzeppelin-contracts-upgradeable)
 which already defines the forementioned gap. Using said package would 
also enable the system to benefit from any future changes implemented in
 this and any other contracts provided by the OpenZeppelin team.
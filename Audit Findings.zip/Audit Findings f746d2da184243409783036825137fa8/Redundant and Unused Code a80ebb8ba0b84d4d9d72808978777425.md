# Redundant and Unused Code

Checkbox: No
Linked to : spbp [ 157 ] 
Problem: redundant and unused codes 
Recommendation: remove such constructs 
Tags: patching

[public-audits/review.pdf at master · sigp/public-audits](https://github.com/sigp/public-audits/blob/master/synthetix/ethercollateral/review.pdf)

The *_recordLoanClosure()* function returns a boolean ( *loanClosed* ) which is never used by the calling function (see *_closeLoan*() , line [312]). Furthermore, since the *_recordLoanClosure*() function is only called via the *_closeLoan*() function, this means that *synthLoan.timeClosed* is always equal to zero (see *require* statement on line [305]). Therefore, the if statement on line [357] is redundant and unnecessary.

1. Recommendation: 1) Using the return value of the *_recordLoanClosure*() function or changing the function definition to stop returning *loanClosed* 2) Removing the if statement in line [357]
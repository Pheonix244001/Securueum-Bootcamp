# GenesisGroup.emergencyExit remains functional after launch

Checkbox: No
Linked to : spbp [145 178 143 177]
Problem: EmergencyExit remained functional after launch 
Recommendation: Ensure emergencyExit cannot be called if launch has been called and vice-versa
Tags: timing

[Fei Protocol | ConsenSys Diligence](https://consensys.net/diligence/audits/2021/01/fei-protocol/#genesisgroupemergencyexit-remains-functional-after-launch)

`emergencyExit` is intended as an escape mechanism for users in the event the genesis `launch` method fails or is frozen. `emergencyExit` becomes callable 3 days after `launch`
 is callable. These two methods are intended to be mutually-exclusive, 
but are not: either method remains callable after a successful call to 
the other.

This may result in accounting edge cases. In particular, `emergencyExit` fails to decrease `totalCommittedFGEN` by the exiting user’s commitment:
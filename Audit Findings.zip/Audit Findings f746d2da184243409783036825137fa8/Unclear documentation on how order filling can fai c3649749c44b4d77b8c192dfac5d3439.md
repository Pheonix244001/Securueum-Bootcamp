# Unclear documentation on how order filling can fail

Checkbox: Yes
Problem: no clear documentation about the determination wether orders are fillable or not 
Tags: specification

[https://raw.githubusercontent.com/trailofbits/publications/master/reviews/0x-protocol.pdf](https://raw.githubusercontent.com/trailofbits/publications/master/reviews/0x-protocol.pdf)
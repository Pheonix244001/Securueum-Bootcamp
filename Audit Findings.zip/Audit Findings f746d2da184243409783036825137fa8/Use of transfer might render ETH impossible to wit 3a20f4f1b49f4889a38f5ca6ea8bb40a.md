# Use of transfer might render ETH impossible to withdraw

Checkbox: No
Linked to : sol [33 34 47 159 ]  spbp [15 27 176 ]   
Problem: using of transfer function can fail if ( see description below ) 
Recommendation: instead use senvalue function . and check for reentrancy by guard 
Tags: dos

[Opyn Gamma Protocol Audit - OpenZeppelin blog](https://blog.openzeppelin.com/opyn-gamma-protocol-audit/)

When withdrawing ETH deposits, the `[PayableProxyController` contract](https://github.com/opynfinance/GammaProtocol/blob/d151621b33134789b29dc78eb89dad2b557b25b9/contracts/external/proxies/PayableProxyController.sol#L19) uses Solidity’s `[transfer` function](https://github.com/opynfinance/GammaProtocol/blob/d151621b33134789b29dc78eb89dad2b557b25b9/contracts/external/proxies/PayableProxyController.sol#L73).
 This has some notable shortcomings when the withdrawer is a smart 
contract, which can render ETH deposits impossible to withdraw. 
Specifically, the withdrawal will inevitably fail when:

- **The withdrawer smart contract does not implement a payable fallback function.**
- **The withdrawer smart contract implements a payable fallback function which uses more than 2300 gas units.**
- **The withdrawer smart contract implements a payable fallback function which needs less than 2300 gas units but is called through a proxy that raises the call’s gas usage above 2300.**

To prevent unexpected behavior and potential loss of funds, consider 
explicitly warning end-users about the mentioned shortcomings to raise 
awareness before they deposit Ether into the protocol. Additionally, 
note that the `[sendValue` function](https://github.com/OpenZeppelin/openzeppelin-contracts/blob/v2.5.1/contracts/utils/Address.sol#L63) available in OpenZeppelin Contract’s `Address`
 library can be used to transfer the withdrawn Ether without being 
limited to 2300 gas units. Risks of reentrancy stemming from the use of 
this function can be mitigated by tightly following the [“Check-effects-interactions” pattern](https://solidity.readthedocs.io/en/latest/security-considerations.html#use-the-checks-effects-interactions-pattern) and using OpenZeppelin Contract’s `[ReentrancyGuard` contract](https://github.com/OpenZeppelin/openzeppelin-contracts/blob/v2.5.1/contracts/utils/ReentrancyGuard.sol). For further reference on why using Solidity’s `transfer` is no longer recommended, refer to these articles:

- [Stop using Solidity’s transfer now](https://diligence.consensys.net/blog/2019/09/stop-using-soliditys-transfer-now/)
- [Reentrancy after Istanbul](https://blog.openzeppelin.com/reentrancy-after-istanbul/)

**Update:** *Fixed in [PR#305](https://github.com/opynfinance/GammaProtocol/pull/305).*
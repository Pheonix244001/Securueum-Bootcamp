# Updating the Governance registry and Guardian addresses emits no events

Checkbox: No
Linked to : spbp [ 45 173 201 ] 
Problem: no events were emmited when sensitive variables were updates . check details 
Recommendation: consider emmiting these events
Tags: auditing & logging

[https://blog.openzeppelin.com/audius-contracts-audit/#high](https://blog.openzeppelin.com/audius-contracts-audit/#high)

In the `Governance` contract the `[registryAddress](https://github.com/AudiusProject/audius-protocol/blob/6f3b31562b9d4c43cef91af0a011986a2580fba2/eth-contracts/contracts/Governance.sol#L17)` and the `[guardianAddress](https://github.com/AudiusProject/audius-protocol/blob/6f3b31562b9d4c43cef91af0a011986a2580fba2/eth-contracts/contracts/Governance.sol#L32)`
 are highly sensitive accounts. The first one holds the contracts that 
can be proposal targets, and the second one is a superuser account that 
can execute proposals without voting.

These variables can be updated by calling `[setRegistryAddress](https://github.com/AudiusProject/audius-protocol/blob/6f3b31562b9d4c43cef91af0a011986a2580fba2/eth-contracts/contracts/Governance.sol#L477)` and `[transferGuardianship](https://github.com/AudiusProject/audius-protocol/blob/6f3b31562b9d4c43cef91af0a011986a2580fba2/eth-contracts/contracts/Governance.sol#L543)`,
 respectively. Note that these two functions update these sensitive 
addresses without logging any events. Stakers who monitor the Audius 
system would have to inspect all transactions to notice that one address
 they trust is replaced with an untrusted one.

Consider emitting events when these addresses are updated. This will 
be more transparent, and it will make it easier for clients to subscribe
 to the events when they want to keep track of the status of the system
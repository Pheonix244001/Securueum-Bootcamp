# Require a delay period before granting KYC_ADMIN_ROLE  Acknowledged

Checkbox: Yes
Linked to : sol [ 182 ] spbp [ 163 153 177 181 ] 
Problem: admin could revoke kyc , trust could be slightly decreased  by implementing a delay on granting this ability to new addresses
Recommendation: Add TimeLock to Granting Privileges 
Tags: access control, timing

[eRLC iExec | ConsenSys Diligence](https://consensys.net/diligence/audits/2021/01/erlc-iexec/#erlc-require-a-delay-period-before-granting-kyc_admin_role)
# Chainlink pricer is using a deprecated API

Checkbox: No
Problem: deprecated chainlink api 
Recommendation: use latest api 
Tags: patching

[Opyn Gamma Protocol Audit - OpenZeppelin blog](https://blog.openzeppelin.com/opyn-gamma-protocol-audit/)
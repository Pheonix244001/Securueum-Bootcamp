# Users can collect interest from SavingsContract by only staking mTokens momentarily

Checkbox: No
Linked to : spbp [142 177]
Problem: Abuse of Sliding Window 
Recommendation: Remove Window Anticipate/Prevent Abuse Such that that every deposit also updates the exchange rate between credits and tokens
Tags: timing

[mStable 1.1 | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/07/mstable-1.1/#users-can-collect-interest-from-savingscontract-by-only-staking-mtokens-momentarily)
# Underflow if TOKEN_DECIMALS are greater than 18

Checkbox: No
Linked to : spbp [ 19 136 137 169 170  ] 
Problem: decimal > 18 problem 
Recommendation: add a simple check in the constructor to ensure that the added token has 18 decimals or less 
Tags: input validation

[Aave CPM Price Provider | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/05/aave-cpm-price-provider/#underflow-if-token-decimals-are-greater-than-18)

In *latestAnswer*(), the assumption is made that *TOKEN_DECIMALS* is less than 18.

1. Recommendation: Add a simple check to the constructor to ensure the added token has 18 decimals or less
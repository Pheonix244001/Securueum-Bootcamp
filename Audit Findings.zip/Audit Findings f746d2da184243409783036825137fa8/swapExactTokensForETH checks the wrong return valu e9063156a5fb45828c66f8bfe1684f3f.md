# swapExactTokensForETH checks the wrong return value

Checkbox: No
Problem: had to check (amount of token recieved > min amount ) , but checked (initial reciever balance - router balance)
Recommendation: Find if something is checking exactly what should it check or else
Tags: error handling

[DAOfi | ConsenSys Diligence](https://consensys.net/diligence/audits/2021/02/daofi/#the-swapexacttokensforeth-checks-the-wrong-return-value)

The following lines are intended to check that the amount of tokens 
received from a swap is greater than the minimum amount expected from 
this swap (`sp.amountOut`):

**code/daofi-v1-periphery/contracts/DAOfiV1Router01.sol:L341-L345**

`uint amountOut = IWETH10(WETH).balanceOf(address(this));
require(
    IWETH10(sp.tokenOut).balanceOf(address(this)).sub(balanceBefore) >= sp.amountOut,
    'DAOfiV1Router: INSUFFICIENT_OUTPUT_AMOUNT'
);`

Instead, it calculates the difference between the initial receiver’s balance and the balance of the router.
# Anyone can steal all the funds that belong to ReferralFeeReceiver

Checkbox: No
Linked to : spbp [ 136 137 148 149 155 169 172 ] 
Problem: not checking if the address is actually deployed 
Recommendation: enusre the deployment and impelemtn token sorting and de-duplication , reentrancy guard ,testing , documentation
Tags: access control, data validation

[1inch Liquidity Protocol | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/12/1inch-liquidity-protocol/#out-of-scope-referralfeereceiver---anyone-can-steal-all-the-funds-that-belong-to-referralfeereceiver)
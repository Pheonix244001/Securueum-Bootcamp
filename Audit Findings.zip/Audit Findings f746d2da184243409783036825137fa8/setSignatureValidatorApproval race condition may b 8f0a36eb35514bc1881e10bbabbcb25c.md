# setSignatureValidatorApproval race condition may be exploitable

Checkbox: No
Linked to : spbp [ 21 177 180 181 201 ]  
Problem: user can delegate signature approval to validator . if validator is compromised , it can validate all the transaction before the call to remove validation gets approved 
Recommendation: document this behaviour and also monitor the chain for approval event to prevent front running 
Tags: timing

[publications/0x-protocol.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/0x-protocol.pdf)
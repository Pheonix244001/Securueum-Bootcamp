# Token approvals can be stolen in DAOfiV1Router01.addLiquidity()

Checkbox: No
Linked to : spbp [ 148 149 160 172 180 181 183 ]
Problem: No address validation
Recommendation: Transfer tokens from msg.sender  instead of lp.sender
Tags: input validation

[DAOfi | ConsenSys Diligence](https://consensys.net/diligence/audits/2021/02/daofi/#token-approvals-can-be-stolen-in-daofiv1router01addliquidity)

There is no validation of the address to transfer tokens from, so an 
attacker could pass in any address with nonzero token approvals to `DAOfiV1Router`
. This could be used to add liquidity to a pair contract for which the attacker is the `pairOwner`
, allowing the stolen funds to be retrieved using `DAOfiV1Pair.withdraw()`

Importance of correct address check . 148 149 160 172 180 181 183 ,

input validation 138 159
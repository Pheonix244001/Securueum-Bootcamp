# Unsafe division in rdivide and wdivide functions

Checkbox: No
Linked to : sol [175] spbp [138 169] 
Problem: division input not checking if the divisor is zero . 
Recommendation: use div function of openzeppelin safeMath libraries or add a require statment 
Tags: data validation

[GEB Protocol Audit - OpenZeppelin blog](https://blog.openzeppelin.com/geb-protocol-audit/)

The function `[rdivide` on line 227](https://github.com/reflexer-labs/geb/blob/261407b6b332c2063e4256aa5f9b223d52dad7e1/src/GlobalSettlement.sol#L227) and the function `[wdivide` on line 230](https://github.com/reflexer-labs/geb/blob/261407b6b332c2063e4256aa5f9b223d52dad7e1/src/GlobalSettlement.sol#L230) of the `GlobalSettlement` contract, accept the divisor `y` as an input parameter. However, these functions do not check if the value of `y` is `0`. If that is the case, the call will revert due to the division by zero error.

Other occurrences of unsafe division functions are:

- `[rdivide](https://github.com/reflexer-labs/geb/blob/261407b6b332c2063e4256aa5f9b223d52dad7e1/src/CollateralAuctionHouse.sol#L150)`, `[rdivide](https://github.com/reflexer-labs/geb/blob/261407b6b332c2063e4256aa5f9b223d52dad7e1/src/CollateralAuctionHouse.sol#L482)` and `[wdivide](https://github.com/reflexer-labs/geb/blob/261407b6b332c2063e4256aa5f9b223d52dad7e1/src/CollateralAuctionHouse.sol#L485)` in the `CollateralAuctionHouse` contract.
- `[rdivide](https://github.com/reflexer-labs/geb/blob/261407b6b332c2063e4256aa5f9b223d52dad7e1/src/OracleRelayer.sol#L132)` in the `OracleRelayer` contract.

To prevent such unsafe calculations, consider adding a require statement in the functions to ensure `y &gt; 0`, or consider using the `div` functions provided in OpenZeppelin’s `[SafeMath](https://github.com/OpenZeppelin/openzeppelin-contracts/blob/ae69ecaf014beac078b4c21da8a83cf005713469/contracts/math/SafeMath.sol#L103)` libraries.

***Update:** Fixed in [pull request #77.](https://github.com/reflexer-labs/geb/pull/77/files)*
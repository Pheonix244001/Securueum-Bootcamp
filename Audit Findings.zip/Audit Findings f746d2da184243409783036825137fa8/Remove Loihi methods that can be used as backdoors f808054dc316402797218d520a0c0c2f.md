# Remove Loihi methods that can be used as backdoors by the administrator

Checkbox: Yes
Linked to : spbp [ 148 149 160 172 192 193 ]
Problem: Admin could Abuse Backdoor Least privilege 
Recommendation: Make Code Static  Increase Trust
Tags: access control

[Shell Protocol | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/06/shell-protocol/#remove-loihi-methods-that-can-be-used-as-backdoors-by-the-administrator)

tags used - admin

admin have too much privilege . As a result if admin is malicious or in case if admin does it unknowingly , can do many things with the smart contract 

In addition to these, the function `safeApprove` allows 
the administrator to move any of the tokens the contract holds to any 
address regardless of the balances any of the users have.

This can also be used by the owner as a backdoor to completely drain the contract.
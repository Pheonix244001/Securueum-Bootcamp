# oToken can be created with a non-whitelisted collateral asset

Checkbox: No
Linked to : spbp [ 132 159 180 183 ] 
Problem: protocil token could be create with non - whitelisted collateral assets 
Recommendation: validate whitelisting 
Tags: data validation

[Opyn Gamma Protocol Audit - OpenZeppelin blog](https://blog.openzeppelin.com/opyn-gamma-protocol-audit/)

A product consists of a set of assets and an option type. Each product has to be whitelisted by the admin using the *whitelistProduct* function from the Whitelist contract.

1. Recommendation: Consider validating if the assets involved in a product have been
already whitelisted before allowing the creation of *oTokens*.
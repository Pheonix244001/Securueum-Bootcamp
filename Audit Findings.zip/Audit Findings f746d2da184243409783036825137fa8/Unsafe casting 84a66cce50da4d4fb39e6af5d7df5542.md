# Unsafe casting

Checkbox: Yes
Linked to : sol [ 177 ] spbp [ 19 169 170 ] 
Problem: unsafe casting uint → int 
Recommendation: verify range and use safecast 
Tags: data validation

In line 554 of the *TaxCollector* contract, the value of *coinBalance(receiver)* is an *uint*. This is cast to an *int* and then negated. However, since *uint* can store higher values than *int*, it is possible that casting from *uint* to *int* may create an overflow.

1. Recommendation: Consider verifying that the value of *coinBalance(receiver)* is within the acceptable range for negative *int* values before casting and negating. Consider using OpenZeppelin’s *SafeCast* contract, which provides functions for safely casting between types.

[GEB Protocol Audit - OpenZeppelin blog](https://blog.openzeppelin.com/geb-protocol-audit/)
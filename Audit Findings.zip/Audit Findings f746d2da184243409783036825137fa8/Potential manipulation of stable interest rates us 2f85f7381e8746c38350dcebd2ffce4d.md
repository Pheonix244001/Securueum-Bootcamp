# Potential manipulation of stable interest rates using flash loans

Checkbox: Yes
Tags: flash loans

[Aave Protocol V2 | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/09/aave-protocol-v2/#potential-manipulation-of-stable-interest-rates-using-flash-loans)

Flash loans allow users to borrow large amounts of liquidity 
from the protocol. It is possible to adjust the stable rate up or down 
by momentarily removing or adding large amounts of liquidity to 
reserves.

1. Recommendation: This type of
manipulation is difficult to prevent especially when flash loans are
available. Aave should monitor the protocol at all times to make sure
that interest rates are being rebalanced to sane values
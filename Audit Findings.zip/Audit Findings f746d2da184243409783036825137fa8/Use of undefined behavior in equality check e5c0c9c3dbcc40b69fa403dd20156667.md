# Use of undefined behavior in equality check

Checkbox: No
Linked to : spbp[179]
Problem: using and assigning the same variable in equality check 
Recommendation: rewrite the equality 
Tags: undefined behaviour

[protocol-v1-deprecated/2021-05-03-Trail_of_Bits.pdf at main · dfx-finance/protocol-v1-deprecated](https://github.com/dfx-finance/protocol/blob/main/audits/2021-05-03-Trail_of_Bits.pdf)

```solidity
if (
(outputAmt_ = _omega < _psi
? -(_inputAmt + _omega - _psi)
: -(_inputAmt + _lambda.us_mul(_omega - _psi))) /
1e13 ==
outputAmt_ / 1e13
) {

```
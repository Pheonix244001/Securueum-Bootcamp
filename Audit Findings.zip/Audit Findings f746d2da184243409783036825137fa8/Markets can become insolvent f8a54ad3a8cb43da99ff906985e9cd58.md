# Markets can become insolvent

Checkbox: Yes
Tags: specification

[Holdefi Audit - OpenZeppelin blog](https://blog.openzeppelin.com/holdefi-audit)

When the value of all collateral is worth less than the value 
of all borrowed assets, we say a market is insolvent. The Holdefi 
codebase can do many things to reduce the risk of market insolvency, 
including: prudent selection of collateral-ratios, incentivizing 
third-party collateral liquidation, careful selection of which tokens 
are listed on the platform, etc. However, the risk of insolvency cannot 
be entirely eliminated, and there are numerous ways a market can become 
insolvent.

1. Recommendation: This risk is not unique
to the Holdefi project. All collateralized loans (even non-blockchain
loans) have a risk of insolvency. However, it is important to know that
this risk does exist, and that it can be difficult to recover from even a small dip into insolvency. Consider adding more targeted tests for
these scenarios to better understand the behavior of the protocol, and
designing relevant mechanics to make sure the platform operates
properly. Also consider communicating the potential risks to the users
if needed.
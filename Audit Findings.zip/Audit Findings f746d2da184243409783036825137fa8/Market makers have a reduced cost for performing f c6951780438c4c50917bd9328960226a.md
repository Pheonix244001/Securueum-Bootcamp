# Market makers have a reduced cost for performing front-running attacks

Checkbox: Yes
Linked to : spbp { 21 177 182 187 } 
Tags: timing

[publications/0x-protocol.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/0x-protocol.pdf)

The protocol fee is a percentage of the transaction value and is paid by the taker (the user who initiates the trade) to the protocol.

The protocol fee is calculated based on the gas price that the transaction uses to get confirmed on the Ethereum blockchain. The higher the gas price, the faster the transaction will be confirmed. Market makers can take advantage of this by specifying a higher gas price than usual, which will increase the probability of their order being filled before others.

When a market maker specifies a higher gas price, they may pay more in transaction fees upfront. However, since they receive a portion of the protocol fee for each order they fill, they can offset the higher gas price by earning a larger share of the protocol fee.

Moreover, market makers can also use the refund they receive upon disbursement of protocol fee pools to further offset the additional gas fees they paid. The refund is a portion of the protocol fee that is distributed back to market makers based on their contribution to the liquidity pool.

Therefore, market makers can effectively reduce their overall transaction costs by using a higher gas price and earning a larger share of the protocol fee, which can be further offset by the refund they receive upon disbursement of protocol fee pools.
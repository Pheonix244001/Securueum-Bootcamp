# Incorrect comparison enables swapping and token draining at no cost

Checkbox: No
Linked to : spbp[147 169] 
Problem: Incorrect check comparison 
Recommendation: replace the >= with <= inside the require in the swap function. add unit test checking 
Tags: data validation

[v3-core/audit.pdf at main · Uniswap/v3-core](https://github.com/Uniswap/uniswap-v3-core/blob/main/audits/tob/audit.pdf)

the check inside the require is incorrect. Instead of checking that at least the

requested amount of tokens has been transferred to the pool, it checks that no more than

the requested amount has been transferred. In other words, if the callback does not

transfer any tokens to the pool, the check, and the swap, will succeed without the initiator

having paid any tokens.
# Oracle updates can be manipulated to perform atomic front-running attack

Checkbox: Yes
Linked to :  spbp [ 21 178 185 ]
Problem: Incorrect assumption about the status of data from system or entities being fresh 
Recommendation: Enforce per Block/Tx Constraints . Update the oracle once per block 
Tags: timing

[Bancor V2 AMM Security Audit | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/06/bancor-v2-amm-security-audit/#oracle-updates-can-be-manipulated-to-perform-atomic-front-running-attack)
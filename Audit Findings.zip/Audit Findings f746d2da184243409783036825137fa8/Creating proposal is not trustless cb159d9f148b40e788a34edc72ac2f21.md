# Creating proposal is not trustless

Checkbox: No
Linked to : spbp [176]
Problem: Token get refunded if proposal gets rejected but no refund if proposal is not processed before emergency meeting 
Recommendation: Use Pull patterns for token withdrawl
Tags: dos

[The LAO | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/01/the-lao/#creating-proposal-is-not-trustless)
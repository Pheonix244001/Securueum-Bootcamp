# Unhandled return values of transfer and transferFrom

Checkbox: No
Recommendation: safeTransferFrom is now used instead of transferFrom in all locations . Check the return value and revert on 0/false
Tags: erc20, transfer

[Transfer and safeTransfer](Unhandled%20return%20values%20of%20transfer%20and%20transferFr%20c0eaab98f33f4580b5cb71b180c5edb8/Transfer%20and%20safeTransfer%20e01adc721f74425690e3f93a69047d48.md)

[About SafeERC20 ](Unhandled%20return%20values%20of%20transfer%20and%20transferFr%20c0eaab98f33f4580b5cb71b180c5edb8/About%20SafeERC20%201d853780af00425c9a84b764db89da5a.md)

```solidity
function transfer(address to, uint256 amount) public virtual override returns (bool) {
        address owner = _msgSender();
        _transfer(owner, to, amount);
        return true;
    }
```

Moves `amount` tokens from the caller’s account to `recipient`.

Returns a boolean value indicating whether the operation succeeded. Emits a `[Transfer](https://docs.openzeppelin.com/contracts/2.x/api/token/erc20#IERC20-Transfer-address-address-uint256-)` event.

Remember that ERC20 only defines the types of functions to be implemented for any smart contract . It doesn’t matter what logic is running under the hood . 

[https://medium.com/coinmonks/missing-return-value-bug-at-least-130-tokens-affected-d67bf08521ca](https://medium.com/coinmonks/missing-return-value-bug-at-least-130-tokens-affected-d67bf08521ca)

### THINGS TO REMEMBER

1. Check for the methods where .transfer is used . using safeTransfer should be recommended 
    
    ```solidity
    if (curPoolInfo.poolEdition == 1) {
                            //For using transferFrom pool (like dodoV1, Curve), pool call transferFrom function to get tokens from adapter
                            IERC20(midToken[i]).transfer(curPoolInfo.adapter, curAmount);
                        } else {
                            //For using transfer pool (like dodoV2), pool determine swapAmount through balanceOf(Token) - reserve
                            IERC20(midToken[i]).transfer(curPoolInfo.pool, curAmount);
                        }
                    }
    ```
    

### Summary

In short , during the discusssion of erc20 implementation , 2 school of thoughts emerged . Either transaction should revert or should return fail in case of transfer faliure . Both were considered valid implementation . 

However some of the erc20 or erc721 tokens were behaving in some other way . They were not returning a boolean of true or false in case of transaction . Now all those functions that are expecting this bool to return their logic flow were malfunctioning . ( see blog for more details ) . So in order to combat this , openzepplin SafeERC20 should be used . This will automatically assert the return value during token transfer . So rather than using original `transfer` or `safeTransfer`

one should use `safeTransfer` and `safeTransferfrom`
# Front-running pool’s initialization can lead to draining of liquidity provider’s initial deposits

Checkbox: No
Linked to : sol [192 ] spbp [21 95 142 166]  
Problem: no access control in initialize function , can be called by anyone . so pool can be initialized with incorrect price 
Recommendation: use constructor , protect initialization 
Tags: access control, timing

[v3-core/audit.pdf at main · Uniswap/v3-core](https://github.com/Uniswap/uniswap-v3-core/blob/main/audits/tob/audit.pdf)
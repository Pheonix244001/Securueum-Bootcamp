# Unnecessary require Statement

Checkbox: No
Linked to : spbp [ 157 ] 
Problem: unnecessary require() 
Recommendation: remove the require statement 
Tags: error checking

[](https://github.com/sigp/public-audits/raw/master/infinigold/review.pdf)

: The following *require* statement in *Blacklistable.sol* can be removed: *require(to != address(0));* Indeed, this check is implemented in the *_transfer*() function in the *ERC20.sol* smart contract.

1. Recommendation: Consider removing the require statement for gas saving purposes.
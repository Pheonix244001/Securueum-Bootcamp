# Lack of event emission after sensitive actions

Checkbox: No
Linked to : spbp [ 45 173 201 ]
Problem: function does not emit relevant events after executing the sensitive actions 
Recommendation: consider emmiting event after sensitive changes take place to facilitate tracking and notifying offchain clients following the contracts activity 
Tags: auditing & logging

[UMA Audit - Phase 4 - OpenZeppelin blog](https://blog.openzeppelin.com/uma-audit-phase-4/)
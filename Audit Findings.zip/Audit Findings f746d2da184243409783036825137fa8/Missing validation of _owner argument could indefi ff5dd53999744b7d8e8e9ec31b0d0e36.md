# Missing validation of _owner argument could indefinitely lock owner role

Checkbox: Yes
Linked to : spbp [49 50 162 ]
Problem: lack of data validation or zero address check leads to permanent locking
Recommendation: use zero address check and implement data validation  ( more inside )
Tags: data validation

[v3-core/audit.pdf at main · Uniswap/v3-core](https://github.com/Uniswap/uniswap-v3-core/blob/main/audits/tob/audit.pdf)

Several improvements could prevent the four abovementioned cases:

● Designate msg.sender as the initial owner, and transfer ownership to the chosen

owner after deployment.

● Implement a two-step ownership-change process through which the new owner

needs to accept ownership.

● If it needs to be possible to set the owner to address(0), implement a

renounceOwnership function.

Long term, use Slither, which will catch the missing address(0) check, and consider using

two-step processes to change important privileged roles.
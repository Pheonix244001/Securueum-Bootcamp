# setFrozen can be front-run to deny deposits/swaps

Checkbox: No
Linked to : spbp [ 21 176 181 ] 
Problem: blocking contract through setFrozen function by admin could be abused to front run and then unfreezing 
Recommendation: rewrite the logic such that any contract freeze would not last long enough for a malicious owner to easily execute an attack or consider permanent freeze 
Tags: dos, timing

[protocol-v1-deprecated/2021-05-03-Trail_of_Bits.pdf at main · dfx-finance/protocol-v1-deprecated](https://github.com/dfx-finance/protocol/blob/main/audits/2021-05-03-Trail_of_Bits.pdf)

Currently, a Curve contract owner can use the *setFrozen*
 function to set the contract into a state that will block swaps and 
deposits. A contract owner could leverage this process to front-run 
transactions and freeze contracts before certain deposits or swaps are 
made; the contract owner could then unfreeze them at a later time.

1. Recommendation: Short term, consider rewriting *setFrozen* such that any contract freeze will not last long enough for a malicious user to easily execute an attack. Alternatively, depending on the
intended use of this function, consider implementing permanent freezes.
# Assimilators’ balance functions return raw values

Checkbox: No
Linked to : spbp [169] 
Problem: The system converts raw values to numeraire values for its internal arithmetic. However, in one instance it uses raw values alongside numeraire values
Recommendation: unit testing and fuzzing and also dont do this 
Tags: data validation

[protocol-v1-deprecated/2021-05-03-Trail_of_Bits.pdf at main · dfx-finance/protocol-v1-deprecated](https://github.com/dfx-finance/protocol/blob/main/audits/2021-05-03-Trail_of_Bits.pdf)

Alice uses a Curve to swap tokens. Since the calculation uses the raw value instead of the

numeraire value, she receives more tokens than she should. As a result, Bob, a liquidity

provider, loses funds.
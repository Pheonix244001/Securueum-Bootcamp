# Ensure system states, roles, and permissions are sufficiently restrictive

Checkbox: No
Linked to : spbp [ 148 149 153 172 192 ] 
Problem: Loosely Defined Roles and Permissions
Recommendation: Document and Monitor the use of admin permission 
Tags: access control

[Growth Defi V1 | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/12/growth-defi-v1/#ensure-system-states-roles-and-permissions-are-sufficiently-restrictive)
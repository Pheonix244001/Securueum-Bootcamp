# cancelTransaction can be called on non-queued transaction

Checkbox: No
Linked to : spbp [ 160 173 ] 
Problem: cancelTransaction can be called without the transaction existence check . attacker could confuse monitoring systems 
Recommendation: check that the trasaction is queued or not 
Tags: data validation

[publications/hermez.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/hermez.pdf)

Without a transaction existence check in *cancelTransaction*, an attacker can confuse monitoring systems. *cancelTransaction*
 emits an event without checking that the transaction to be canceled 
exists. This allows a malicious admin to confuse monitoring systems by 
generating malicious events.

1. Recommendation: Short term, check that the transaction to be canceled exists in *cancelTransaction*. This will ensure that monitoring tools can rely on emitted events. Long term, write a specification of each function and thoroughly test it
with unit tests and fuzzing. Use symbolic execution for arithmetic
invariants.
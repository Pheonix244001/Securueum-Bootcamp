# Single Account Can Capture All Supply

Checkbox: No
Linked to : spbp [ 158 169 170 171 ] 
Problem: a single account could capture all the supply eth protocol 
Recommendation: document this behaviour and enforce a cap 
Tags: data validation

[public-audits/review.pdf at master · sigp/public-audits](https://github.com/sigp/public-audits/blob/master/synthetix/ethercollateral/review.pdf)

The *EtherCollateral* smart contract does not rely on a *maxLoanSize*
 to limit the amount of ETH that can be locked for a loan. As a result, a
 single account can issue a loan that will reach the total minting 
supply.

1. Recommendation: Make sure this behaviour is understood and consider introducing and enforcing a cap ( *maxLoanSize* ) on the size of the loans allowed to be opened.
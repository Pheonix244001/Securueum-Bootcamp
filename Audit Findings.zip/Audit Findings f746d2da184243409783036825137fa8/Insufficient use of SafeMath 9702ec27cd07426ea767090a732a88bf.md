# Insufficient use of SafeMath

Checkbox: No
Linked to : spbp [ 19 169 170 ] 
Problem: SafeMath was not used in some places 
Recommendation: Consistently use SafeMath 
Tags: data validation

[protocol-v1-deprecated/2021-05-03-Trail_of_Bits.pdf at main · dfx-finance/protocol-v1-deprecated](https://github.com/dfx-finance/protocol/blob/main/audits/2021-05-03-Trail_of_Bits.pdf)

*CurveMath.calculateTrade* is used to compute the output amount for a trade. However, although *SafeMath*
 is used throughout the codebase to prevent underflows/overflows, it is 
not used in this calculation. Although we could not prove that the lack 
of *SafeMath* would cause an arithmetic issue in practice, all such calculations would benefit from the use of *SafeMath*.

1. Recommendation: Review all critical arithmetic to ensure that it accounts for
underflows, overflows, and the loss of precision. Consider using *SafeMath* and the safe functions of *ABDKMath64x64* where possible to prevent underflows and overflows.
# Initialization functions can be front-run

Checkbox: Yes
Linked to : sol[192 ] spbp [21 95 143 166] 
Problem:  Use of delegatecall proxy pattern doesn’t allow constructor initialization and so initialization functions are implemented which can be front runned 
Recommendation: Use a factory pattern or ensure deploy scripts are robust that can prevent front running 
Tags: configuration

[publications/hermez.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/hermez.pdf)

[https://blog.trailofbits.com/2018/09/05/contract-upgrade-anti-patterns/](https://blog.trailofbits.com/2018/09/05/contract-upgrade-anti-patterns/)
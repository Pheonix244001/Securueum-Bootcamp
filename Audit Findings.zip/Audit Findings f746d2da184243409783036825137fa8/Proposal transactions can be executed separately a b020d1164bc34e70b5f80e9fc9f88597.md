# Proposal transactions can be executed separately and block Proposal.execute call

Checkbox: Yes
Linked to : spbp [4 141 148 149 150 172]
Tags: access control

[publications/OriginDollar.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/OriginDollar.pdf)

- Anybody can call the Timelock.executeTransaction function to execute a specific transaction.
- If a transaction was already executed it will revert.
- If any of the transactions in a Proposal revert the entire Governor.execute call reverts.
- If any of the transactions in a Proposal with multiple transactions have been executed separately, the Governor.execute function cannot be used to execute the remaining transactions, as the already executed one will revert.
- The only way to execute the remaining transactions is separately executing them through Timelock.executeTransaction.
- This also means that when one transaction has been separately executed, the Proposal.executed field will forever remain false.
- A Proposal could contain multiple transactions that should be executed simultaneously to keep the contract functioning correctly. Executing the Proposal through Governor.execute would satisfy this requirement. However, only executing a specific transaction by directly executing it through Timelock.executeTransaction would break this requirement
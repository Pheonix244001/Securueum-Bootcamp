# Price Normalization

Price normalization is the process of converting a price value from one scale to another scale so that it can be easily compared and used in calculations. In the given code snippet, the price of a token is normalized to a standard scale of 36 decimals by adjusting the number of decimal places in the price value.

Normalization of the price is done in Solidity to ensure that the price values of different tokens are comparable and can be used in calculations without errors due to varying scales of price values. In this specific code snippet, the normalized price is used to calculate the daily low of the token, which is then stored in a mapping of daily lows for the token.

The normalization process involves finding the difference between the total number of decimals in the feed and token values and subtracting it from 36, which is the standard number of decimals used for Ethereum. The resulting value is multiplied with the price value to obtain the normalized price value.

For example, if the token price has 4 decimal places and the price feed has 6 decimal places, then the total number of decimal places is 10. To adjust this price to the standard scale of 36 decimal places, we subtract 10 from 36 to get 26. This means that we need to add 26 zeros after the price value to obtain a price with 36 decimal places.

To do this, we multiply the price value by 10^26, which adds 26 zeros to the price value, effectively adjusting the number of decimal places to 36. The resulting value is the normalized price, which can be used for comparisons and calculations.
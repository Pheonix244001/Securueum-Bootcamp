# Withdrawing ETH collateral with max uint256 amount value reverts transaction

Checkbox: No
Tags: M
URL: https://github.com/code-423n4/2022-05-sturdy-findings/issues/85
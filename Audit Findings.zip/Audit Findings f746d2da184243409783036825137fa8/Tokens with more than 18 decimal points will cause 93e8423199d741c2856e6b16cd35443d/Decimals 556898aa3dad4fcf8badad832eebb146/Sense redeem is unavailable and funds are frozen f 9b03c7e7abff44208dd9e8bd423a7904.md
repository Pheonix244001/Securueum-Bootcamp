# Sense redeem is unavailable and funds are frozen for underlyings 
whose decimals are smaller than the corresponding IBT decimals

Checkbox: No
Tags: H
URL: https://github.com/sherlock-audit/2022-10-illuminate-judging/issues/228
# Lender#lend for Sense has mismatched decimals

Checkbox: No
Tags: H
URL: https://github.com/sherlock-audit/2022-10-illuminate-judging/issues/164
# Wrong calculation for yVault price per share if decimals != 18

Checkbox: No
Tags: M
URL: https://github.com/code-423n4/2022-04-jpegd-findings/issues/117
# Wrong price scale for GasOracle

Checkbox: No
Tags: H
URL: https://github.com/code-423n4/2021-06-tracer-findings/issues/93
# PA1D#bidSharesForToken returns incorrect bidShares.creator.value

Checkbox: No
Tags: M
URL: https://github.com/code-423n4/2022-10-holograph-findings/issues/180
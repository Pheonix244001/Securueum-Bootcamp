# Oracle assumes token and feed decimals will be limited to 18 decimals

Checkbox: No
Tags: M
URL: https://github.com/code-423n4/2022-10-inverse-findings/issues/533
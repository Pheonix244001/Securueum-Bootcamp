# Tokens with lower number of decimals can result in postponed linear vesting for user

Checkbox: No
Tags: M
URL: https://github.com/code-423n4/2022-10-holograph-findings/issues/180
# Swapping 100 tokens in DepositReceipt_ETH and DepositReciept_USDC breaks usage of WBTC LP and other high value tokens

Checkbox: No
Comments: swapping logic break for wbtc ( 8 decimals)
Tags: H
URL: https://github.com/sherlock-audit/2022-11-isomorph-judging/issues/46
# CTokenOracle.sol#getCErc20Price contains critical math error

Checkbox: No
Tags: H
URL: https://github.com/sherlock-audit/2022-08-sentiment-judging/tree/main/021-H
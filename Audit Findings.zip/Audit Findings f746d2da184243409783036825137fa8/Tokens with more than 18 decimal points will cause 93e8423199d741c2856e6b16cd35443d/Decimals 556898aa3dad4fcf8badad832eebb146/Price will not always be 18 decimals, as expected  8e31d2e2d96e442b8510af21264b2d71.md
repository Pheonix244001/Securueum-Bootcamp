# Price will not always be 18 decimals, as expected and outlined in the comments

Checkbox: Yes
Comments: formula was not valid for >18 decimal 
Tags: M
URL: https://github.com/code-423n4/2022-12-caviar-findings/issues/141
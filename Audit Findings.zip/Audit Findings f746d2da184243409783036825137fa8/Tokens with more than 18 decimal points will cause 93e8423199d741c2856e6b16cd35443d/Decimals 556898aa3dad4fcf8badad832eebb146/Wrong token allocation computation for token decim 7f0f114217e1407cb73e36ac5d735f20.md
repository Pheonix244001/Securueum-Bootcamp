# Wrong token allocation computation for token decimals != 18 if floor price not reached

Checkbox: No
Tags: H
URL: https://github.com/code-423n4/2022-01-trader-joe-findings/issues/193
# The rather harsh requirement of tokenAmount makes it inapplicable for certain tokens

Checkbox: Yes
Tags: M
URL: https://github.com/sherlock-audit/2022-11-nounsdao-judging/issues/63
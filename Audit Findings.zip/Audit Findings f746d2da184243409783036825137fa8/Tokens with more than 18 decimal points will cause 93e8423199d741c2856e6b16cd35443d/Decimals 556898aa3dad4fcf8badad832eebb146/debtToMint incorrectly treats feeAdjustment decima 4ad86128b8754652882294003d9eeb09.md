# debtToMint incorrectly treats feeAdjustment decimals

Checkbox: No
Tags: H
URL: https://github.com/sherlock-audit/2022-11-opyn-judging/issues/236
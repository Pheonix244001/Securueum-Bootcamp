# CompositeMultiOracle returns wrong decimals for prices?

Checkbox: No
Tags: H
URL: https://github.com/code-423n4/2021-08-yield-findings/issues/26
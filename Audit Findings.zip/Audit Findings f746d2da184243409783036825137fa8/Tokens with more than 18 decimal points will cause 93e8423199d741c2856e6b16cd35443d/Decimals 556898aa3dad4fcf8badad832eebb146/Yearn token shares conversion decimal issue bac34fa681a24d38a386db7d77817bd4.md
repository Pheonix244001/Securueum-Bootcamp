# Yearn token <> shares conversion decimal issue

Checkbox: No
Tags: H
URL: https://github.com/code-423n4/2021-12-sublime-findings/issues/134
# Vault.balance() mixes normalized and standard amounts

Checkbox: No
Tags: H
URL: https://github.com/code-423n4/2021-09-yaxis-findings/issues/132
# UniV2LPOracle will malfunction if token0 or token1's decimals != 18

Checkbox: No
Tags: H
URL: https://github.com/sherlock-audit/2022-08-sentiment-judging/tree/main/026-H
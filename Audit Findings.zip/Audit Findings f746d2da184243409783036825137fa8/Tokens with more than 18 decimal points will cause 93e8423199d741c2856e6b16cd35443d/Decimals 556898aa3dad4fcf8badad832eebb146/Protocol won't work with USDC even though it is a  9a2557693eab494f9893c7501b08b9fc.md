# Protocol won't work with USDC even though it is a token specifically mentioned in the docs

Checkbox: No
Tags: M
URL: https://github.com/sherlock-audit/2022-11-float-capital-judging/issues/21
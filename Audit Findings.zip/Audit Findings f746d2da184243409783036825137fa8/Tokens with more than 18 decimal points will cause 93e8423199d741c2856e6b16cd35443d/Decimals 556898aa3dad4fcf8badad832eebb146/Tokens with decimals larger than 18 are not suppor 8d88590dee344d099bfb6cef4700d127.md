# Tokens with decimals larger than 18 are not supported

Checkbox: No
Tags: M
URL: https://github.com/code-423n4/2022-06-connext-findings/issues/204
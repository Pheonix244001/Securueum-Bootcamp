# ERC4626Oracle Price will be wrong when the ERC4626's decimals is different from the underlying token’s decimals

Checkbox: No
Tags: H
URL: https://github.com/sherlock-audit/2022-08-sentiment-judging/tree/main/025-H
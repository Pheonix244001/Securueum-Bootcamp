# Reentrancy and untrusted contract call in mintMultiple

Checkbox: Yes
Linked to : sol[157] spbp[13]
Tags: reentrancy

[publications/OriginDollar.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/OriginDollar.pdf)
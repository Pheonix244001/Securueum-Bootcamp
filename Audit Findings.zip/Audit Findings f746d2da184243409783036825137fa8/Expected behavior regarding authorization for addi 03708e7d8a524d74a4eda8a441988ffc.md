# Expected behavior regarding authorization for adding tokens is unclear

Checkbox: No
Linked to : spbp [ 129 136 172 188 ] 
Problem: addToken allows anyone to list a new token on Hermez.  contradicts online
documentation, which says that only the governance should have this authorization.
Recommendation: update either the implementaion or the authorization 
Tags: access control

[publications/hermez.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/hermez.pdf)

*addToken* allows anyone to list a new token on Hermez. 
This contradicts the online documentation, which implies that only the 
governance should have this authorization. It is unclear whether the 
implementation or the documentation is correct.

1. Recommendation: Short term, update either the implementation or the documentation to
standardize the authorization specification for adding tokens. Long
term, write a specification of each function and thoroughly test it with unit tests and fuzzing. Use symbolic execution for arithmetic
invariants.
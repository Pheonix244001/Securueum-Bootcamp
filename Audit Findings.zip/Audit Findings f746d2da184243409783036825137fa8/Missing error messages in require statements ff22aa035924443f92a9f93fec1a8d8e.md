# Missing error messages in require statements

Checkbox: No
Problem: missing error messages in require statements if they fail the transaction woudl revert silently 
Tags: error checking

[GEB Protocol Audit - OpenZeppelin blog](https://blog.openzeppelin.com/geb-protocol-audit/)

There are many places where *require* 
statements are correctly followed by their error messages, clarifying 
what was the triggered exception. However, there are places where *require* statements are not followed by the corresponding error messages. If any of those *require* statements were to fail the checked condition, the transactionwould revert silently without an informative error message.

1. Recommendation: Consider including specific and informative error messages in all *require* statements.
# A reverting fallback function will lock up all payouts

Checkbox: Yes
Linked to : sol [158] spbp [ 43 176 158 ]
Problem: Reverting Fallback function would lock up all payouts
Recommendation: Ignore Failed Transfer or Implement a pull withdrawl pattern 
Tags: dos

[Lien Protocol | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/05/lien-protocol/#a-reverting-fallback-function-will-lock-up-all-payouts)

[External Calls - Ethereum Smart Contract Best Practices](https://consensys.github.io/smart-contract-best-practices/development-recommendations/general/external-calls/#favor-pull-over-push-for-external-calls)

************************************************************************************************************************************The point is to avoid congesting more logic in a function . pull over push pattern helps you to minimize the faliures that are caused by failing of external call . Due to this , the function will not be able to execute any other logic and will stuck upon only making that faliure success . that is what we call denial of service .*** 

also these low level calls never throw exception upon faliure but instead they return false . 

```solidity
// bad
someAddress.send(55);
someAddress.call.value(55)(""); // this is doubly dangerous, as it will forward all remaining gas and doesn't check for result
someAddress.call.value(100)(bytes4(sha3("deposit()"))); // if deposit throws an exception, the raw call() will only return false and transaction will NOT be reverted

// good
(bool success, ) = someAddress.call.value(55)("");
if(!success) {
    // handle failure code
}

ExternalContract(someAddress).deposit.value(100)();
```

In BoxExchange.sol, the internal function `_transferEth()` reverts if the transfer does not succeed:

**code/Fairswap_iDOLvsETH/contracts/BoxExchange.sol:L958-L963**

```solidity
function _transferETH(address _recipient, uint256 _amount) private {
    (bool success, ) = _recipient.call{value: _amount}(
        abi.encodeWithSignature("")
    );
    require(success, "Transfer Failed");
}
```

The `_payment()` function processes a list of transfers to settle the transactions in an `ExchangeBox`.
 If any of the recipients of an Eth transfer is a smart contract that 
reverts, then the entire payout will fail and will be unrecoverable.
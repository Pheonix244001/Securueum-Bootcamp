# Deeper validation of curve math

Checkbox: No
Linked to : spbp [ 155 170 ] 
Problem: increased testing in mathematically complex logic could have found atleast one issue 
Recommendation: add fuzzing and uint/propert tests
Tags: testing

[DAOfi | ConsenSys Diligence](https://consensys.net/diligence/audits/2021/02/daofi/#deeper-validation-of-curve-math)
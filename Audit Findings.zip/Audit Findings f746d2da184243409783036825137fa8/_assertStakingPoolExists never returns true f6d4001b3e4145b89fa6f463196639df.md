# _assertStakingPoolExists never returns true

Checkbox: No
Linked to : spbp [ 142 175 ] 
Problem: function should have returned boolean but it didnt used return statement resulting in always false or revert 
Recommendation: add a return statement or remove return type 
Tags: error handling

[publications/0x-protocol.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/0x-protocol.pdf)

The *_assertStakingPoolExists* should return a bool to determine if the staking pool exists or not; however, it only returns false or reverts. The *_assertStakingPoolExists*
 function checks that a staking pool exists given a pool id parameter. 
However, this function does not use a return statement and therefore, it
 will always return false or revert.

1. Recommendation: Add a return statement or remove the return type. Properly adjust the documentation, if needed.
# Not using upgrade safe contracts in FsToken inheritance

Checkbox: No
Linked to : sol [192] spbp [97 165 166 ] 
Problem: importing ERC contracts not from upgradable library but from standard library . ( unsafe inheritance )  
Recommendation: use the updgrade safe library 
Tags: configuration

[https://blog.openzeppelin.com/futureswap-v2-audit/](https://blog.openzeppelin.com/futureswap-v2-audit/)

[Why is Initializable inheritance required everywhere?](https://forum.openzeppelin.com/t/why-is-initializable-inheritance-required-everywhere/284)

The fstoken contract is intended to be an upgradable contract  used behind a proxy 

however the ocntract ERC20Snapshot . ERC20Mintable ERC20Burnable in the inheritance chain of FsToken are not imported from the upgrade safe library but instead from normal contracts 

In particular, using the upgrades safe library in this case will ensure the inheritance from `Initializable`
 and the other contracts is always linearized as expected by the compiler (see this [forum post](https://forum.openzeppelin.com/t/why-is-initializable-inheritance-required-everywhere/284)
 for more info about it).
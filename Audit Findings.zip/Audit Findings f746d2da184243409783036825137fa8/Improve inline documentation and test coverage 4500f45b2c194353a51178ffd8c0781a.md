# Improve inline documentation and test coverage

Checkbox: No
Linked to : spbp [ 137 154 155 188 ]
Problem: source code had no inline documentation and test coverage was also limited 
Recommendation: consider natspec and increase Test coverage
Tags: documentation

[1inch Liquidity Protocol | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/12/1inch-liquidity-protocol/#improve-inline-documentation-and-test-coverage)
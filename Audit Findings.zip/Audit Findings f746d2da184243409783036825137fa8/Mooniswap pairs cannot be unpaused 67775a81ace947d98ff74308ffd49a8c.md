# Mooniswap pairs cannot be unpaused

Checkbox: No
Linked to : sol [ 156] spbp [134 135 176 ]
Problem: shutdown function only has pause functionality but no unpause one . 
Recommendation: provide a way to upause also 
Tags: dos

[1inch Liquidity Protocol Audit - OpenZeppelin blog](https://blog.openzeppelin.com/1inch-liquidity-protocol-audit/)

The `MooniswapFactoryGovernance` contract has a `[shutdown` function](https://github.com/1inch-exchange/mooniswap-v2/blob/b9c06335fb1d68b19054442547fc677f42795b44/contracts/governance/MooniswapFactoryGovernance.sol#L48)
 that can be used to pause the contract and prevent any future swaps. 
However there is no function to unpause the contract. There is also no 
way for the factory contract to redeploy a `Mooniswap` instance for a given pair of tokens. Therefore, if a `Mooniswap`
 contract is ever shutdown/paused, it will not be possible for that pair
 of tokens to ever be traded on the Mooniswap platform again, unless a 
new factory contract is deployed.

Consider providing a way for `Mooniswap` contracts to be unpaused.
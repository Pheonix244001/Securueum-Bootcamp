# Lack of return value checks can lead to unexpected results

Checkbox: No
Linked to : spbp[74 142]
Problem: several function calls were not checking the return value
Recommendation: check the return value
Tags: error handling

[publications/OriginDollar.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/OriginDollar.pdf)
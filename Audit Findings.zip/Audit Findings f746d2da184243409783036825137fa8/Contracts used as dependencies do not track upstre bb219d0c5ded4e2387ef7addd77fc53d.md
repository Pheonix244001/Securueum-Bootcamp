# Contracts used as dependencies do not track upstream changes

Checkbox: No
Linked to : spbp [ 165 180 183 190 ] 
Problem: 3rd party contracts were copy pasted and no documentation of version used or if modified . leads to unreiable security fixes 
Recommendation: Review the codebase and document each dependency with version used , also include 3rd party sources as submodules in git repo  so that dependencies  can be updated periodically 
Tags: patching

[publications/hermez.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/hermez.pdf)

Third-party contracts like *_concatStorage*
 are pasted into the Hermez repository. Moreover, the code documentation
 does not specify the exact revision used, or if it is modified. This 
makes updates and security fixes on these dependencies unreliable since 
they must be updated manually. *_concatStorage* is 
borrowed from the solidity-bytes-utils library, which provides helper 
functions for byte-related operations. Recently, a critical 
vulnerability was discovered in the library’s slice function which 
allows arbitrary writes for user-supplied inputs.

1. Recommendation: Short term, review the codebase and document each dependency’s source
and version. Include the third-party sources as submodules in your Git
repository so internal path consistency can be maintained and
dependencies are updated periodically. Long term, identify the areas in
the code that are relying on external libraries and use an Ethereum
development environment and NPM to manage packages as part of your
project.
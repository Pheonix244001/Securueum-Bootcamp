# Purchasing and committing still possible after launch

Checkbox: No
Linked to : spbp [145 178 143 177]
Problem: functions can be invoked more than once 
Recommendation: Consider adding validation to check functions are not called more than once if they are intended to do so 
Tags: timing

Even after *GenesisGroup.launch* has successfully been executed, it is still possible to invoke *GenesisGroup.purchase* and *GenesisGroup.commit* .

[Fei Protocol | ConsenSys Diligence](https://consensys.net/diligence/audits/2021/01/fei-protocol/#genesisgroup-commit-overwrites-previously-committed-values)
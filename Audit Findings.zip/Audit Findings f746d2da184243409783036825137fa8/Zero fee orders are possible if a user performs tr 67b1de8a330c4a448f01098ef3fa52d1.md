# Zero fee orders are possible if a user performs transactions with a zero gas price

Checkbox: No
Problem: order can be submitted with paying zero gas fees . because user is selecting gas price 
Recommendation: select a minimum fees for protocol and for the long term , do not depend on the gas price for computation of protocol fees . this will avoid giving miners advantage 
Tags: data validation

[publications/0x-protocol.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/0x-protocol.pdf)

[Zero Gas Price Transactions — what they do, who creates them, and why they might impact Scalability](https://medium.com/chainsecurity/zero-gas-price-transactions-what-they-do-who-creates-them-and-why-they-might-impact-scalability-aeb6487b8bb0)

The Exchange governance decides to significantly increase protocolFeeMultiplier to

force the collection of higher fees. Alice does not want to pay increased fees, so she

decides to submit her transactions with a gas price equal to zero and process her own

transactions as a miner. As a result, she is able to bypass protocol fee collection.
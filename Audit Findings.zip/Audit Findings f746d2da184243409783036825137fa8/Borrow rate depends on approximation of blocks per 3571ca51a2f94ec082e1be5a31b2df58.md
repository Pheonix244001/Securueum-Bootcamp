# Borrow rate depends on approximation of blocks per year

Checkbox: Yes
Linked to : spbp [ 18 165 166 184 ] 
Problem: incorrect assumption of blocks per year . it could change over time 
Recommendation: analyze the effect of this deviation and document that 
Tags: configuration

[publications/AdvancedBlockchain.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/AdvancedBlockchain.pdf)

The borrow rate formula uses an approximation of the number of 
blocks mined annually. This number can change across different 
blockchains and years. The current value assumes that a new block is 
mined every 15 seconds, but on Ethereum mainnet, a new block is mined 
every ~13 seconds. To calculate the base rate, the formula determines 
the approximate borrow rate over the past year and divides that number 
by the estimated number of blocks mined per year. However, *blocksPerYear*
 is an estimated value and may change depending on transaction 
throughput. Additionally, different blockchains may have different 
block-settling times, which could also alter this number.

1. Recommendation: Short term, analyze the effects of a deviation from the actual number
of blocks mined annually in borrow rate calculations and document the
associated risks. Long term, identify all variables that are affected by external factors, and document the risks associated with deviations
from their true values.
# Kyber getRates code is unclear

Checkbox: No
Linked to : spbp [137 188]
Problem: function names were not indicating their work and also have some undocumented assumptions as well
Recommendation: Refactor the code and also document any assumptions
Tags: specification

Function names don’t reflect their true functionalities, and the code uses some undocumented assumptions.

1. Recommendation: Refactor the code to separate getting rate functionality with
getSellRate and getBuyRate. Explicitly document any assumptions in the
code ( slippage, etc).

[DeFi Saver | ConsenSys Diligence](https://consensys.net/diligence/audits/2021/03/defi-saver/#kyber-getrates-code-is-unclear)
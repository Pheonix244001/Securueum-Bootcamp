# Proposals could allow Timelock.admin takeover

Checkbox: No
Linked to : spbp[148 149 172 196]
Problem: function to change timelock admin can be called by anyone , which is a risk
Recommendation: add a check that prevents setPendingAdmin to be included in a Proposal or let governor inherit from timelock 
Tags: access control

[publications/OriginDollar.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/OriginDollar.pdf)

note - all of these security flaws are going with an assumption that the ******************guardian****************** would be unable to notice a malicious transaction in a queued transaction and it will execute 

the point is that we are putting too much trust on the guardian , which makes it an attack vector and also goes against the philosophy of decentralization
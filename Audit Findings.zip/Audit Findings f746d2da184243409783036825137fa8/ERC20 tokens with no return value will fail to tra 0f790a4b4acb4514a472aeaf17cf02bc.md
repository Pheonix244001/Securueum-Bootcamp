# ERC20 tokens with no return value will fail to transfer

Checkbox: No
Problem: Incorrect Reurn value check on ERC20 transfer
Recommendation: Consider using OpenZeppelin’s SafeERC20
Tags: error handling

[Transfer and safeTransfer](Unhandled%20return%20values%20of%20transfer%20and%20transferFr%20c0eaab98f33f4580b5cb71b180c5edb8/Transfer%20and%20safeTransfer%20e01adc721f74425690e3f93a69047d48.md) 

[bitbank | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/11/bitbank/#erc20-tokens-with-no-return-value-will-fail-to-transfer)

In that case, the `.transfer()` call here will revert even
 if the transfer is successful, because solidity will check that the 
RETURNDATASIZE matches the ERC20 interface.
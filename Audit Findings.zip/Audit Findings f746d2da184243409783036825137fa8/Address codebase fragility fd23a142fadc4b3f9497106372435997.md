# Address codebase fragility

Checkbox: No
Linked to : spbp [ 180 183 188 197 ] 
Problem: Codebase if fragile ( check details for definition ) 
Recommendation:  single-responsibility principle of functions and Reduce reliance on external systems
Tags: fragile code

[MCDEX Mai Protocol V2 | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/05/mcdex-mai-protocol-v2/#address-codebase-fragility)

**Software is considered “fragile” when issues or changes in one part 
of the system can have side-effects in conceptually unrelated parts of 
the codebase. Fragile software tends to break easily and may be 
challenging to maintain.**

Our assessment uncovered several indicators of software fragility in Mai V2:

- [Issue 6.8](https://consensys.net/diligence/audits/2020/05/mcdex-mai-protocol-v2/#amm-amount-of-collateral-spent-or-shares-received-may-be-unpredictable-for-liquidity-provider) describes that liquidity providers can never be sure of the result of calls to `addLiquidity` and `removeLiquidity`. The amount of collateral received for burned shares, and the number of
shares received for provided collateral is based on the system’s current price and total shares in circulation. These values can fluctuate
significantly for many reasons:
- Oracle price updates may introduce a new price to the system.
Significant deviations from expected values may result in unexpected
gains or losses for users.
- Frontrunning by other users (whether on purpose or not) will affect the current price and total share amount.
- Adjustments to global variable configuration by the system admin do
not come with a delay, so changes will directly impact users' subsequent actions.
- System configuration by administrators primarily occurs in `Perpetual` (via inherited `PerpetualGovernance`) and `AMM` (via inherited `AMMGovernance`). Both configuration features are accessed through monolithic `setGovernanceParameter` functions, where an input `bytes32 key` is compared against all existing parameter names for a match. If a match is found, the parameter is set to the input `int256 value`.
- If future development adds or removes configurable parameters, the
change will have a broad impact on the entire configuration system.
- `int256 value` is not a sufficiently-descriptive value for many configurable parameters. Many parameters must first convert this to a `uint` via `LibMathSigned.toUint256`, which rejects negative input values. As a result, if a parameter is introduced that requires a high enough `uint` value, these functions will not work as the positive values of `int256` do not go higher than `2 ** 255 - 1`.
- By using a multipurpose function like `setGovernanceParameter`, configurable parameters are not afforded the type safety checks
Solidity would provide if standard, single-purpose setter methods were
used.

### Recommendation:

Building an anti-fragile system requires careful thought and 
consideration outside of the scope of this review. In general, 
prioritize the following concepts:

- **Follow the single-responsibility principle of functions.** This principle states that functions should have responsibility for a
single part of the system’s functionality and that their purpose should
be narrowly-aligned with that responsibility. Avoid functions that “do
everything” (like `setGovernanceParameter`), and avoid functions that touch every other function (like `funding` and `markPrice`).
- **Reduce reliance on external systems.** Whether the
“external system” refers to the Chainlink oracle or admin control, the
contracts should avoid blindly and immediately consuming and conforming
to the arbitrary inputs of external systems. External systems can
introduce significant change at a moment’s notice: the oracle may wildly impact the index price, and admins may suddenly make large adjustments
to fee rates, lot sizes, premiums, and other critically-important
values. When reducing reliance on external systems, make sure users can
interact with the system in a consistent, expected manner.
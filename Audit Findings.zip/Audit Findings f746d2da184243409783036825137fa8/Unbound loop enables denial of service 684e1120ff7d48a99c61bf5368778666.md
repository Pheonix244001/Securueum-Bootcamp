# Unbound loop enables denial of service

Checkbox: No
Linked to : spbp[43 176 182]
Problem: unbounded loop causing dos 
Recommendation: bound the loops and document them 
Tags: dos

[v3-core/audit.pdf at main · Uniswap/v3-core](https://github.com/Uniswap/uniswap-v3-core/blob/main/audits/tob/audit.pdf)

creates thousands of positions in every Uniswap V3 pool to prevent users from using the system
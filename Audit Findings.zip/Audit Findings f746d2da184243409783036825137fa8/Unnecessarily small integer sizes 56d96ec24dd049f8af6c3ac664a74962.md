# Unnecessarily small integer sizes

Checkbox: No
Linked to : spbp [ 136 197 ] 
Problem: unecessary small integers increase gas cost 
Recommendation: use uint256
Tags: specification

[Fei Protocol Audit - OpenZeppelin blog](https://blog.openzeppelin.com/fei-protocol-audit/)

In Solidity, using integers smaller than 256 bits tends to 
increase gas costs because the Ethereum Virtual Machine must perform 
additional operations to zero out the unused bits. This can be justified
 by savings in storage costs in some scenarios, however, that is not 
generally the case in this codebase.

1. Recommendation: Consider using integers of size 256 bits to improve gas efficiency and mitigate function reverts.
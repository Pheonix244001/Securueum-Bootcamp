# Summoner can steal funds using bailout

Checkbox: No
Linked to : spbp[176]
Problem: Given a lot of trust to the summoner to transfer funds 
Recommendation: use a Pull mechanism
Tags: dos

[The LAO | ConsenSys Diligence](https://consensys.net/diligence/audits/2020/01/the-lao/#emergency-processing-can-be-blocked)
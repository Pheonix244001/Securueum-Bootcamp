# Batch processing of transaction execution and order matching may lead to exchange griefing

Checkbox: No
Linked to : spbp [43 175 176] 
Problem: if one transaction fails in a batch procesing , the entire batch will revert 
Recommendation: implement NoThrow variants for batch processing of transaction execution and order matching . also consider the malicious inputs when implementing function that perform batch operation
Tags: dos

[publications/0x-protocol.pdf at master · trailofbits/publications](https://github.com/trailofbits/publications/blob/master/reviews/0x-protocol.pdf)

attacker submit valid transaction , the transaction gets bundled up in a batch by validator . but before the validation happens , the attacker front runs it and decrease the allowance below the limit which will make the valid transaction invalid . this will cause the whole batch to revert and there is a loss of fees to the makers

Note - call within loops is a representative of batch transactions
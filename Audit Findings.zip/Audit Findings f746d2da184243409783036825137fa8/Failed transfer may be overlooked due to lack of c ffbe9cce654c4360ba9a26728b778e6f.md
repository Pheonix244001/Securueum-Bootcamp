# Failed transfer may be overlooked due to lack of contract existence check

Checkbox: No
Linked to : sol [87] spbp [38 174]
Problem: .safeTransfer  performs a transfer with a low-level call without
confirming the contract’s existence
Recommendation: check contract existence before low level call . avoid low level calls if possible 
Tags: data validation

[v3-core/audit.pdf at main · Uniswap/v3-core](https://github.com/Uniswap/uniswap-v3-core/blob/main/audits/tob/audit.pdf)

Exploit 

The pool contains tokens A and B. Token A has a bug, and the contract is destroyed. Bob is

not aware of the issue and swaps 1,000 B tokens for A tokens. Bob successfully transfers

1,000 B tokens to the pool but does not receive any A tokens in return. As a result, Bob

loses 1,000 B tokens.
# Incorrect safeApprove usage

Checkbox: No
Linked to : sol [149 ] spbp [21 22 177 ]
Problem: setting allowance to zero reintroduces front running attack and undermines the value of safeApprove
Recommendation: consider using safeIncrease/DecreaseAllowance 
Tags: timing

[1inch Exchange Audit - OpenZeppelin blog](https://blog.openzeppelin.com/1inch-exchange-audit/)

The `safeApprove` function of the OpenZeppelin `SafeERC20` library [prevents changing an allowance between non-zero values](https://github.com/OpenZeppelin/openzeppelin-contracts/blob/master/contracts/token/ERC20/SafeERC20.sol#L42-L44) to mitigate a [possible front-running attack](https://github.com/ethereum/EIPs/issues/20#issuecomment-263524729). 

Instead, the `safeIncreaseAllowance` and `safeDecreaseAllowance` functions should be used. However, the `UniERC20` library simply [bypasses this restriction](https://github.com/1inch-exchange/1inch-v2-contracts/blob/72f2812837fdd73ec2d32c8988811df361e80985/contracts/helpers/UniERC20.sol#L47-L50) by first setting the allowance to zero. 

The reintroduces the front-running attack and undermines the value of the `safeApprove` function. Consider introducing an `increaseAllowance` function to handle this case.

This issue is related to **[[ M02 ] Cannot decrease allowance to non-zero value](https://blog.openzeppelin.com/1inch-exchange-audit/#m02)** and any mitigation should consider both simultaneously.

*Fixed in [commit bdbda2c7](https://github.com/1inch-exchange/1inch-v2-contracts/commit/bdbda2c74b772e99687200f487f687cc96e5a26d). The function replicates standard `approve`
 functionality, whether or not the token prevents changing allowances 
between non-zero values. The code intentionally disregards the possible 
frontrunning attack in the interest of universal applicability.*